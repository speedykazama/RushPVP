config = {}

config.prices = {
	-- Tipos de Cor
	["colortypes"] = {
		["cromado"] = 2000,
		["metálico"] = 2000,
		["fosco"] = 2000,
		["metal"] = 2000
	},
	-- Cor Primária Custom
	["cor-primaria"] = {
		startprice = 0,
	},
	-- Cor primária
	["primaria"] = {
		startprice = 2000,
	},
	-- Cor Secundária Custom
	["cor-secundaria"] = {
		startprice = 0,
	},
	-- Cor Secundária
	["secundaria"] = {
		startprice = 1000,
	},
	-- Perolado
	["perolado"] = {
		startprice = 0,
	},
	-- Cor da roda
	["wheelcolor"] = {
		startprice = 1000,
	},
	-- Neon
	["neon"] = {
		startprice = 13000,
	},
	-- Pneu Custom
	["custom"] = {
		startprice = 1000,
	},
	-- Pneu a prova de balas
	["bulletproof"] = {
		startprice = 240000,
	},
	-- Placa
	["placa"] = {
		startprice = 1000,
		increaseby = 0
	},
	-- Vidro
	["vidro"] = {
		startprice = 3000,
		increaseby = 0
	},
	-- Liveries
	[48] = {
		startprice = 5000,
		increaseby = 0
	},
	-- Windows
	[46] = {
		startprice = 3000,
		increaseby = 0
	},
	-- Tank
	[45] = {
		startprice = 20000,
		increaseby = 20000
	},
	-- Trim
	[44] = {
		startprice = 1000,
		increaseby = 0
	},
	-- Aerials
	[43] = {
		startprice = 2000,
		increaseby = 0
	},
	-- Arch Cover
	[42] = {
		startprice = 2000,
		increaseby = 0
	},
	-- Struts
	[41] = {
		startprice = 5000,
		increaseby = 0
	},
	-- Air Filter
	[40] = {
		startprice = 2000,
		increaseby = 0
	},
	-- Engine Block
	[39] = {
		startprice = 2000,
		increaseby = 0
	},
	-- Hydraulics
	[38] = {
		startprice = 5000,
		increaseby = 0
	},
	-- Trunk
	[37] = {
		startprice = 4000,
		increaseby = 0
	},
	-- Speakers
	[36] = {
		startprice = 5000,
		increaseby = 0
	},
	-- Plaques
	[35] = {
		startprice = 2000,
		increaseby = 0
	},
	-- Shift leavers
	[34] = {
		startprice = 3000,
		increaseby = 0
	},
	-- Steeringwheel
	[33] = {
		startprice = 3000,
		increaseby = 0
	},
	-- Seats
	[32] = {
		startprice = 4000,
		increaseby = 0
	},
	-- Door speaker
	[31] = {
		startprice = 5000,
		increaseby = 0
	},
	-- Dial
	[30] = {
		startprice = 4000,
		increaseby = 0
	},
	-- Dashboard
	[29] = {
		startprice = 4000,
		increaseby = 0
	},
	-- Ornaments
	[28] = {
		startprice = 4000,
		increaseby = 0
	},
	-- Trim
	[27] = {
		startprice = 4000,
		increaseby = 0
	},
	-- Vanity Plates
	[26] = {
		startprice = 3000,
		increaseby = 0
	},
	-- Plate holder
	[25] = {
		startprice = 3000,
		increaseby = 0
	},
	-- Back Wheels
	[24] = {
		startprice = 5000,
		increaseby = 0
	},
	-- Front Wheels
	[23] = {
		startprice = 5000,
		increaseby = 0
	},
	-- Headlights
	[22] = {
		startprice = 15000,
	},
	-- Turbo
	[18] = {
		startprice = 20000,
	},
	-- Armor
	[16] = {
		startprice = 20000,
		increaseby = 20000
	},
	-- Suspension
	[15] = {
		startprice = 5000,
		increaseby = 5000
	},
	-- Horn
	[14] = {
		startprice = 2000,
		increaseby = 0
	},
	-- Transmission
	[13] = {
		startprice = 30000,
		increaseby = 10000
	},
	-- Brakes
	[12] = {
		startprice = 10000,
		increaseby = 10000
	},
	-- Engine
	[11] = {
		startprice = 10000,
		increaseby = 10000
	},
	-- Roof
	[10] = {
		startprice = 2000,
		increaseby = 0
	},
	-- Fenders
	[8] = {
		startprice = 4000,
		increaseby = 0
	},
	-- Hood
	[7] = {
		startprice = 4000,
		increaseby = 0
	},
	-- Grille
	[6] = {
		startprice = 4000,
		increaseby = 0
	},
	-- Roll Cage
	[5] = {
		startprice = 4000,
		increaseby = 0
	},
	-- Exhaust
	[4] = {
		startprice = 4000,
		increaseby = 0
	},
	-- Skirts
	[3] = {
		startprice = 5000,
		increaseby = 0
	},
	-- Rear Bumpers
	[2] = {
		startprice = 5000,
		increaseby = 0
	},
	--Front Bumpers
	[1] = {
		startprice = 5000,
		increaseby = 0
	},
	-- Spoiler
	[0] = {
		startprice = 5000,
		increaseby = 0
	},
}

config.locais = {
	{
		pos = vec3(875.83,-2125.02,30.55),
		heading = 170.08,
		permission = "Mechanic"
	},
	{
		pos = vec3(887.16,-2125.85,30.55),
		heading = 170.08,
		permission = "Mechanic"
	},
	{
		pos = vec3(897.8,-2126.74,30.55),
		heading = 170.08,
		permission = "Mechanic"
	},
	{
		pos = vec3(909.13,-2127.54,30.55),
		heading = 170.08,
		permission = "Mechanic"
	},
	{
		pos = vec3(2740.25,3491.73,55.25),
		heading = 337.33,
		permission = "Mechanic2"
	},
	{
		pos = vec3(2733.64,3494.66,55.25),
		heading = 337.33,
		permission = "Mechanic2"
	},
	{
		pos = vec3(2724.98,3498.14,55.25),
		heading = 337.33,
		permission = "Mechanic2"
	},
	{
		pos = vec3(2716.92,3501.53,55.25),
		heading = 337.33,
		permission = "Mechanic2"
	},
	{
		pos = vec3(2708.76,3504.99,55.25),
		heading = 337.33,
		permission = "Mechanic2"
	}
}