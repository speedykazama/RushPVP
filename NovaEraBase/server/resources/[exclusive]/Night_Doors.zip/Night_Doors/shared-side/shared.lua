Config = {}

Config.CommandAddDoor = "addport"                                   -- COMANDO PARA ADICIONAR UMA PORTA
Config.CommandRemDoor = "remport"                                   -- COMANDO PARA REMOVER UMA PORTA
Config.CommandDebugDoor = "debugport"                               -- COMANDO PARA DEBUGAR UMA PORTA
Config.CommandReloadDoors = "reloaddoors"                           -- COMANDO PARA RECARREGAR AS PORTAS

Config.PermissionDoor = "Admin"                                     -- PERMISSÃO QUE PODE ADICIONAR/REMOVER/DEBUGAR E RECARREGAR AS PORTAS
Config.PermissionOpenCloseAllDoor = "Admin"                         -- PERMISSÃO QUE PODE ABRIR/FECHAR QUALQUER PORTA
Config.PermissionPolice = "Policia"                                 -- PERMISSÃO QUE VAI NOTIFICAR QUANDO ALGUÉM ARROMBAR UMA PORTA

Config.BreakDoors = true                                            -- ATIVAR/DESATIVAR O ARROMBAMENTO DE PORTAS
Config.ItemLockPick = "lockpick"                                    -- ITEM NECESSÁRIO PARA ARROMBAR AS PORTAS
Config.ProbabilityBreakLockpick = 80                                -- 80% DE CHANCE DE QUEBRAR A LOCKPICK
Config.ProbabilityCallPolice = 80                                   -- 80% DE CHANCE DE NOTIFICAR A POLÍCIA                           
Config.KeyboardBreakDoors = "G"                                     -- TECLA PARA ARROMBAR UMA PORTA

Config.KeyboardOpenCloseDoor = "E"                                  -- TECLA PARA ABRIR/FECHAR PORTAS
Config.DistanceOpenCloseDoor = 2.0                                  -- DISTÂNCIA QUE O JOGADOR PRECISA ESTAR DA PORTA PARA ABRIR/FECHAR

Config.SpritesDoors = {
    [0] = { "mpsafecracking", "lock_open", 0, 0, 0.018, 0.018, 0, 0, 255, 0, 255 },
    [1] = { "mpsafecracking", "lock_closed", 0, 0, 0.018, 0.018, 0, 255, 0, 0, 255 }
}