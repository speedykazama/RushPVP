-----------------------------------------------------------------------------------------------------------------------------------------
-- VRP
-----------------------------------------------------------------------------------------------------------------------------------------
local Tunnel = module("vrp", "lib/Tunnel")
local Proxy = module("vrp", "lib/Proxy")
local Tools = module("vrp", "lib/Tools")
vRPC = Tunnel.getInterface("vRP")
vRP = Proxy.getInterface("vRP")
-----------------------------------------------------------------------------------------------------------------------------------------
-- CONNECTION
-----------------------------------------------------------------------------------------------------------------------------------------
Creative = {}
Tunnel.bindInterface("Night_Doors",Creative)
vCLIENT = Tunnel.getInterface("Night_Doors")
vKEYBOARD = Tunnel.getInterface("keyboard")
vTASKBAR = Tunnel.getInterface("taskbar")
-----------------------------------------------------------------------------------------------------------------------------------------
-- VARIABLES
-----------------------------------------------------------------------------------------------------------------------------------------
local doorslock = {}
local doors = {}
----------------------------------------------------------------------------------------------------------------------------------------
-- TRYLOCKDOOR
----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("tryLockDoor")
AddEventHandler("tryLockDoor", function(id)
    local source = source
    local Passport = vRP.Passport(source)
    if Passport then
        if doors[id] ~= nil then
            local door = doors[id]
            if vRP.HasGroup(Passport, Config.PermissionOpenCloseAllDoor) or vRP.HasGroup(Passport, doors[id].perm) then
                local state = doors[id].lock

                if doorslock[id] ~= nil then
                    state = doorslock[id]
                end

                doorslock[id] = not state

                TriggerClientEvent("door", -1, id, doorslock[id])
                return
            end

            if Config.BreakDoors then
                local dataItem = vRP.InventoryItemAmount(Passport, Config.ItemLockPick)
                local consultItem = dataItem[1]

                if consultItem >= 1 then
                    vRPC.playAnim(source, false, {"missheistfbi3b_ig7", "lift_fibagent_loop"}, false)

                    if math.random(100) <= Config.ProbabilityBreakLockpick then
                        vRP.TakeItem(Passport, dataItem[2], 1, true)
                        TriggerClientEvent("Notify", source, "vermelho", "Sua lockpick quebrou.", 5000)
                    end

                    local taskResult = vTASKBAR.taskDoors(source)
                    if taskResult then
                        TriggerClientEvent("Notify", source, "amarelo", "Você conseguiu arrombar a porta.", 5000)
                        TriggerClientEvent("door", -1, id, doorslock[id])
                        vRPC.PlaySound(source, "ATM_WINDOW", "HUD_FRONTEND_DEFAULT_SOUNDSET")

                        local ped = GetPlayerPed(source)
                        local coords = GetEntityCoords(ped)

                        if math.random(100) <= Config.ProbabilityCallPolice then
                            local policeResult = vRP.NumPermission(Config.PermissionPolice)
                            for k,v in pairs(policeResult) do
                                async(function()
                                    TriggerClientEvent("NotifyPush", v, {
                                        code = 90,
                                        title = "Arrombou uma Porta",
                                        x = coords.x,
                                        y = coords.y,
                                        z = coords.z,
                                        criminal = "Alarme de segurança",
                                        time = "Recebido às " .. os.date("%H:%M"),
                                        blipColor = 43
                                    })
                                end)
                            end
                        end
                    end

                    vRPC.Destroy(source)
                end
            end
        end
    end
end)
----------------------------------------------------------------------------------------------------------------------------------------
-- TRYOPENCLOSEDOOR
----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("tryOpenCloseDoor")
AddEventHandler("tryOpenCloseDoor", function(id)
    local source = source
    local Passport = vRP.Passport(source)
    if Passport then
        if doors[id] ~= nil then
            local door = doors[id]
            if vRP.HasGroup(Passport, Config.PermissionOpenCloseAllDoor) or vRP.HasGroup(Passport, doors[id].perm) then
                local state = doors[id].lock
                if doorslock[id] ~= nil then
                    state = doorslock[id]
                end
                doorslock[id] = not state
                TriggerClientEvent("door", -1, id, doorslock[id])
            end
        end
    end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- CONNECT
-----------------------------------------------------------------------------------------------------------------------------------------
AddEventHandler("Connect", function(Passport, source, first_spawn)
    TriggerClientEvent("doors:loadall", -1, doors)
    Wait(500)
    TriggerClientEvent("doors:load", -1, doorslock)
end)
----------------------------------------------------------------------------------------------------------------------------------------
-- RELOADDOORS
----------------------------------------------------------------------------------------------------------------------------------------
RegisterCommand(Config.CommandReloadDoors, function(source, ...)
    local Passport = vRP.Passport(source)
    if Passport and vRP.HasGroup(Passport, Config.PermissionDoor) then
        TriggerClientEvent("doors:load", -1, doorslock)
        TriggerClientEvent("Notify", source, "verde", "Você atualizou os portões com sucesso", 5000)
    end
end)
----------------------------------------------------------------------------------------------------------------------------------------
-- DEBUGDOOR
----------------------------------------------------------------------------------------------------------------------------------------
RegisterCommand(Config.CommandDebugDoor, function(source)
    local Passport = vRP.Passport(source)
    if Passport and vRP.HasGroup(Passport, Config.PermissionDoor) then
        local data = vCLIENT.rayCastDoor(source)
        if data and data.hash and data.coords then
            for id, door in pairs(doors) do
                if door.hash == data.hash and 
                   math.abs(door.x - data.coords.x) < 0.01 and 
                   math.abs(door.y - data.coords.y) < 0.01 and 
                   math.abs(door.z - data.coords.z) < 0.01 then
                    TriggerClientEvent("Notify", source, "verde", "ID da porta: " .. id, 5000)
                    return
                end
            end
            TriggerClientEvent("Notify", source, "vermelho", "Nenhuma porta encontrada.", 5000)
        else
            TriggerClientEvent("Notify", source, "vermelho", "Nenhuma porta detectada no local.", 5000)
        end
    else
        TriggerClientEvent("Notify", source, "vermelho", "Permissão insuficiente.", 5000)
    end
end)
----------------------------------------------------------------------------------------------------------------------------------------
-- REMDOOR
----------------------------------------------------------------------------------------------------------------------------------------
RegisterCommand(Config.CommandRemDoor, function(source)
    local Passport = vRP.Passport(source)
    if Passport and vRP.HasGroup(Passport, Config.PermissionDoor) then
        local data = vCLIENT.rayCastDoor(source)
        if data and data.hash and data.coords then
            for id, door in pairs(doors) do
                if door.hash == data.hash and 
                   math.abs(door.x - data.coords.x) < 0.01 and 
                   math.abs(door.y - data.coords.y) < 0.01 and 
                   math.abs(door.z - data.coords.z) < 0.01 then

                    doors[id] = nil
                    local success = SaveResourceFile(GetCurrentResourceName(), "doors.json", json.encode(doors, {indent = true}), -1)
                    
                    if success then
                        TriggerClientEvent("doors:remove", -1, id)
                        TriggerClientEvent("Notify", source, "verde", "Porta removida com sucesso.", 5000)
                    end
                    return
                end
            end
            TriggerClientEvent("Notify", source, "vermelho", "Nenhuma porta encontrada para deletar.", 5000)
        else
            TriggerClientEvent("Notify", source, "vermelho", "Nenhuma porta detectada no local.", 5000)
        end
    else
        TriggerClientEvent("Notify", source, "vermelho", "Permissão insuficiente.", 5000)
    end
end)
----------------------------------------------------------------------------------------------------------------------------------------
-- ADDDOOR
----------------------------------------------------------------------------------------------------------------------------------------
RegisterCommand(Config.CommandAddDoor,function(source)
    local Passport = vRP.Passport(source)
    if Passport and vRP.HasGroup(Passport, Config.PermissionDoor) then
        local data = vCLIENT.rayCastDoor(source)
        if data and data.hash and data.coords then
            local keyboard = vKEYBOARD.keySingle(source, "Digite a permissão da porta")
            local perm = keyboard and keyboard[1] or nil
            if perm and perm ~= "" then
                local doorsFile = LoadResourceFile(GetCurrentResourceName(), "doors.json")
                local existingDoors = json.decode(doorsFile) or {}
                local newDoor = {
                    isGate = false,
                    dist = Config.DistanceOpenCloseDoor,
                    text = true,
                    hash = data.hash,
                    x = data.coords.x,
                    y = data.coords.y,
                    z = data.coords.z,
                    perm = perm,
                    lock = true
                }
                table.insert(existingDoors, newDoor)
                local success = SaveResourceFile(GetCurrentResourceName(), "doors.json", json.encode(existingDoors, {indent = true}), -1)
                if success then
                    doors = existingDoors
                    TriggerClientEvent("doors:loadall", -1, doors)
                    Wait(500)
                    TriggerClientEvent("doors:load", -1, doorslock)
                end
            else
                TriggerClientEvent("Notify", source, "vermelho", "Permissão inválida ou não inserida.", 5000)
            end
        else
            TriggerClientEvent("Notify", source, "vermelho", "Nenhuma porta detectada no local.", 5000)
        end
    else
        TriggerClientEvent("Notify", source, "vermelho", "Permissão insuficiente.", 5000)
    end
end)
----------------------------------------------------------------------------------------------------------------------------------------
-- LOADDOORS
----------------------------------------------------------------------------------------------------------------------------------------
CreateThread(function()
    local doorsFile = LoadResourceFile(GetCurrentResourceName(), "doors.json")
    if doorsFile then
        doors = json.decode(doorsFile) or {}
        for _, door in ipairs(doors) do
            door.lock = true
        end
        Wait(500)
        TriggerClientEvent("doors:loadall", -1, doors)
        Wait(500)
        TriggerClientEvent("doors:load", -1, doorslock)
    end
end)