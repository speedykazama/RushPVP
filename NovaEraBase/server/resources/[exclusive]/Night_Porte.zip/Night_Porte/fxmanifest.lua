fx_version "bodacious"
game "gta5"

ui_page "web-side/index.html"

client_scripts {
	"@vrp/lib/utils.lua",
	"shared-side/*",
	"client-side/*",
}

server_scripts {
	"@vrp/lib/utils.lua",
	"shared-side/*",
	"server-side/*",
}

files {
	"web-side/*",
	"web-side/js/*",
	"web-side/css/*",
	"web-side/imgs/*"
}