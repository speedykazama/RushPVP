-----------------------------------------------------------------------------------------------------------------------------------------
-- VRP
-----------------------------------------------------------------------------------------------------------------------------------------
local Tunnel = module("vrp","lib/Tunnel")
local Proxy = module("vrp","lib/Proxy")
vRP = Proxy.getInterface("vRP")
-----------------------------------------------------------------------------------------------------------------------------------------
-- CONNECTION
-----------------------------------------------------------------------------------------------------------------------------------------
Creative = {}
Tunnel.bindInterface("Night_Porte", Creative)
Proxy.addInterface("Night_Porte", Creative)
vCLIENT = Tunnel.getInterface("Night_Porte")
-----------------------------------------------------------------------------------------------------------------------------------------
-- VARIABLES
-----------------------------------------------------------------------------------------------------------------------------------------
Creative.inPorte = {}
-----------------------------------------------------------------------------------------------------------------------------------------
-- GETINSPORTE
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.getInsPorte()
    return Creative.inPorte
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- CHECKINPORTECLIENT
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.checkInPorteClient()
    local source = source
    local Passport = vRP.Passport(source)
    return Creative.inPorte[tostring(Passport)] or false
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- SETINPORTE
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.setInPorte(bool)
    local source = source
    local Passport = vRP.Passport(source)
    Creative.inPorte[tostring(Passport)] = bool
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- SETPLAYERSTAND
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.setPlayerStand(ped)
    local source = source
    SetPlayerRoutingBucket(source, tonumber(source))
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- RETURNPLAYERSTAND
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.returnPlayerStand()
    local source = source
    SetPlayerRoutingBucket(source, 0)
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- VERIFICARPORTE
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.verificarPorte(Passport)
    local Result = vRP.Query("characters/CheckGun", { Passport = Passport })
    if Result[1] and tonumber(Result[1].gun) == 1 then
        return true
    else
        return false
    end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- GETPORTEDATA
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.getPorteData(passport)
    local Identity = vRP.Identity(passport)
    if not Identity then
        return false
    end

    local Result = vRP.Query("gunlicense/GetByUser", { Passport = passport })
    local possuiPorte = Creative.verificarPorte(passport)
    local porte = possuiPorte and "Possui" or "Não possui"

    local data = "00/00/0000"
    if possuiPorte and Result[1] and Result[1].date then
        data = string.match(Result[1].date, "(%d%d/%d%d/%d%d%d%d)")
    end

    return {
        nome = Identity.name .. ' ' .. Identity.name2,
        serial = Identity.serial,
        age = Identity.age,
        porte = porte,
        data = data
    }
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- REGISTERCOMMAND
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterCommand(Config.ComandoVerPorte, function(source)
    local Passport = vRP.Passport(source)
    local dados = Creative.getPorteData(Passport)
    if dados then
        TriggerClientEvent("Night_Porte:abrirPorte", source, false, dados)
    end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- REGISTERCOMMAND
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterCommand(Config.ComandoVerificarPortePolicia, function(source, args)
    local Passport = vRP.Passport(source)

    if not vRP.HasService(Passport, Config.PermissaoVerPorte) then
        TriggerClientEvent("Notify", source, "vermelho", "Você não possui permissão para checar porte de arma.", 5000)
        return
    end

    local OtherID = tonumber(args[1])
    local OtherSource = vRP.Source(OtherID)
    local OtherPassport = vRP.Passport(OtherSource)

    local dados = Creative.getDadosPorte(true, OtherPassport)
    if dados then
        TriggerClientEvent("Night_Porte:abrirPorte", source, true, dados, OtherID)
    end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- GETDADOSPORTE
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.getDadosPorte(pVerPortePolicia, Passport)
    if pVerPortePolicia then
        return Creative.getPorteData(Passport)
    end

    local source = source
    local SelfPassport = vRP.Passport(source)
    return Creative.getPorteData(SelfPassport)
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- RESULTADOTESTETEORICO
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.resultadoTesteTeorico(resultado)
    local source = source
    local Passport = vRP.Passport(source)

    if resultado then
        vRP.GenerateItem(Passport, Config.ItemLaudoProvaTeorica.item, 1, true)
        TriggerClientEvent("Notify", source, "verde", "Você recebeu um Laudo do teste teórico.", 5000)
        TriggerClientEvent("Notify", source, "verde", "Você foi Aprovado no teste teórico.", 5000)
    else
        TriggerClientEvent("Notify", source, "vermelho", "Você foi Reprovado no teste teórico.", 5000)
    end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- VERIFICARTESTETEORICO
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.verificarTesteTeorico()
    local source = source
    local Passport = vRP.Passport(source)

    if Creative.verificarPorte(Passport) then
        TriggerClientEvent("Notify", source, "vermelho", "Você já possui porte.", 5000)
        TriggerClientEvent("Night_Porte:Close", source)
        return
    end

    if vRP.PaymentFull(Passport, parseInt(Config.PrecoProvaTeorica)) then
        vCLIENT.iniciarTesteTeorico(source)
    else
        TriggerClientEvent("Notify", source, "vermelho", "Dinheiro insuficiente.", 5000)
        TriggerClientEvent("Night_Porte:Close", source)
    end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- VERIFICARTESTEPRATICO
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.verificarTestePratico()
    local source = source
    local Passport = vRP.Passport(source)

    if Creative.verificarPorte(Passport) then
        TriggerClientEvent("Notify", source, "vermelho", "Você já possui porte.", 5000)
        TriggerClientEvent("Night_Porte:Close", source)
        return
    end

    if vRP.ConsultItem(Passport, Config.ItemLaudoProvaTeorica.item, 1) then
        if vRP.PaymentFull(Passport, parseInt(Config.PrecoProvaPratica)) then
            vRP.TakeItem(Passport, Config.ItemLaudoProvaTeorica.item, 1, true)
            vCLIENT.realizarTestePratico(source)
        else
            TriggerClientEvent("Notify", source, "vermelho", "Dinheiro insuficiente.", 5000)
            TriggerClientEvent("Night_Porte:Close", source)
        end
    else
        TriggerClientEvent("Notify", source, "vermelho", "Você não possui um Laudo Teórico!", 5000)
        TriggerClientEvent("Night_Porte:Close", source)
    end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- RESULTADOTESTEPRATICO
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.resultadoTestePratico(resultado)
    local source = source
    local Passport = vRP.Passport(source)

    if resultado then
        vRP.GenerateItem(Passport, Config.ItemLaudoProvaPratica.item, 1, true)
        TriggerClientEvent("Notify", source, "verde", "Você recebeu um laudo do teste prático.", 5000)
        TriggerClientEvent("Notify", source, "verde", "Você foi Aprovado no teste prático.", 5000)
    else
        TriggerClientEvent("Notify", source, "vermelho", "Você foi Reprovado no teste prático.", 5000)
    end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- PLAYERDROPPED
-----------------------------------------------------------------------------------------------------------------------------------------
AddEventHandler("playerDropped", function()
    local source = source
    local Passport = vRP.Passport(source)

    if Creative.inPorte[tostring(Passport)] then
        local data = vRP.Datatable(Passport)
        if data then
            data.weapons = {}
        end

        Creative.inPorte[tostring(Passport)] = nil
    end
end)