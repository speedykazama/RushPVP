-----------------------------------------------------------------------------------------------------------------------------------------
-- VRP
-----------------------------------------------------------------------------------------------------------------------------------------
local Tunnel = module("vrp", "lib/Tunnel")
local Proxy = module("vrp", "lib/Proxy")
local Tools = module("vrp", "lib/Tools")
vRP = Proxy.getInterface("vRP")
-----------------------------------------------------------------------------------------------------------------------------------------
-- CONNECTION
-----------------------------------------------------------------------------------------------------------------------------------------
Creative = {}
Tunnel.bindInterface("Night_Porte", Creative)
Proxy.addInterface("Night_Porte", Creative)
vSERVER = Tunnel.getInterface("Night_Porte")
-------------------------------------------------------------------------------------------------
-- TARGET
-------------------------------------------------------------------------------------------------
CreateThread(function()
    exports["target"]:AddCircleZone("Porte", Config.LocalTestes, 1.0, {
        name = "Porte",
        heading = 3374176
    }, {
        Distance = 1.5,
        options = {
            {
                event = "provateorica:Init",
                label = "Aula Teórica",
                tunnel = "client"
            }, {
                event = "provapratica:Init",
                label = "Aula Prática",
                tunnel = "client"
            }
        }
    })
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- PROVATEORICA:INIT
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("provateorica:Init")
AddEventHandler("provateorica:Init", function()
    vRP.CreateObjects("amb@code_human_in_bus_passenger_idles@female@tablet@idle_a", "idle_b", "prop_cs_tablet", 49, 28422)
    SetNuiFocus(true, true)
    SendNUIMessage({
        type = "abrirQuizPorte",
        valor = Config.PrecoProvaTeorica
    })
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- PROVAPRATICA:INIT
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("provapratica:Init")
AddEventHandler("provapratica:Init", function()
    vRP.CreateObjects("amb@code_human_in_bus_passenger_idles@female@tablet@idle_a", "idle_b", "prop_cs_tablet", 49, 28422)
    SetNuiFocus(true, true)
    SendNUIMessage({
        type = "abrirPraticaPorte",
        valor = Config.PrecoProvaPratica
    })
end)
-------------------------------------------------------------------------------------------------
-- CLOSE
-------------------------------------------------------------------------------------------------
RegisterNetEvent("Night_Porte:Close")
AddEventHandler("Night_Porte:Close", function()
    SetNuiFocus(false, false)
    SendNUIMessage({ type = 'fecharQuizPorte' })
    vRP.stopAnim(false)
    vRP.Destroy()
    ClearPedTasks(PlayerPedId())
end)
-------------------------------------------------------------------------------------------------
-- BUTTONCLICK
-------------------------------------------------------------------------------------------------
RegisterNUICallback("ButtonClick", function(data, cb)
    if data.action == "fecharQuizPorte" then 
        TriggerEvent("Night_Porte:Close") 
    end
    if data.action == "iniciar-teste-teorico" then
        vSERVER.verificarTesteTeorico()
    end
    if data.action == "iniciar-teste-pratico" then
        vSERVER.verificarTestePratico()
    end
    if data.action == "resultado-teste-teorico" then
        vSERVER.resultadoTesteTeorico(data.resultado)
    end
end)
-------------------------------------------------------------------------------------------------
-- INICIARTESTETEORICO
-------------------------------------------------------------------------------------------------
function Creative.iniciarTesteTeorico()
    SetNuiFocus(true, true)
    SendNUIMessage({type = "iniciar-teste-teorico"})
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- NIGHT_PORTE:ABRIRPORTE
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("Night_Porte:abrirPorte")
AddEventHandler("Night_Porte:abrirPorte", function(pVerPortePolicia, dados)
    vRP.CreateObjects("cellphone@", "cellphone_horizontal_intro", "prop_police_phone", 50, 28422)
    SetNuiFocus(true, true)
    SendNUIMessage({ type = "ver-porte", dados = dados })
end)
-------------------------------------------------------------------------------------------------
-- RANDOM
-------------------------------------------------------------------------------------------------
function random(tb)
    local keys = {}
    for k in pairs(tb) do table.insert(keys, k) end
    return tb[keys[math.random(1, #keys)]]
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- VARIABLES
-----------------------------------------------------------------------------------------------------------------------------------------
local score = 0
local sequenceShots = {}
-----------------------------------------------------------------------------------------------------------------------------------------
-- ISMALE
-----------------------------------------------------------------------------------------------------------------------------------------
function isMale()
    local hashSkinMale = GetHashKey("mp_m_freemode_01")
    local hashSkinFemale = GetHashKey("mp_f_freemode_01")

    if GetEntityModel(PlayerPedId()) == hashSkinMale then
        return true
    elseif GetEntityModel(PlayerPedId()) == hashSkinFemale then
        return false
    end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- REQANIMDICT
-----------------------------------------------------------------------------------------------------------------------------------------
function ReqAnimDict(animDict)
    RequestAnimDict(animDict)
    while not HasAnimDictLoaded(animDict) do Citizen.Wait(0) end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- TARGETSPAWN
-----------------------------------------------------------------------------------------------------------------------------------------
function TargetSpawn(x, y, z, a, v)
    local model = GetHashKey("prop_range_target_01")
    local shot = 0
    RequestModel(model)
    while (not HasModelLoaded(model)) do Wait(1) end
    local obj = CreateObject(model, x, y, z, true, true, true)
    SetEntityProofs(obj, false, true, false, false, false, false, 0, false)
    SetEntityRotation(obj, GetEntityRotation(obj) + vector3(-90, 0.0, 0))
    local r = -90
    PlaySoundFrontend(-1, "SHOOTING_RANGE_ROUND_OVER", "HUD_AWARDS", 1)
    while r ~= 0 do
        SetEntityRotation(obj, GetEntityRotation(obj) + vector3(9, 0.0, 0))
        r = r + 9
        Wait(1)
    end
    DeleteEntity(obj)
    Citizen.Wait(1)
    local obj = CreateObject(model, x, y, z, true, true, true)
    local fin = 0
    while shot < a do
        Citizen.Wait(0)
        fin = fin + 1
        if IsPedShooting(GetPlayerPed(-1)) then
            Wait(100)
            if fin > v then
                PlaySoundFrontend(-1, "CONFIRM_BEEP", "HUD_MINI_GAME_SOUNDSET", 1)
                shot = shot + 100
                table.insert(sequenceShots, false)
            elseif HasEntityBeenDamagedByWeapon(obj, 0, 2) then
                PlaySoundFrontend(-1, "HACKING_SUCCESS", 0, 1)
                shot = shot + 1
                score = score + 1
                table.insert(sequenceShots, true)
                ClearEntityLastDamageEntity(obj)
            elseif not HasEntityBeenDamagedByWeapon(obj, 0, 2) then
                PlaySoundFrontend(-1, "CONFIRM_BEEP", "HUD_MINI_GAME_SOUNDSET", 1)
                shot = shot + 1
                table.insert(sequenceShots, false)
            end
        elseif fin > v then
            PlaySoundFrontend(-1, "CONFIRM_BEEP", "HUD_MINI_GAME_SOUNDSET", 1)
            shot = shot + 100
            table.insert(sequenceShots, false)
        end
    end
    while r ~= -90 do
        SetEntityRotation(obj, GetEntityRotation(obj) - vector3(5, 0.0, 0))
        r = r - 5
        Wait(1)
    end
    DeleteEntity(obj)
    SetModelAsNoLongerNeeded(model)
end
-------------------------------------------------------------------------------------------------
-- REALIZARTESTEPRATICO
-------------------------------------------------------------------------------------------------
function Creative.realizarTestePratico()
    TriggerEvent("Night_Porte:Close") 
    vSERVER.setPlayerStand(PlayerPedId())
    vSERVER.setInPorte(true)
    SetPlayerControl(PlayerId(), true)

    local ped = GetPlayerPed(-1)
    local coords = GetEntityCoords(ped)
    score = 0
    SetNuiFocus(false, false)
    Citizen.Wait(400)

    -- FADE OUT no início
    DoScreenFadeOut(2000)
    Citizen.Wait(2000)

    -- Aplicar roupas de início se configurado
    if Config.UsarOculosEAbafador then
        local sexo = isMale() and "Male" or "Female"
        local propsInicio = Config.RoupasInicioFim.Inicio[sexo]
        for propId, data in pairs(propsInicio) do
            SetPedPropIndex(ped, propId, data.drawable, data.texture, true)
        end
    end

    -- Dar arma
    GiveWeaponToPed(ped, GetHashKey(Config.ArmaTestePratico), Config.MunicoesArmaTestePratico, true, true)

    -- Posicionar jogador na prova
    SetEntityHeading(ped, Config.ConfiguracaoTestePratico.CoordenadaDeTiro.h)
    SetEntityCoordsNoOffset(ped, Config.ConfiguracaoTestePratico.CoordenadaDeTiro.x, Config.ConfiguracaoTestePratico.CoordenadaDeTiro.y, Config.ConfiguracaoTestePratico.CoordenadaDeTiro.z, 0)
    FreezeEntityPosition(ped, true)

    -- Animação inicial
    ReqAnimDict("anim@deathmatch_intros@1hmale")
    TaskPlayAnim(ped, "anim@deathmatch_intros@1hmale", "intro_male_1h_d_trevor", 8.0, 5.0, -1, true, 1, 0, 0, 0)

    -- FADE IN para iniciar o teste
    DoScreenFadeIn(2000)
    Citizen.Wait(2000)
    Citizen.Wait(10000)
    ClearPedTasks(ped)
    RemoveAnimDict("anim@deathmatch_intros@1hmale")

    SendNUIMessage({ type = "pistaFria" })

    local x = 1
    while x == 1 do
        Wait(5)
        if IsControlJustPressed(1, 38) then
            sequenceShots = {}
            SetNuiFocus(false, false)
            SendNUIMessage({ type = "pistaQuente" })
            score = 0

            PlaySoundFrontend(-1, "Checkpoint_Hit", "GTAO_FM_Events_Soundset", 0)
            Wait(1000)
            PlaySoundFrontend(-1, "Checkpoint_Hit", "GTAO_FM_Events_Soundset", 0)
            Wait(1000)
            PlaySoundFrontend(-1, "CHECKPOINT_PERFECT", "HUD_MINI_GAME_SOUNDSET", 0)
            Wait(1000)

            for i = 1, 10 do
                local spawn = random(Config.ConfiguracaoTestePratico.CoordenadaAlvos)
                TargetSpawn(spawn.x, spawn.y, spawn.z, 1, 100)
                SendNUIMessage({type = "atualizar-pista", score = sequenceShots})
                Wait(1000)
            end
            x = 2
        end
        if IsControlJustPressed(1, 105) then x = 2 end
    end

    -- FADE OUT no final da prova
    DoScreenFadeOut(2000)
    Wait(4000)

    -- Aplicar roupas finais se configurado
    if Config.UsarOculosEAbafador then
        local sexo = isMale() and "Male" or "Female"
        local propsFim = Config.RoupasInicioFim.Fim[sexo]
        for propId, data in pairs(propsFim) do
            SetPedPropIndex(ped, propId, data.drawable, data.texture, true)
        end
    end

    -- Restaurar jogador
    FreezeEntityPosition(ped, false)
    SetEntityHeading(ped, 180.0)
    SetEntityCoordsNoOffset(ped, coords, 0)

    ReqAnimDict("switch@franklin@chopshop")
    TaskPlayAnim(ped, "switch@franklin@chopshop", "checkshoe", 8.0, 5.0, -1, true, 1, 0, 0, 0)

    SetPedAmmo(ped, GetHashKey(Config.ArmaTestePratico), 0)
    RemoveWeaponFromPed(ped, GetHashKey(Config.ArmaTestePratico))
    SendNUIMessage({ type = "fechar-pista" })

    -- FADE IN final
    DoScreenFadeIn(2000)
    Wait(4000)
    ClearPedTasks(ped)

    vSERVER.setInPorte(false)
    vSERVER.returnPlayerStand()
    local aprovado = score >= Config.ConfiguracaoTestePratico.QuantidaDeAcertosParaPassar
    vSERVER.resultadoTestePratico(aprovado)
end