Config = {}

Config.ComandoVerificarPortePolicia = "vporte"                  -- COMANDO QUE O POLICIAL VAI USAR PARA CHECAR O PORTE DE UM JOGADOR
Config.ComandoVerPorte = "porte"                                -- COMANDO QUE O JOGADOR VAI UTILIZAR PARA VER O STATUS DO SEU PORTE                  

Config.PermissaoVerPorte = "Policia"                            -- PERMISSÃO QUE PODE EXECUTAR O COMANDO PARA VERIFICAR O PORTE DE ARMAS DE OUTROS JOGADORES

Config.PrecoProvaTeorica = 50000                                -- VALOR DA PROVA TEÓRICA
Config.PrecoProvaPratica = 100000                               -- VALOR DA PROVA PRÁTICA

Config.ArmaTestePratico = "WEAPON_GLOCK21"                      -- ARMA UTILIZADA NA PROVA PRÁTICA
Config.MunicoesArmaTestePratico = 100                           -- QUANTIDADE DE MUNIÇÕES QUE VAI SER UTILIZADA NA ARMA

Config.ItemLaudoProvaTeorica = { item = "laudoprovateorica" }   -- ITEM QUE O JOGADOR VAI RECEBER APÓS CONCLUIR A PROVA TEÓRICA
Config.ItemLaudoProvaPratica = { item = "laudoprovapratica" }   -- ITEM QUE O JOGADOR VAI RECEBER APÓS CONCLUIR A PROVA PRÁTICA

Config.LocalTestes = vec3(12.16,-1106.54,29.79)                 -- COORDENADA AONDE SE INICIA OS TESTES

Config.ConfiguracaoTestePratico = { 
    QuantidaDeAcertosParaPassar = 8,                            -- QUANTIDADE DE ALVOS QUE O JOGADOR PRECISA ACERTAR PARA SER APROVADO NA PROVA PRÁTICA (MÁXIMO 10)
    CoordenadaDeTiro = vec4(13.61, -1097.26, 29.83, 340.15),    -- COORDENADA AONDE O JOGADOR VAI SPAWNAR NA PROVA PRÁTICA
    CoordenadaAlvos = {                                         -- COORDENADAS DOS ALVOS QUE APARECEM DURANTE A PROVA PRÁTICA
        vec3(19.31, -1069.66, 29.84), vec3(22.15, -1070.59, 29.84),
        vec3(25.04, -1071.73, 29.84), vec3(13.34, -1089.01, 29.84),
        vec3(16.22, -1089.92, 29.84), vec3(19.01, -1091.02, 29.84),
        vec3(23.91, -1083.10, 29.84), vec3(21.23, -1082.14, 29.84),
        vec3(18.37, -1081.13, 29.84), vec3(16.54, -1080.42, 29.84),
        vec3(14.65, -1079.79, 29.84), vec3(14.29, -1089.31, 29.84),
        vec3(17.15, -1090.36, 29.84), vec3(24.80, -1071.70, 29.84),
        vec3(21.27, -1070.30, 29.84), vec3(22.18, -1070.66, 29.84),
        vec3(23.14, -1071.09, 29.84)
    }
}

Config.UsarOculosEAbafador = false                              -- QUANDO INICIAR A PROVA PRÁTICA, EQUIPA UM ÓCULOS E O ABAFADOR
Config.RoupasInicioFim = {
    Inicio = {
        Male = {
            [0] = { drawable = 0, texture = 0 },                -- CHAPÉU/BONÉ
            [1] = { drawable = 15, texture = 0 }                -- ÓCULOS
        },
        Female = {
            [0] = { drawable = 0, texture = 0 },                -- CHAPÉU/BONÉ
            [1] = { drawable = 25, texture = 0 }                -- ÓCULOS
        }
    },
    Fim = {
        Male = {
            [0] = { drawable = 8, texture = 0 },                -- CHAPÉU/BONÉ
            [1] = { drawable = 0, texture = 0 }                 -- ÓCULOS
        },
        Female = {
            [0] = { drawable = 0, texture = 0 },                -- CHAPÉU/BONÉ
            [1] = { drawable = 57, texture = 0 }                -- ÓCULOS
        }
    }
}