var provaAtual = null,
respostaSelecionada = null;

$(function () {
    provaAtual = createProva();

    window.addEventListener('message', function (event) {
        if (event.data.type === 'abrirQuizPorte') {
            $('.home-box').fadeIn();
            $('#valor-teste').html(event.data.valor);
        }
        
        if (event.data.type === 'abrirPraticaPorte') {
            $('.teste-pratico-box').fadeIn();
            $('#valor-teste-pratico').html(event.data.valor);
            
            if (event.data.laudo) {
                $('#necessario-laudo').fadeIn();
            } else {
                $('#necessario-laudo').fadeOut();
            }
        }

        if (event.data.type === 'ver-porte') {
            setDadosPorte(event.data.dados);
            $('.exibe-porte').fadeIn();
        }

        if (event.data.type === 'iniciar-teste-teorico') {
            $('.quiz-box').fadeIn();
            provaAtual.iniciarProva();
        }

        if (event.data.type === 'fechar-pista') {
            $('.div-pista-quente').fadeOut();
        }

        if (event.data.type === 'pistaFria') {
            $('.shots span').removeClass('acertou errou');
            $('.div-pista-quente').fadeIn();
            $('.div-pista-quente .titlepista').html('PISTA FRIA');
            $('.div-pista-quente .textpista').fadeIn();
        }

        if (event.data.type === 'pistaQuente') {
            $('.shots span').removeClass('acertou errou');
            $('.div-pista-quente .titlepista').html('PISTA QUENTE');
            $('.div-pista-quente .textpista').fadeOut();
        }

        if (event.data.type === 'atualizar-pista') {
            atualizarPista(event.data.score);
        }

        if (event.data.type === 'fecharQuizPorte') {
            closeAllScrens();
        }
    });

    document.onkeyup = function (event) {
        if (event.which === 27) {
            sendData('ButtonClick', { action: 'fecharQuizPorte' }, false);
        }
    };
});

function atualizarPista(scores) {
    let acertos = 0;
    let erros = 0;

    scores.forEach(function (score, index) {
        $('.shots .' + (index + 1))
            .removeClass('acertou')
            .removeClass('errou')
            .addClass(score ? 'acertou' : 'errou');

        if (score) {
            acertos++;
        } else {
            erros++;
        }
    });

    $('#acertos').text(acertos);
    $('#erros').text(erros);
    let precisao = scores.length > 0 ? Math.round((acertos / scores.length) * 100) : 0;
    $('#precisao').text(precisao + '%');
}

function setDadosPorte(dadosPorte) {
    $('.nome-porte').text(dadosPorte.nome);
    $('.info-porte').text(dadosPorte.porte);
    $('.serial-porte').text(dadosPorte.serial);
    $('.age-porte').text(dadosPorte.age);
    $('.data-porte').text(dadosPorte.data);
}

$('#iniciar-prova').click(function () {
    closeAllScrens();
    sendData('ButtonClick', { action: 'iniciar-teste-teorico' }, false);
});

$('#iniciar-teste-pratico').click(function () {
    closeAllScrens();
    sendData('ButtonClick', { action: 'iniciar-teste-pratico' }, false);
});

$('#inicio').click(function () {
    closeAllScrens();
    $('.home-box').fadeIn();
});

$('#fechar').click(function () {
    closeAllScrens();
    sendData('ButtonClick', { action: 'fecharQuizPorte' }, false);
});

$('#responder').click(function () {
    if (respostaSelecionada != null) {
        provaAtual.verificarReposta(respostaSelecionada);
    }
});

function closeAllScrens() {
    $('.exibe-porte').fadeOut();
    $('.div-pista-quente').fadeOut();
    
    var elements = ['home-box', 'quiz-box', 'result-box', 'teste-pratico-box'];
    elements.forEach(function (element) {
        $('.' + element).css('display', 'none');
    });
}

function createProva() {
    var prova = {
        gerarQuestoesAleatoriamente() {
            var shuffledQuestions = perguntas.sort(() => Math.random() - 0.5);
            shuffledQuestions.forEach(function (questao) {
                questao.opcoes = questao.opcoes.sort(() => Math.random() - 0.5);
                prova.questoes.push(questao);
            });
            prova.totalQuestoes = prova.questoes.length;
        },
        clearQuestion() {
            $('.option-container').empty();
            $('.question-text').html('');
        },
        iniciarProva() {
            prova.questoes = [];
            prova.totalQuestoes = 0;
            prova.acertos = 0;
            prova.erros = 0;
            prova.questaoAtual = 0;
            prova.acertosErros = [];
            $('.answers-indicator').empty();
            prova.gerarQuestoesAleatoriamente();
            prova.gerarProximaQuestao();
        },
        gerarProximaQuestao() {
            prova.clearQuestion();
            var questaoAtual = prova.questoes[prova.questaoAtual];
            $('#total-question').html('' + prova.totalQuestoes);
            $('#num-question').html('' + (prova.questaoAtual + 1));
            $('.question-text').html('' + questaoAtual.pergunta);
            
            questaoAtual.opcoes.forEach(function (opcao) {
                $('.option-container').append(
                    '<div class="option" data-value="' + opcao.index + '">' + opcao.text + '</div>'
                );
            });

            $('.option').click(function () {
                $('.option').removeClass('option-selected');
                respostaSelecionada = $(this).data('value');
                $(this).addClass('option-selected');
            });
        },
        atualizarCorrecaoProva(correto) {
            if (correto) {
                prova.acertos++;
            } else {
                prova.erros++;
            }
            prova.acertosErros.push(correto);
            $('.answers-indicator').empty();
            prova.acertosErros.forEach(function (acerto) {
                if (acerto) {
                    $('.answers-indicator').append('<div class="green"></div>');
                } else {
                    $('.answers-indicator').append('<div class="red"></div>');
                }
            });
        },
        verificarReposta(resposta) {
            var questaoAtual = prova.questoes[prova.questaoAtual];
            prova.atualizarCorrecaoProva(questaoAtual.resposta == resposta);

            if (prova.questaoAtual == prova.totalQuestoes - 1) {
                closeAllScrens();
                prova.resultado();
            } else {
                prova.questaoAtual++;
                respostaSelecionada = null;
                prova.gerarProximaQuestao();
            }
        },
        resultado() {
            $('.total-question').html('' + prova.totalQuestoes);
            $('.total-question-correct').html('' + prova.acertos);
            $('.total-question-error').html('' + prova.erros);
            $('.total-question-percent').html(
                (prova.acertos * 100) / prova.totalQuestoes + '%'
            );
            $('.result-box').fadeIn();
            var passou = (prova.acertos * 100) / prova.totalQuestoes > 80;
            sendData('ButtonClick', { action: 'resultado-teste-teorico', resultado: passou }, false);
        }
    };
    return prova;
}

function sendData(action, data) {
    $.post('http://Night_Porte/' + action, JSON.stringify(data), function (response) {});
}