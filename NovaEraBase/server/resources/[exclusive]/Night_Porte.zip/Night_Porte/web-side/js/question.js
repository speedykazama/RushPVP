const perguntas = [
  {
    pergunta: "Qual é a idade mínima legal para possuir uma arma de fogo?",
    opcoes: [
      { index: 0, text: "30" },
      { index: 1, text: "21" },
      { index: 2, text: "27" },
      { index: 3, text: "17" },
    ],
    resposta: 1,
  },

  {
    pergunta: "Em qual circustancia você pode usar a arma?",
    opcoes: [
      { index: 0, text: "À vontade" },
      { index: 1, text: "Em legítima defesa" },
      { index: 2, text: "Para expressar raiva" },
      { index: 3, text: "Para efetuar roubos" },
    ],
    resposta: 1,
  },

  {
    pergunta: "Qual arma você pode utilizar com o porte?",
    opcoes: [
      { index: 0, text: "Apenas pistolas .45" },
      { index: 1, text: "Apenas Rifles 7.62" },
      { index: 2, text: "Todo tipo de armamento" },
      { index: 3, text: "Apenas Fuzil 5.56" },
    ],
    resposta: 0,
  },

  {
    pergunta: "Qual é a principal finalidade do porte de armas?",
    opcoes: [
      { index: 0, text: "Facilitar a compra de armas" },
      { index: 1, text: "Garantir o anonimato dos proprietários" },
      { index: 2, text: "Garantir a defesa pessoal" },
      { index: 3, text: "Monitorar atividades esportivas" },
    ],
    resposta: 2,
  },

  {
    pergunta: "Qual é o principal objetivo do treinamento para porte de armas?",
    opcoes: [
      { index: 0, text: "Mostrar poder para a comunidade" },
      { index: 1, text: "Usar armas em esportes radicais" },
      { index: 2, text: "Garantir segurança e uso responsável" },
      { index: 3, text: "Aprender a atirar em alvos de pessoas" },
    ],
    resposta: 2,
  },

  {
    pergunta: "É permitido portar arma em locais públicos sem justificativa?",
    opcoes: [
      { index: 0, text: "Sim" },
      { index: 1, text: "Não" },
      { index: 2, text: "Apenas em festas" },
      { index: 3, text: "Apenas com registro policial" },
    ],
    resposta: 1,
  },

  {
    pergunta: "Qual documento é necessário para portar uma arma legalmente?",
    opcoes: [
      { index: 0, text: "Título de eleitor" },
      { index: 1, text: "Passaporte" },
      { index: 2, text: "Porte de arma" },
      { index: 3, text: "CNH" },
    ],
    resposta: 2,
  },

  {
    pergunta: "Por que você quer tirar o porte?",
    opcoes: [
      { index: 0, text: "Matar todos" },
      { index: 1, text: "Ficar atirando à toa" },
      { index: 2, text: "Se defender" },
      { index: 3, text: "Assaltar pessoas" },
    ],
    resposta: 2,
  },

  {
    pergunta: "O porte de armas é obrigatório para cidadãos comuns?",
    opcoes: [
      { index: 0, text: "Sim" },
      { index: 1, text: "Não" },
      { index: 2, text: "Apenas em cidades grandes" },
      { index: 3, text: "Apenas para maiores de 18 anos" },
    ],
    resposta: 1,
  },

  {
    pergunta: "Qual orgão regula o porte de armas no Brasil?",
    opcoes: [
      { index: 0, text: "Detran" },
      { index: 1, text: "Exército Brasileiro" },
      { index: 2, text: "Polícia Militar" },
      { index: 3, text: "IBAMA" },
    ],
    resposta: 1,
  },
];