Elevators = {
    { -- Hospital
        { ['Coord'] = vector4(-418.91,-344.75,24.23,107.72), ['CanUseVehicle'] = false, ['Name'] = '<i class="fa-solid fa-circle-sort-up"></i><br> -1' },
        { ['Coord'] = vector4(-436.03,-359.73,34.95,354.34), ['CanUseVehicle'] = false, ['Name'] = '<i class="fa-solid fa-circle-sort-down"></i><br> 0' },
        { ['Coord'] = vector4(-439.8,-335.77,78.3,82.21), ['CanUseVehicle'] = false, ['Name'] = '<i class="fa-solid fa-circle-sort-down"></i><br> H' }
    },
    { -- Mecânica Red Line
        { ['Coord'] = vector4(2732.43,3509.03,55.25,150.24), ['CanUseVehicle'] = false, ['Name'] = '<i class="fa-solid fa-circle-sort-up"></i><br> 0' },
        { ['Coord'] = vector4(2727.28,3513.39,61.52,246.62), ['CanUseVehicle'] = false, ['Name'] = '<i class="fa-solid fa-circle-sort-down"></i><br> 1' }
    },
    { -- Policia Civil
        { ['Coord'] = vector4(-311.22,-1048.57,27.21,70.87), ['CanUseVehicle'] = false, ['Name'] = '<i class="fa-solid fa-circle-sort-up"></i><br> 0' },
        { ['Coord'] = vector4(-334.37,-1051.04,73.89,161.58), ['CanUseVehicle'] = false, ['Name'] = '<i class="fa-solid fa-circle-sort-down"></i><br> H' }
    },
    { -- PRF
        { ['Coord'] = vector4(2624.87,5349.84,46.72,104.89), ['CanUseVehicle'] = false, ['Name'] = '<i class="fa-solid fa-circle-sort-up"></i><br> 0' },
        { ['Coord'] = vector4(2622.27,5350.2,58.47,286.3), ['CanUseVehicle'] = false, ['Name'] = '<i class="fa-solid fa-circle-sort-down"></i><br> H' }
    },
    { -- BOPE
        { ['Coord'] = vector4(2504.47,-342.0,94.09,136.07), ['CanUseVehicle'] = false, ['Name'] = '<i class="fa-solid fa-circle-sort-up"></i><br> 0' },
        { ['Coord'] = vector4(2504.37,-342.09,101.89,133.23), ['CanUseVehicle'] = false, ['Name'] = '<i class="fa-solid fa-circle-sort-down"></i><br> 3' },
        { ['Coord'] = vector4(2504.44,-342.02,105.68,133.23), ['CanUseVehicle'] = false, ['Name'] = '<i class="fa-solid fa-circle-sort-down"></i><br> 4' },
        { ['Coord'] = vector4(2507.61,-336.47,115.59,133.23), ['CanUseVehicle'] = false, ['Name'] = '<i class="fa-solid fa-circle-sort-down"></i><br> H' }
    },
}