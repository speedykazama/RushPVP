fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'Maralto'
description 'Rework: Nostradamus'
version '1.0.0'

client_script { 'client/*.lua', 'config.lua' }

ui_page 'web/index.html'

files { 'web/*' }