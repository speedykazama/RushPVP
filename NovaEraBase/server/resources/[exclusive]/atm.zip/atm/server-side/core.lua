-----------------------------------------------------------------------------------------------------------------------------------------
-- VRP
-----------------------------------------------------------------------------------------------------------------------------------------
local Tunnel = module("vrp","lib/Tunnel")
local Proxy = module("vrp","lib/Proxy")
vRP = Proxy.getInterface("vRP")
-----------------------------------------------------------------------------------------------------------------------------------------
-- CONNECTION
-----------------------------------------------------------------------------------------------------------------------------------------
Creative = {}
Tunnel.bindInterface("atm",Creative)
vCLIENT = Tunnel.getInterface("atm")
-----------------------------------------------------------------------------------------------------------------------------------------
-- VARIABLES
-----------------------------------------------------------------------------------------------------------------------------------------
local Active = {}
-----------------------------------------------------------------------------------------------------------------------------------------
-- BANK
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.Bank()
	local Source = source
	local Passport = vRP.Passport(Source)
	if Passport then
		for _, Value in pairs(vRP.Inventory(Passport)) do
			if SplitOne(Value["item"]) == "debitcard" then
				local CardPassport = parseInt(SplitTwo(Value["item"]))
				if Passport == CardPassport then
					local Identity = vRP.Identity(CardPassport)
					return {
						Password = Identity.cardpassword,
						Balance = Identity.bank
					}
				end
			end
		end

		TriggerClientEvent("Notify",Source,"amarelo","Precisa de um <b>Cartão de Débito</b>.",5000)
	end
	return false
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- DEPOSIT
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.Deposit(amount)
	local source = source
	local Passport = vRP.Passport(source)
	if Passport and Active[Passport] == nil then
		if parseInt(amount) > 0 then
			Active[Passport] = true
			if vRP.PaymentMoney(Passport,amount) then
				vRP.GiveBank(Passport, amount)
			end
			Active[Passport] = nil
		end
	end
	return vRP.Identity(Passport).bank
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- WITHDRAW
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.Withdraw(amount)
	local source = source
	local Passport = vRP.Passport(source)
	if Passport and Active[Passport] == nil  then
		if parseInt(amount) > 0 then
			Active[Passport] = true
			vRP.WithdrawCash(Passport, amount)
			Active[Passport] = nil
		end
	end
	return vRP.Identity(Passport).bank
end