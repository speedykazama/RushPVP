local Tunnel = module("vrp","lib/Tunnel")
local Proxy = module("vrp","lib/Proxy")
local Tools = module("vrp","lib/Tools")
vRP = Proxy.getInterface("vRP")

src = {}
Tunnel.bindInterface("Night_Rewards", src)
vSERVER = Tunnel.getInterface("Night_Rewards")

local uiOpen = false
local userData = {
    lastClaimed = 0,
    canClaim = false,
}

function TimeToDate(time)
	local day = math.floor(time / 86400)
	local hour = math.floor(time / 60 / 60) % 24
	local minute = math.floor(time / 60) % 60
	local second = time % 60

	return day, hour, minute, second
end

function DateToTime(day, hour, minute, second)
	return day * 86400 + hour * 3600 + minute * 60 + second
end

local timeToClaim = DateToTime(0, Config.TempoPararesgatar['horas'], Config.TempoPararesgatar['minutos'], Config.TempoPararesgatar['segundos']) 
local timeToClaimVip = DateToTime(0, Config.TempoPararesgatarVip['horas'], Config.TempoPararesgatarVip['minutos'], Config.TempoPararesgatarVip['segundos']) 

local function loadData(data)
    for k, v in pairs(data) do
        userData[k] = v
        SendNUIMessage(
            { 
                type = "dailyBonus",
                action = "setData",
                data = k, 
                value = v
            }
        )
    end
end

local function saveData()
    SetResourceKvp('night', json.encode(userData))
end

local function initializeUi()
    local data = GetResourceKvpString('night')
    if data then loadData(json.decode(data)) end
    
    Citizen.Wait(500)
    
    local rouletteData = Config.Recompensas
    local finalRouletteData = {}

    for k, v in pairs(rouletteData) do
        table.insert(finalRouletteData, rouletteData[k])
    end

    SendNUIMessage(
        {
            type = "dailyBonus",
            action = "initialize",
            data = userData,
            rouletteData = json.encode(finalRouletteData),
            probability = Config.Raridades,
            animationDuration = Config.TempoAnimacao,
        }
    )

end

RegisterNetEvent('night:openDailyBonus')
AddEventHandler('night:openDailyBonus', function()
    if not uiOpen then
        if Config.Animacao then
            vRP.createObjects("amb@code_human_in_bus_passenger_idles@female@tablet@idle_a","idle_a","prop_cs_tablet",49,28422,-0.05,0.0,0.0,0.0,0.0, 0.0) -- CREATIVE NETWORK
        end

        SendNUIMessage({
            type = "dailyBonus",
            action = "open"
        })

        SetNuiFocus(true, true)
        uiOpen = true
    end
end)


AddEventHandler('onClientResourceStart', function (resourceName)
    if(GetCurrentResourceName() ~= resourceName) then return end

    Wait(1000)

    initializeUi()
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(1000)

    if vSERVER.permissao() then 
        if not userData.canClaim then
            local year, month, day, hour, minute, second = GetLocalTime()
            local currentTime = DateToTime(day, hour, minute, second)
            local lastClaimed = userData.lastClaimed
            
            local timeDifference = lastClaimed - currentTime + timeToClaimVip
            local day, hour, minute, second = TimeToDate(timeDifference)

            if timeDifference <= 0 then
                userData.canClaim = true
                SendNUIMessage({
                    type = "dailyBonus",
                    action = "setData",
                    data = 'canClaim',
                    value = true
                })
                saveData()
            else
                local day, hour, minute, second = TimeToDate(timeDifference)
    
                if hour < 10 then hour = '0' .. hour end
                if minute < 10 then minute = '0' .. minute end
                if second < 10 then second = '0' .. second end
    
                SendNUIMessage({
                    type = "dailyBonus",
                    action = "setData",
                    data = 'lastClaimed',
                    value = hour .. ':' .. minute .. ':' .. second
                })
            end
        end

        elseif not userData.canClaim then
            local year, month, day, hour, minute, second = GetLocalTime()
            local currentTime = DateToTime(day, hour, minute, second)
            local lastClaimed = userData.lastClaimed
            
            local timeDifference = lastClaimed - currentTime + timeToClaim
            local day, hour, minute, second = TimeToDate(timeDifference)

            if timeDifference <= 0 then
                userData.canClaim = true
                SendNUIMessage({
                    type = "dailyBonus",
                    action = "setData",
                    data = 'canClaim',
                    value = true
                })
                saveData()
            else
                local day, hour, minute, second = TimeToDate(timeDifference)
    
                if hour < 10 then hour = '0' .. hour end
                if minute < 10 then minute = '0' .. minute end
                if second < 10 then second = '0' .. second end
    
                SendNUIMessage({
                    type = "dailyBonus",
                    action = "setData",
                    data = 'lastClaimed',
                    value = hour .. ':' .. minute .. ':' .. second
                })
            end
        end
    end
end)

RegisterNUICallback('claim', function(data, cb)
    userData.canClaim = false
    local year, month, day, hour, minute, second = GetLocalTime()
    userData.lastClaimed = DateToTime(day, hour, minute, second)
    SendNUIMessage({
        type = "dailyBonus",
        action = "setData",
        data = 'canClaim',
        value = false
    })
    saveData()
end)

RegisterNUICallback('reward', function(data, cb)
    local reward = Config.Recompensas[data.id]
    if reward.type == 'veiculo' then
        TriggerServerEvent('night:giveveiculo', reward.model)
    elseif reward.type == 'item' then
        TriggerServerEvent('night:giveItem', reward.model, reward.quantity)
    elseif reward.type == 'cash' then
        TriggerServerEvent('night:giveCash', reward.model)
    elseif reward.type == 'banco' then
        TriggerServerEvent('night:givebanco', reward.model)
    elseif reward.type == 'arma' then
        TriggerServerEvent('night:givearma', reward.model)
    end
end)

RegisterNUICallback('sell', function(data, cb)
    local reward = Config.Recompensas[data.id].sell
    TriggerServerEvent('night:sellReward', reward)
end)

RegisterNUICallback('close', function(data, cb)
    SetNuiFocus(false, false)
    uiOpen = false
    vRP.removeObjects()
end)


RegisterNetEvent("resetDailyBonusTimer")
AddEventHandler("resetDailyBonusTimer", function()
    userData.canClaim = true
    SendNUIMessage({
        type = "dailyBonus",
        action = "setData",
        data = 'canClaim',
        value = true
    })
    saveData()
end)
