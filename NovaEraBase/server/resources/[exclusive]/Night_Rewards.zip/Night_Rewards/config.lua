Config = {}

Config.Comando = 'bonus'                    -- Comando para abrir o menu

Config.ComandoResetarTempo = 'resetar'      -- Comando para resetar o tempo

Config.Animacao = true                      -- true = com animação, false = sem animação

Config.TempoAnimacao = 15                   -- Tempo para girar a roleta em segundos

Config.TempoPararesgatar = {
    horas = 24,                             -- Horas para resgatar
    minutos = 0,                            -- Minutos para resgatar
    segundos = 0,                           -- Segundos para resgatar
}

Config.TempoPararesgatarVip = {
    horas = 18,                             -- Horas para resgatar
    minutos = 0,                            -- Minutos para resgatar
    segundos = 0,                           -- Segundos para resgatar
}

Config.PermissaoResetarTempo = {            -- Permissões para utilizar o comando de resetar o tempo
    "Admin", "Suporte"
}

Config.PermissaoVip = {                     -- Permissões dos VIPS
	{ perm = "Diamante" },
    { perm = "Platina" },
}

Config.Recompensas = {
    [0] = {
        id = 0,                             -- ID DO RECOMPENSA, COLOCA EM ORDEM CRESCENTE
        type = "veiculo",                   -- TYPE (veiculo,arma,item,banco)
        model = "bmci",                     -- NOME DO ITEM OU VEÍCULO
        rarity = "lendario",                -- RARIDADE DO ITEM (comum,raro,epico,lendario)
        img = '/html/img/m5-comp.png',      -- NOME DA IMAGEM
        name = "BMW M5 F90 2018",           -- NOME QUE VAI APARECER NO PAINEL
        sell = 25000                        -- VALOR DE VENDA DO ITEM
    },
    [1] = {
        id = 1,
        type = "arma",
        model = "WEAPON_COMBATPISTOL",
        rarity = "epico",
        img = '/html/img/combat-pistol.png',
        name = "Combat Pistol",
        sell = 5000
    },
    [2] = {
        id = 2,
        rarity = "raro",
        type = "arma",
        model = "WEAPON_KNUCKLE",
        img = '/html/img/knuckles.webp',
        name = "Soco Inglês",
        sell = 500
    },
    [3] = {
        id = 3,
        rarity = "raro",
        type = "item",
        model = "toolbox",
        img = '/html/img/fix_kit.png',
        name = "Caixa de Ferramentas",
        sell = 500,
        quantity = 1
    },
    [4] = {
        id = 4,
        rarity = "raro",
        type = "banco",
        model = 1000,
        img = '/html/img/creditCard.png',
        name = "$1000 Banco",
        sell = 500
    },
    [5] = {
        id = 5,
        rarity = "comum",
        type = "item",
        model = "bandage",
        img = '/html/img/bandage.png',
        name = "Bandagem",
        sell = 50,
        quantity = 1
    },
    [6] = {
        id = 6,
        rarity = "comum",
        type = "item",
        model = "cola",
        img = '/html/img/cola.png',
        name = "Coca Cola",
        sell = 50,
        quantity = 1
    },
    [7] = {
        id = 7,
        rarity = "comum",
        type = "item",
        model = "dollars",
        img = '/html/img/cash.png',
        name = "$100 Doláres",
        sell = 50,
        quantity = 100
    },
    [8] = {
        id = 8,
        rarity = "comum",
        type = "item",
        model = "medkit",
        img = '/html/img/medikit.png',
        name = "MedKit",
        sell = 50,
        quantity = 1
    },
    [9] = {
        id = 9,
        rarity = "epico",
        type = "veiculo",
        model = "vespa",
        img = '/html/img/vespa.webp',
        name = "Piaggio Vespa 150cc",
        sell = 7500
    },
    [10] = {
        id = 10,
        rarity = "lendario",
        type = "arma",
        model = "WEAPON_SAWNOFFSHOTGUN",
        img = '/html/img/shotgun.webp',
        name = "Pump Shotgun",
        sell = 7500
    },
    [11] = {
        id = 11,
        rarity = "epico",
        type = "item",
        model = "backpack",
        img = '/html/img/louis_vuitton.webp',
        name = "Mochila Louis Vuitton",
        sell = 5000,
        quantity = 1
    },
    [12] = {
        id = 12,
        rarity = "raro",
        type = "item",
        model = "vest",
        img = '/html/img/armor.png',
        name = "Colete",
        sell = 500,
        quantity = 1
    },
    [13] = {
        id = 13,
        rarity = "comum",
        type = "item",
        model = "joint",
        img = '/html/img/joint.png',
        name = "Baseado",
        sell = 50,
        quantity = 1
    },
    [14] = {
        id = 14,
        rarity = "comum",
        type = "item",
        model = "chips",
        img = '/html/img/chips.png',
        name = "Chips",
        sell = 50,
        quantity = 1
    },
}

Config.Raridades = {
    lendario = 0.001,                               
    epico = 0.02,
    raro = 0.20,
    comum = 0.779
}