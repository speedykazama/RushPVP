local config = {}

config.checkpermission = false
config.permissions = {
    "Admin",
}

config.command = {
    name = "pneucds",
    permissions = {
        "Admin"
    }
}

config.prop = "prop_rub_pile_04"

return config