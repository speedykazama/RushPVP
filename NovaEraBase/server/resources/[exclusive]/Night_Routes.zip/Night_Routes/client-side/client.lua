-----------------------------------------------------------------------------------------------------------------------------------------
-- VRP
-----------------------------------------------------------------------------------------------------------------------------------------
local Tunnel = module("vrp","lib/Tunnel")
local Proxy = module("vrp","lib/Proxy")
vRPS = Tunnel.getInterface("vRP")
vRP = Proxy.getInterface("vRP")
-----------------------------------------------------------------------------------------------------------------------------------------
-- CONNECTION
-----------------------------------------------------------------------------------------------------------------------------------------
Creative = {}
Tunnel.bindInterface("Night_Routes",Creative)
vSERVER = Tunnel.getInterface("Night_Routes")
-----------------------------------------------------------------------------------------------------------------------------------------
-- VARIAVEIS
-----------------------------------------------------------------------------------------------------------------------------------------
local InRoute = false
local Blips = nil
local aberto = false
-----------------------------------------------------------------------------------------------------------------------------------------
-- OPEN FARM
-----------------------------------------------------------------------------------------------------------------------------------------
CreateThread(function()
	while true do
		local ped = PlayerPedId()
		local PlayerCoord = GetEntityCoords(ped)
		local sleep = 1000
		for k,v in pairs(Cfg.FarmConfig) do
			local Distance = GetDistanceBetweenCoords(v["StartCoord"][1],v["StartCoord"][2],v["StartCoord"][3],PlayerCoord[1],PlayerCoord[2],PlayerCoord[3])
			if Distance < 3 then
				sleep = 3
				DrawText3D(v["StartCoord"][1],v["StartCoord"][2],v["StartCoord"][3],"~b~[E]~w~ Abrir Farm")
				if Distance < 1 then
					if not aberto then
						if IsControlJustReleased(0, 38) then
							if vSERVER.CheckOrg(k) then
								TransitionToBlurred(1000)
								SetNuiFocus(true,true)
								SendNUIMessage({ action = "openSystem", InRoute = InRoute, farm = k  })
								aberto = true
							end
						end
					end
				end
			end
		end
		Wait(sleep)
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- CLOSESYSTEM
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNUICallback("closeSystem",function(data)
	SetNuiFocus(false,false)
	SendNUIMessage({ action = "closeSystem" })
	TransitionFromBlurred(1000) --DESBORRA
	aberto = false
end)

function Creative.CloseSystem()
	SetNuiFocus(false,false)
	SendNUIMessage({ action = "closeSystem" })
	TransitionFromBlurred(1000) --DESBORRA
	aberto = false
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- INFORMAÇÕES SOBRE O UPGRADWE
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNUICallback("requestinfos",function(data,cb)
	cb(vSERVER.levelIdentify(data.farm))
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- LISTANDO FARMES (DEIXEI COMO EXEMPLO DE SUGESTÃO)
-----------------------------------------------------------------------------------------------------------------------------------------
function listarfarms(farm)
	local OrgName = farm--vSERVER.CheckOrg()
	local Table = {}
	for k,v in pairs(Cfg.FarmConfig[OrgName]["ItemFarm"]) do
		table.insert(Table,{ k = v["ItemSpawn"], name = itemName(v["ItemSpawn"]), Org = OrgName, Route = k, Lvl = vSERVER.GetLvl(OrgName) })
	end

	return Table
end

function listarRotas(farm)
	local OrgName = farm--vSERVER.CheckOrg()
	local Table = {}
	for k,v in pairs(Cfg.FarmCoords[farm]) do
		table.insert(Table,{ nome = k })
	end

	return Table
end

RegisterNUICallback("requestitens",function(data,cb)
	local listarfarms = listarfarms(data.farm)
	local listarrotas = listarRotas(data.farm)
	if listarfarms and listarrotas then
		cb({ listarfarms = listarfarms, listarrotas = listarrotas })
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- UPAR
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNUICallback("upar",function(data)
	if vSERVER.UpgradeFarm(data.farm) then
		SendNUIMessage({ action = "attupar" })
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- ENCERRARROTA
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNUICallback("encerrarrota",function(data)
	if DoesBlipExist(Blips) then
		RemoveBlip(Blips)
		Blips = nil
	end
	Selected = 1
	InRoute = false
	SendNUIMessage({ action = "attupar", InRoute = InRoute })
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- INICIARFARM
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNUICallback("IniciarFarm",function(data)
    if not InRoute then
        if Cfg.FarmCoords[data.org][data.tipo] then
            local Selected = 1
            InRoute = true
            SendNUIMessage({ action = "attupar", InRoute = InRoute })
            if DoesBlipExist(Blips) then
                RemoveBlip(Blips)
                Blips = nil
            end

            Marker(Cfg.FarmCoords[data.org][data.tipo][Selected][1],Cfg.FarmCoords[data.org][data.tipo][Selected][2],Cfg.FarmCoords[data.org][data.tipo][Selected][3],data.rota)

            TriggerEvent("Notify","verde","Rota iniciada.",5000)
            
            while InRoute do
                local TimeDistance = 3
                local Ped = PlayerPedId()
                local Coords = GetEntityCoords(Ped)
                local Vector = vec3(Cfg.FarmCoords[data.org][data.tipo][Selected][1],Cfg.FarmCoords[data.org][data.tipo][Selected][2],Cfg.FarmCoords[data.org][data.tipo][Selected][3])
                local Distance = #(Coords - Vector)

                DrawTxt("~b~PRESSIONE F7 ~w~SE DESEJA FINALIZAR A ROTA",4,0.015,0.10,0.35,255,255,255,180)
                DrawTxt("~b~DIRIJA-SE ~w~ AO LOCAL DEMARCADO ",4,0.015,0.13,0.35,255,255,255,180)
				--DrawTxt("~b~PRESSIONE F7 ~w~SE DESEJA FINALIZAR A ROTA FIXA",4,0.015,0.92,0.35,255,255,255,180)
				--DrawTxt("~b~DIRIJA-SE ~w~ AO LOCAL DEMARCADO ",4,0.015,0.94,0.35,255,255,255,180)
                
                if Distance <= 15.0 then
                    DrawText3D(Cfg.FarmCoords[data.org][data.tipo][Selected][1],Cfg.FarmCoords[data.org][data.tipo][Selected][2],Cfg.FarmCoords[data.org][data.tipo][Selected][3],"~b~[E]~w~ Coletar")
                    DrawMarker(21, Cfg.FarmCoords[data.org][data.tipo][Selected][1],Cfg.FarmCoords[data.org][data.tipo][Selected][2],Cfg.FarmCoords[data.org][data.tipo][Selected][3] - 0.7, 0, 0, 0, 0, 0, 0, 0.3, 0.3, 0.3, 22, 22, 23, 100, false, false, false, true)
                    DrawMarker(27, Cfg.FarmCoords[data.org][data.tipo][Selected][1],Cfg.FarmCoords[data.org][data.tipo][Selected][2],Cfg.FarmCoords[data.org][data.tipo][Selected][3] - 0.95, 0, 0, 0, 0, 0, 0, 0.6, 0.6, 1.0, 22, 22, 23, 100, false, false, false, true)
                end

                if Distance <= 1.0 then
                    if IsControlJustReleased(0, 38) then
                        if IsPedInAnyVehicle(Ped) then
                            TriggerEvent("Notify", "vermelho", "Você precisa sair do veículo para coletar!", 5000)
                        else
                            FreezeEntityPosition(Ped, true)
                            if vSERVER.PaymentCollect(data.org,data.rota,data.nivel) then
                                if Selected >= #Cfg.FarmCoords[data.org][data.tipo] then
                                    Selected = 1
                                    if data.tipo == "aleatoria" then
                                        Selected = math.random(#(Cfg.FarmCoords[data.org][data.tipo][Selected]))
                                    end
                                else
                                    Selected = Selected + 1
                                    if data.tipo == "aleatoria" then
                                        Selected = math.random(#(Cfg.FarmCoords[data.org][data.tipo][Selected]))
                                    end
                                end 
                                RemoveBlip(Blips)
                                Marker(Cfg.FarmCoords[data.org][data.tipo][Selected][1],Cfg.FarmCoords[data.org][data.tipo][Selected][2],Cfg.FarmCoords[data.org][data.tipo][Selected][3],data.rota)
                            end    
                            FreezeEntityPosition(Ped, false)
                        end
                    end
                end

                if IsControlJustReleased(0, 168) then
                    if DoesBlipExist(Blips) then
                        RemoveBlip(Blips)
                        Blips = nil
                    end
                    Selected = 1
                    InRoute = false
                end

                Wait(TimeDistance)
            end
        end
    end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- DRAWTEXT3D
-----------------------------------------------------------------------------------------------------------------------------------------
function DrawText3D(x,y,z,text)
	local onScreen,_x,_y = GetScreenCoordFromWorldCoord(x,y,z)
	if onScreen then
		BeginTextCommandDisplayText("STRING")
		AddTextComponentSubstringKeyboardDisplay(text)
		SetTextColour(255,255,255,150)
		SetTextScale(0.35,0.35)
		SetTextFont(4)
		SetTextCentre(1)
		EndTextCommandDisplayText(_x,_y)
		local width = string.len(text) / 190 * 0.45
		DrawRect(_x,_y + 0.0125,width,0.03,15,15,15,175)
	end
end

function DrawTxt(text,font,x,y,scale,r,g,b,a)
    SetTextFont(font)
    SetTextScale(scale,scale)
    SetTextColour(r,g,b,a)
    SetTextOutline()
    SetTextEntry("STRING")
    AddTextComponentString(text)
    DrawText(x,y)
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- MARKER
-----------------------------------------------------------------------------------------------------------------------------------------
function Marker(x,y,z,Item)
	if DoesBlipExist(Blips) then
		RemoveBlip(Blips)
		Blips = nil
	end

	Blips = AddBlipForCoord(x,y,z)
	SetBlipSprite(Blips,501)
	SetBlipColour(Blips,3)
	SetBlipScale(Blips,0.5)
	SetBlipRoute(Blips,true)
	SetBlipAsShortRange(Blips,true)
	BeginTextCommandSetBlipName("STRING")
	AddTextComponentString("Coletar "..Item)
	EndTextCommandSetBlipName(Blips)
end