Cfg = {}

Cfg.FarmConfig = { 
    ["Maonegra"] = { 
        ["StartCoord"] = {1278.45,68.77,98.12},
        ["PermToAcess"] = "Maonegra",
        ["UpgradeValue"] = {20000,50000,100000, 480000, 890000},
        ["Animation"] = {"amb@prop_human_parking_meter@female@idle_a","idle_a_female"},
        ["AnimDuration"] = 1000,
        ["ItemFarm"] = {
            ["Alumínio"] = {
                ["ItemSpawn"] = "aluminum",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            },
            ["Cobre"] = {
                ["ItemSpawn"] = "copper",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            },
            ["Plastico"] = {
                ["ItemSpawn"] = "plastic",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            },
            ["Vidro"] = {
                ["ItemSpawn"] = "glass",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            },
            ["Borracha"] = {
                ["ItemSpawn"] = "rubber",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            }
        }
    },
    ["Bairro13"] = { 
        ["StartCoord"] = {-2239.5,-163.39,91.44},
        ["PermToAcess"] = "Bairro13",
        ["UpgradeValue"] = {20000,50000,100000, 480000, 890000},
        ["Animation"] = {"amb@prop_human_parking_meter@female@idle_a","idle_a_female"},
        ["AnimDuration"] = 1000,
        ["ItemFarm"] = {
            ["Alumínio"] = {
                ["ItemSpawn"] = "aluminum",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            },
            ["Cobre"] = {
                ["ItemSpawn"] = "copper",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            },
            ["Plastico"] = {
                ["ItemSpawn"] = "plastic",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            },
            ["Vidro"] = {
                ["ItemSpawn"] = "glass",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            },
            ["Borracha"] = {
                ["ItemSpawn"] = "rubber",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            }
        }
    },
    ["Setor13"] = { 
        ["StartCoord"] = {895.43,1984.04,81.5},
        ["PermToAcess"] = "Setor13",
        ["UpgradeValue"] = {20000,50000,100000, 480000, 890000},
        ["Animation"] = {"amb@prop_human_parking_meter@female@idle_a","idle_a_female"},
        ["AnimDuration"] = 1000,
        ["ItemFarm"] = {
            ["Alumínio"] = {
                ["ItemSpawn"] = "aluminum",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            },
            ["Cobre"] = {
                ["ItemSpawn"] = "copper",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            },
            ["Plastico"] = {
                ["ItemSpawn"] = "plastic",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            },
            ["Vidro"] = {
                ["ItemSpawn"] = "glass",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            },
            ["Borracha"] = {
                ["ItemSpawn"] = "rubber",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            }
        }
    },
    ["Grota"] = { 
        ["StartCoord"] = {1369.43,-208.35,158.15},
        ["PermToAcess"] = "Grota",
        ["UpgradeValue"] = {20000,50000,100000, 480000, 890000},
        ["Animation"] = {"amb@prop_human_parking_meter@female@idle_a","idle_a_female"},
        ["AnimDuration"] = 1000,
        ["ItemFarm"] = {
            ["Barra de Chumbo"] = {
                ["ItemSpawn"] = "lead_pure",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            },
            ["Minério de Cobre"] = {
                ["ItemSpawn"] = "copper_pure",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            },
            ["Pólvora"] = {
                ["ItemSpawn"] = "gunpowder",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            }
        }
    },
    ["Chernobyl"] = { 
        ["StartCoord"] = {1863.06,-2245.67,171.75},
        ["PermToAcess"] = "Chernobyl",
        ["UpgradeValue"] = {20000,50000,100000, 480000, 890000},
        ["Animation"] = {"amb@prop_human_parking_meter@female@idle_a","idle_a_female"},
        ["AnimDuration"] = 1000,
        ["ItemFarm"] = {
            ["Barra de Chumbo"] = {
                ["ItemSpawn"] = "lead_pure",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            },
            ["Minério de Cobre"] = {
                ["ItemSpawn"] = "copper_pure",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            },
            ["Pólvora"] = {
                ["ItemSpawn"] = "gunpowder",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            }
        }
    },
    ["Crips"] = { 
        ["StartCoord"] = {2311.42,2644.63,61.62},
        ["PermToAcess"] = "Crips",
        ["UpgradeValue"] = {20000,50000,100000, 480000, 890000},
        ["Animation"] = {"amb@prop_human_parking_meter@female@idle_a","idle_a_female"},
        ["AnimDuration"] = 1000,
        ["ItemFarm"] = {
            ["Barra de Chumbo"] = {
                ["ItemSpawn"] = "lead_pure",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            },
            ["Minério de Cobre"] = {
                ["ItemSpawn"] = "copper_pure",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            },
            ["Pólvora"] = {
                ["ItemSpawn"] = "gunpowder",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            }
        }
    },
    ["Distrito"] = { 
        ["StartCoord"] = {1902.85,0.86,188.89},
        ["PermToAcess"] = "Distrito",
        ["UpgradeValue"] = {20000,50000,100000, 480000, 890000},
        ["Animation"] = {"amb@prop_human_parking_meter@female@idle_a","idle_a_female"},
        ["AnimDuration"] = 1000,
        ["ItemFarm"] = {
            ["Cokebud"] = {
                ["ItemSpawn"] = "cokebud",
                ["ItemAmount"] = {
                    ["Lvl0"] = {1,2},
                    ["Lvl1"] = {2,3},
                    ["Lvl2"] = {3,4},
                    ["Lvl3"] = {4,5},
                    ["Lvl4"] = {5,6},
                    ["Lvl5"] = {6,7}
                }
            },
            ["Ziplock"] = {
                ["ItemSpawn"] = "ziplock",
                ["ItemAmount"] = {
                    ["Lvl0"] = {1,2},
                    ["Lvl1"] = {2,3},
                    ["Lvl2"] = {3,4},
                    ["Lvl3"] = {4,5},
                    ["Lvl4"] = {5,6},
                    ["Lvl5"] = {6,7}
                }
            },
            ["Acetona"] = {
                ["ItemSpawn"] = "acetone",
                ["ItemAmount"] = {
                    ["Lvl0"] = {1,2},
                    ["Lvl1"] = {2,3},
                    ["Lvl2"] = {3,4},
                    ["Lvl3"] = {4,5},
                    ["Lvl4"] = {5,6},
                    ["Lvl5"] = {6,7}
                }
            },
            ["Garrafa"] = {
                ["ItemSpawn"] = "bottle",
                ["ItemAmount"] = {
                    ["Lvl0"] = {1,2},
                    ["Lvl1"] = {2,3},
                    ["Lvl2"] = {3,4},
                    ["Lvl3"] = {4,5},
                    ["Lvl4"] = {5,6},
                    ["Lvl5"] = {6,7}
                }
            },
            ["Solvente"] = {
                ["ItemSpawn"] = "solvent",
                ["ItemAmount"] = {
                    ["Lvl0"] = {1,2},
                    ["Lvl1"] = {2,3},
                    ["Lvl2"] = {3,4},
                    ["Lvl3"] = {4,5},
                    ["Lvl4"] = {5,6},
                    ["Lvl5"] = {6,7}
                }
            },
            ["Vinagre"] = {
                ["ItemSpawn"] = "vinegar",
                ["ItemAmount"] = {
                    ["Lvl0"] = {1,2},
                    ["Lvl1"] = {2,3},
                    ["Lvl2"] = {3,4},
                    ["Lvl3"] = {4,5},
                    ["Lvl4"] = {5,6},
                    ["Lvl5"] = {6,7}
                }
            },
            ["Weedbud"] = {
                ["ItemSpawn"] = "weedbud",
                ["ItemAmount"] = {
                    ["Lvl0"] = {1,2},
                    ["Lvl1"] = {2,3},
                    ["Lvl2"] = {3,4},
                    ["Lvl3"] = {4,5},
                    ["Lvl4"] = {5,6},
                    ["Lvl5"] = {6,7}
                }
            },
            ["Silk"] = {
                ["ItemSpawn"] = "silk",
                ["ItemAmount"] = {
                    ["Lvl0"] = {1,2},
                    ["Lvl1"] = {2,3},
                    ["Lvl2"] = {3,4},
                    ["Lvl3"] = {4,5},
                    ["Lvl4"] = {5,6},
                    ["Lvl5"] = {6,7}
                }
            },
            ["Codeine"] = {
                ["ItemSpawn"] = "codeine",
                ["ItemAmount"] = {
                    ["Lvl0"] = {1,2},
                    ["Lvl1"] = {2,3},
                    ["Lvl2"] = {3,4},
                    ["Lvl3"] = {4,5},
                    ["Lvl4"] = {5,6},
                    ["Lvl5"] = {6,7}
                }
            },
            ["Alcohol"] = {
                ["ItemSpawn"] = "alcohol",
                ["ItemAmount"] = {
                    ["Lvl0"] = {1,2},
                    ["Lvl1"] = {2,3},
                    ["Lvl2"] = {3,4},
                    ["Lvl3"] = {4,5},
                    ["Lvl4"] = {5,6},
                    ["Lvl5"] = {6,7}
                }
            },
            ["Pill"] = {
                ["ItemSpawn"] = "pill",
                ["ItemAmount"] = {
                    ["Lvl0"] = {1,2},
                    ["Lvl1"] = {2,3},
                    ["Lvl2"] = {3,4},
                    ["Lvl3"] = {4,5},
                    ["Lvl4"] = {5,6},
                    ["Lvl5"] = {6,7}
                }
            },
            ["Amphetamine"] = {
                ["ItemSpawn"] = "amphetamine",
                ["ItemAmount"] = {
                    ["Lvl0"] = {1,2},
                    ["Lvl1"] = {2,3},
                    ["Lvl2"] = {3,4},
                    ["Lvl3"] = {4,5},
                    ["Lvl4"] = {5,6},
                    ["Lvl5"] = {6,7}
                }
            },
            ["Jar"] = {
                ["ItemSpawn"] = "jar",
                ["ItemAmount"] = {
                    ["Lvl0"] = {1,2},
                    ["Lvl1"] = {2,3},
                    ["Lvl2"] = {3,4},
                    ["Lvl3"] = {4,5},
                    ["Lvl4"] = {5,6},
                    ["Lvl5"] = {6,7}
                }
            }            
        }
    },    
    ["Dz7"] = { 
        ["StartCoord"] = {2053.42,6480.7,110.45},
        ["PermToAcess"] = "Dz7",
        ["UpgradeValue"] = {20000,50000,100000, 480000, 890000},
        ["Animation"] = {"amb@prop_human_parking_meter@female@idle_a","idle_a_female"},
        ["AnimDuration"] = 1000,
        ["ItemFarm"] = {
            ["Cokebud"] = {
                ["ItemSpawn"] = "cokebud",
                ["ItemAmount"] = {
                    ["Lvl0"] = {1,2},
                    ["Lvl1"] = {2,3},
                    ["Lvl2"] = {3,4},
                    ["Lvl3"] = {4,5},
                    ["Lvl4"] = {5,6},
                    ["Lvl5"] = {6,7}
                }
            },
            ["Ziplock"] = {
                ["ItemSpawn"] = "ziplock",
                ["ItemAmount"] = {
                    ["Lvl0"] = {1,2},
                    ["Lvl1"] = {2,3},
                    ["Lvl2"] = {3,4},
                    ["Lvl3"] = {4,5},
                    ["Lvl4"] = {5,6},
                    ["Lvl5"] = {6,7}
                }
            },
            ["Acetona"] = {
                ["ItemSpawn"] = "acetone",
                ["ItemAmount"] = {
                    ["Lvl0"] = {1,2},
                    ["Lvl1"] = {2,3},
                    ["Lvl2"] = {3,4},
                    ["Lvl3"] = {4,5},
                    ["Lvl4"] = {5,6},
                    ["Lvl5"] = {6,7}
                }
            },
            ["Garrafa"] = {
                ["ItemSpawn"] = "bottle",
                ["ItemAmount"] = {
                    ["Lvl0"] = {1,2},
                    ["Lvl1"] = {2,3},
                    ["Lvl2"] = {3,4},
                    ["Lvl3"] = {4,5},
                    ["Lvl4"] = {5,6},
                    ["Lvl5"] = {6,7}
                }
            },
            ["Solvente"] = {
                ["ItemSpawn"] = "solvent",
                ["ItemAmount"] = {
                    ["Lvl0"] = {1,2},
                    ["Lvl1"] = {2,3},
                    ["Lvl2"] = {3,4},
                    ["Lvl3"] = {4,5},
                    ["Lvl4"] = {5,6},
                    ["Lvl5"] = {6,7}
                }
            },
            ["Vinagre"] = {
                ["ItemSpawn"] = "vinegar",
                ["ItemAmount"] = {
                    ["Lvl0"] = {1,2},
                    ["Lvl1"] = {2,3},
                    ["Lvl2"] = {3,4},
                    ["Lvl3"] = {4,5},
                    ["Lvl4"] = {5,6},
                    ["Lvl5"] = {6,7}
                }
            },
            ["Weedbud"] = {
                ["ItemSpawn"] = "weedbud",
                ["ItemAmount"] = {
                    ["Lvl0"] = {1,2},
                    ["Lvl1"] = {2,3},
                    ["Lvl2"] = {3,4},
                    ["Lvl3"] = {4,5},
                    ["Lvl4"] = {5,6},
                    ["Lvl5"] = {6,7}
                }
            },
            ["Silk"] = {
                ["ItemSpawn"] = "silk",
                ["ItemAmount"] = {
                    ["Lvl0"] = {1,2},
                    ["Lvl1"] = {2,3},
                    ["Lvl2"] = {3,4},
                    ["Lvl3"] = {4,5},
                    ["Lvl4"] = {5,6},
                    ["Lvl5"] = {6,7}
                }
            },
            ["Codeine"] = {
                ["ItemSpawn"] = "codeine",
                ["ItemAmount"] = {
                    ["Lvl0"] = {1,2},
                    ["Lvl1"] = {2,3},
                    ["Lvl2"] = {3,4},
                    ["Lvl3"] = {4,5},
                    ["Lvl4"] = {5,6},
                    ["Lvl5"] = {6,7}
                }
            },
            ["Alcohol"] = {
                ["ItemSpawn"] = "alcohol",
                ["ItemAmount"] = {
                    ["Lvl0"] = {1,2},
                    ["Lvl1"] = {2,3},
                    ["Lvl2"] = {3,4},
                    ["Lvl3"] = {4,5},
                    ["Lvl4"] = {5,6},
                    ["Lvl5"] = {6,7}
                }
            },
            ["Pill"] = {
                ["ItemSpawn"] = "pill",
                ["ItemAmount"] = {
                    ["Lvl0"] = {1,2},
                    ["Lvl1"] = {2,3},
                    ["Lvl2"] = {3,4},
                    ["Lvl3"] = {4,5},
                    ["Lvl4"] = {5,6},
                    ["Lvl5"] = {6,7}
                }
            },
            ["Amphetamine"] = {
                ["ItemSpawn"] = "amphetamine",
                ["ItemAmount"] = {
                    ["Lvl0"] = {1,2},
                    ["Lvl1"] = {2,3},
                    ["Lvl2"] = {3,4},
                    ["Lvl3"] = {4,5},
                    ["Lvl4"] = {5,6},
                    ["Lvl5"] = {6,7}
                }
            },
            ["Jar"] = {
                ["ItemSpawn"] = "jar",
                ["ItemAmount"] = {
                    ["Lvl0"] = {1,2},
                    ["Lvl1"] = {2,3},
                    ["Lvl2"] = {3,4},
                    ["Lvl3"] = {4,5},
                    ["Lvl4"] = {5,6},
                    ["Lvl5"] = {6,7}
                }
            }            
        }
    },    
    ["Labirinto"] = { 
        ["StartCoord"] = {2219.82,3956.14,37.42},
        ["PermToAcess"] = "Labirinto",
        ["UpgradeValue"] = {20000,50000,100000, 480000, 890000},
        ["Animation"] = {"amb@prop_human_parking_meter@female@idle_a","idle_a_female"},
        ["AnimDuration"] = 1000,
        ["ItemFarm"] = {
            ["Cokebud"] = {
                ["ItemSpawn"] = "cokebud",
                ["ItemAmount"] = {
                    ["Lvl0"] = {1,2},
                    ["Lvl1"] = {2,3},
                    ["Lvl2"] = {3,4},
                    ["Lvl3"] = {4,5},
                    ["Lvl4"] = {5,6},
                    ["Lvl5"] = {6,7}
                }
            },
            ["Ziplock"] = {
                ["ItemSpawn"] = "ziplock",
                ["ItemAmount"] = {
                    ["Lvl0"] = {1,2},
                    ["Lvl1"] = {2,3},
                    ["Lvl2"] = {3,4},
                    ["Lvl3"] = {4,5},
                    ["Lvl4"] = {5,6},
                    ["Lvl5"] = {6,7}
                }
            },
            ["Acetona"] = {
                ["ItemSpawn"] = "acetone",
                ["ItemAmount"] = {
                    ["Lvl0"] = {1,2},
                    ["Lvl1"] = {2,3},
                    ["Lvl2"] = {3,4},
                    ["Lvl3"] = {4,5},
                    ["Lvl4"] = {5,6},
                    ["Lvl5"] = {6,7}
                }
            },
            ["Garrafa"] = {
                ["ItemSpawn"] = "bottle",
                ["ItemAmount"] = {
                    ["Lvl0"] = {1,2},
                    ["Lvl1"] = {2,3},
                    ["Lvl2"] = {3,4},
                    ["Lvl3"] = {4,5},
                    ["Lvl4"] = {5,6},
                    ["Lvl5"] = {6,7}
                }
            },
            ["Solvente"] = {
                ["ItemSpawn"] = "solvent",
                ["ItemAmount"] = {
                    ["Lvl0"] = {1,2},
                    ["Lvl1"] = {2,3},
                    ["Lvl2"] = {3,4},
                    ["Lvl3"] = {4,5},
                    ["Lvl4"] = {5,6},
                    ["Lvl5"] = {6,7}
                }
            },
            ["Vinagre"] = {
                ["ItemSpawn"] = "vinegar",
                ["ItemAmount"] = {
                    ["Lvl0"] = {1,2},
                    ["Lvl1"] = {2,3},
                    ["Lvl2"] = {3,4},
                    ["Lvl3"] = {4,5},
                    ["Lvl4"] = {5,6},
                    ["Lvl5"] = {6,7}
                }
            },
            ["Weedbud"] = {
                ["ItemSpawn"] = "weedbud",
                ["ItemAmount"] = {
                    ["Lvl0"] = {1,2},
                    ["Lvl1"] = {2,3},
                    ["Lvl2"] = {3,4},
                    ["Lvl3"] = {4,5},
                    ["Lvl4"] = {5,6},
                    ["Lvl5"] = {6,7}
                }
            },
            ["Silk"] = {
                ["ItemSpawn"] = "silk",
                ["ItemAmount"] = {
                    ["Lvl0"] = {1,2},
                    ["Lvl1"] = {2,3},
                    ["Lvl2"] = {3,4},
                    ["Lvl3"] = {4,5},
                    ["Lvl4"] = {5,6},
                    ["Lvl5"] = {6,7}
                }
            },
            ["Codeine"] = {
                ["ItemSpawn"] = "codeine",
                ["ItemAmount"] = {
                    ["Lvl0"] = {1,2},
                    ["Lvl1"] = {2,3},
                    ["Lvl2"] = {3,4},
                    ["Lvl3"] = {4,5},
                    ["Lvl4"] = {5,6},
                    ["Lvl5"] = {6,7}
                }
            },
            ["Alcohol"] = {
                ["ItemSpawn"] = "alcohol",
                ["ItemAmount"] = {
                    ["Lvl0"] = {1,2},
                    ["Lvl1"] = {2,3},
                    ["Lvl2"] = {3,4},
                    ["Lvl3"] = {4,5},
                    ["Lvl4"] = {5,6},
                    ["Lvl5"] = {6,7}
                }
            },
            ["Pill"] = {
                ["ItemSpawn"] = "pill",
                ["ItemAmount"] = {
                    ["Lvl0"] = {1,2},
                    ["Lvl1"] = {2,3},
                    ["Lvl2"] = {3,4},
                    ["Lvl3"] = {4,5},
                    ["Lvl4"] = {5,6},
                    ["Lvl5"] = {6,7}
                }
            },
            ["Amphetamine"] = {
                ["ItemSpawn"] = "amphetamine",
                ["ItemAmount"] = {
                    ["Lvl0"] = {1,2},
                    ["Lvl1"] = {2,3},
                    ["Lvl2"] = {3,4},
                    ["Lvl3"] = {4,5},
                    ["Lvl4"] = {5,6},
                    ["Lvl5"] = {6,7}
                }
            },
            ["Jar"] = {
                ["ItemSpawn"] = "jar",
                ["ItemAmount"] = {
                    ["Lvl0"] = {1,2},
                    ["Lvl1"] = {2,3},
                    ["Lvl2"] = {3,4},
                    ["Lvl3"] = {4,5},
                    ["Lvl4"] = {5,6},
                    ["Lvl5"] = {6,7}
                }
            }            
        }
    },    
    ["P77"] = { 
        ["StartCoord"] = {1971.78,419.23,175.44},
        ["PermToAcess"] = "P77",
        ["UpgradeValue"] = {20000,50000,100000, 480000, 890000},
        ["Animation"] = {"amb@prop_human_parking_meter@female@idle_a","idle_a_female"},
        ["AnimDuration"] = 1000,
        ["ItemFarm"] = {
            ["Alumínio"] = {
                ["ItemSpawn"] = "aluminum",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            },
            ["Chapa de Metal"] = {
                ["ItemSpawn"] = "sheetmetal",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            }
        }
    },
    ["Favela6"] = { 
        ["StartCoord"] = {-2397.61,2617.59,27.57},
        ["PermToAcess"] = "Favela6",
        ["UpgradeValue"] = {20000,50000,100000, 480000, 890000},
        ["Animation"] = {"amb@prop_human_parking_meter@female@idle_a","idle_a_female"},
        ["AnimDuration"] = 1000,
        ["ItemFarm"] = {
            ["Alumínio"] = {
                ["ItemSpawn"] = "aluminum",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            },
            ["Chapa de Metal"] = {
                ["ItemSpawn"] = "sheetmetal",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            }
        }
    },
    ["Milicia"] = { 
        ["StartCoord"] = {1552.21,1463.83,111.14},
        ["PermToAcess"] = "Milicia",
        ["UpgradeValue"] = {20000,50000,100000, 480000, 890000},
        ["Animation"] = {"amb@prop_human_parking_meter@female@idle_a","idle_a_female"},
        ["AnimDuration"] = 1000,
        ["ItemFarm"] = {
            ["Plástico"] = {
                ["ItemSpawn"] = "plastic",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            },
            ["Lixo Eletrônico"] = {
                ["ItemSpawn"] = "techtrash",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            },
            ["Explosivos"] = {
                ["ItemSpawn"] = "explosives",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            },
            ["Alumínio"] = {
                ["ItemSpawn"] = "aluminum",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            },
            ["Barra de Ferro"] = {
                ["ItemSpawn"] = "iron_pure",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            },
            ["Tecido"] = {
                ["ItemSpawn"] = "fabric",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            },
            ["Chapa de Metal"] = {
                ["ItemSpawn"] = "sheetmetal",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            },
            ["Lona"] = {
                ["ItemSpawn"] = "tarp",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            },
            ["Barra de Estanho"] = {
                ["ItemSpawn"] = "tin_pure",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            },
            ["Vidro"] = {
                ["ItemSpawn"] = "glass",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            }
        }
    },
    ["Medellín"] = { 
        ["StartCoord"] = {2236.45,3557.93,68.78},
        ["PermToAcess"] = "Medellín",
        ["UpgradeValue"] = {20000,50000,100000, 480000, 890000},
        ["Animation"] = {"amb@prop_human_parking_meter@female@idle_a","idle_a_female"},
        ["AnimDuration"] = 1000,
        ["ItemFarm"] = {
            ["Plástico"] = {
                ["ItemSpawn"] = "plastic",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            },
            ["Lixo Eletrônico"] = {
                ["ItemSpawn"] = "techtrash",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            },
            ["Explosivos"] = {
                ["ItemSpawn"] = "explosives",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            },
            ["Alumínio"] = {
                ["ItemSpawn"] = "aluminum",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            },
            ["Barra de Ferro"] = {
                ["ItemSpawn"] = "iron_pure",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            },
            ["Tecido"] = {
                ["ItemSpawn"] = "fabric",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            },
            ["Chapa de Metal"] = {
                ["ItemSpawn"] = "sheetmetal",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            },
            ["Lona"] = {
                ["ItemSpawn"] = "tarp",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            },
            ["Barra de Estanho"] = {
                ["ItemSpawn"] = "tin_pure",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            },
            ["Vidro"] = {
                ["ItemSpawn"] = "glass",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            }
        }
    },
    ["Mare"] = { 
        ["StartCoord"] = {2356.78,484.73,202.01},
        ["PermToAcess"] = "Mare",
        ["UpgradeValue"] = {20000,50000,100000, 480000, 890000},
        ["Animation"] = {"amb@prop_human_parking_meter@female@idle_a","idle_a_female"},
        ["AnimDuration"] = 1000,
        ["ItemFarm"] = {
            ["Veja"] = {
                ["ItemSpawn"] = "veja",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            }
        }
    },
    ["Crateva"] = { 
        ["StartCoord"] = {619.86,2556.37,73.36},
        ["PermToAcess"] = "Crateva",
        ["UpgradeValue"] = {20000,50000,100000, 480000, 890000},
        ["Animation"] = {"amb@prop_human_parking_meter@female@idle_a","idle_a_female"},
        ["AnimDuration"] = 1000,
        ["ItemFarm"] = {
            ["Veja"] = {
                ["ItemSpawn"] = "veja",
                ["ItemAmount"] = {
                    ["Lvl0"] = {2,3},
                    ["Lvl1"] = {3,4},
                    ["Lvl2"] = {5,6},
                    ["Lvl3"] = {8,9},
                    ["Lvl4"] = {12,13},
                    ["Lvl5"] = {14,16}
                }
            }
        }
    },
}

Cfg.FarmCoords = {
    ["Maonegra"] = {
        ["Exclusivo"] = {
            { -1699.99,4284.45,71.98 },
            { -1582.9,4195.15,80.81 },
            { -1417.93,4183.11,49.34 },
            { -1316.07,4186.26,62.7 },
            { -1256.75,4278.24,68.97 },
            { -1045.0,4197.22,120.73 },
            { -922.0,4116.39,154.48 },
            { -757.75,4053.76,150.94 },
            { -539.72,3948.52,96.87 },
            { -388.83,3972.48,55.76 },
            { -221.19,3827.0,37.51 },
            { -112.07,3615.74,44.08 },
            { 77.82,3472.11,39.21 },
            { 346.5,3406.13,36.48 },
            { 82.19,3354.9,34.37 },
            { -76.66,3200.55,38.94 },
            { -303.25,3097.97,36.7 },
            { -424.95,3047.12,28.32 },
            { -600.84,3021.46,24.04 },
            { -784.47,2927.24,27.5 },
            { -909.96,2875.4,23.15 },
            { -1045.66,2884.3,11.02 },
            { -1260.46,2775.82,15.7 },
            { -1488.79,2689.63,3.03 },
            { -1634.51,2714.99,5.11 },
            { -1918.54,2714.05,3.4 },
            { -2145.87,2730.19,3.45 },
            { -2360.05,2851.76,3.17 },
            { -2627.22,2915.19,5.43 },
            { -2913.49,3231.5,10.06 },
            { -2945.07,3481.23,10.03 },
            { -2739.99,3470.01,11.73 },
            { -2507.18,3614.7,13.18 },
            { -2378.8,3905.12,23.83 },
            { -2219.84,4269.25,46.37 },
        },
        ["Padrão"] = {
            { -1380.43,735.34,182.98 },
            { -1280.21,2547.69,18.37 },
            { -459.0,2861.93,35.09 },
            { 346.28,3406.07,36.49 },
            { 1289.77,3630.85,33.2 },
            { 1690.89,3866.74,34.92 },
            { 2414.79,4032.14,36.82 },
            { 2030.48,3184.07,45.18 },
            { 2764.95,3248.69,52.06 },
            { 2456.39,4058.31,38.07 },
            { 1530.14,3778.62,34.52 },
            { 655.49,3505.75,34.01 },
            { 159.13,3133.74,43.57 },
            { 524.41,3080.05,40.49 },
            { 569.32,2796.7,42.02 },
            { 722.1,2331.68,51.76 },
            { 1531.51,1728.1,109.93 },
            { 1552.04,2189.58,78.85 },
            { 1048.33,2652.97,39.56 },
            { 732.7,2523.18,73.23 },
            { 97.95,3682.2,39.74 },
            { 1916.34,3823.94,32.44 },
            { 2566.64,4283.56,41.98 },
            { 2931.97,4486.07,48.04 },
            { 1723.08,6417.75,35.01 },
            { 1088.74,6509.08,21.08 },
            { -38.98,6420.18,31.5 },
            { -246.68,6068.31,32.35 },
            { -1044.22,5327.1,44.6 },
            { -2193.74,4290.4,49.18 },
            { -3190.6,1297.62,19.12 },
            { -2966.64,501.32,15.56 },
            { -2188.11,-409.04,13.16 },
            { -1152.92,-1448.92,4.58 },
            { -887.99,-1515.4,5.18 },
            { -1122.83,-1060.53,2.14 },
            { -2010.13,445.42,103.02 },
            { -128.74,618.63,206.12 },
            { -477.8,218.92,83.71 },
            { 240.07,99.48,93.93 }
        }
    },
    ["Bairro13"] = {
        ["Exclusivo"] = {
            { -1699.99,4284.45,71.98 },
            { -1582.9,4195.15,80.81 },
            { -1417.93,4183.11,49.34 },
            { -1316.07,4186.26,62.7 },
            { -1256.75,4278.24,68.97 },
            { -1045.0,4197.22,120.73 },
            { -922.0,4116.39,154.48 },
            { -757.75,4053.76,150.94 },
            { -539.72,3948.52,96.87 },
            { -388.83,3972.48,55.76 },
            { -221.19,3827.0,37.51 },
            { -112.07,3615.74,44.08 },
            { 77.82,3472.11,39.21 },
            { 346.5,3406.13,36.48 },
            { 82.19,3354.9,34.37 },
            { -76.66,3200.55,38.94 },
            { -303.25,3097.97,36.7 },
            { -424.95,3047.12,28.32 },
            { -600.84,3021.46,24.04 },
            { -784.47,2927.24,27.5 },
            { -909.96,2875.4,23.15 },
            { -1045.66,2884.3,11.02 },
            { -1260.46,2775.82,15.7 },
            { -1488.79,2689.63,3.03 },
            { -1634.51,2714.99,5.11 },
            { -1918.54,2714.05,3.4 },
            { -2145.87,2730.19,3.45 },
            { -2360.05,2851.76,3.17 },
            { -2627.22,2915.19,5.43 },
            { -2913.49,3231.5,10.06 },
            { -2945.07,3481.23,10.03 },
            { -2739.99,3470.01,11.73 },
            { -2507.18,3614.7,13.18 },
            { -2378.8,3905.12,23.83 },
            { -2219.84,4269.25,46.37 },
        },
        ["Padrão"] = {
            { -1380.43,735.34,182.98 },
            { -1280.21,2547.69,18.37 },
            { -459.0,2861.93,35.09 },
            { 346.28,3406.07,36.49 },
            { 1289.77,3630.85,33.2 },
            { 1690.89,3866.74,34.92 },
            { 2414.79,4032.14,36.82 },
            { 2030.48,3184.07,45.18 },
            { 2764.95,3248.69,52.06 },
            { 2456.39,4058.31,38.07 },
            { 1530.14,3778.62,34.52 },
            { 655.49,3505.75,34.01 },
            { 159.13,3133.74,43.57 },
            { 524.41,3080.05,40.49 },
            { 569.32,2796.7,42.02 },
            { 722.1,2331.68,51.76 },
            { 1531.51,1728.1,109.93 },
            { 1552.04,2189.58,78.85 },
            { 1048.33,2652.97,39.56 },
            { 732.7,2523.18,73.23 },
            { 97.95,3682.2,39.74 },
            { 1916.34,3823.94,32.44 },
            { 2566.64,4283.56,41.98 },
            { 2931.97,4486.07,48.04 },
            { 1723.08,6417.75,35.01 },
            { 1088.74,6509.08,21.08 },
            { -38.98,6420.18,31.5 },
            { -246.68,6068.31,32.35 },
            { -1044.22,5327.1,44.6 },
            { -2193.74,4290.4,49.18 },
            { -3190.6,1297.62,19.12 },
            { -2966.64,501.32,15.56 },
            { -2188.11,-409.04,13.16 },
            { -1152.92,-1448.92,4.58 },
            { -887.99,-1515.4,5.18 },
            { -1122.83,-1060.53,2.14 },
            { -2010.13,445.42,103.02 },
            { -128.74,618.63,206.12 },
            { -477.8,218.92,83.71 },
            { 240.07,99.48,93.93 }
        }
    },
    ["Setor13"] = {
        ["Exclusivo"] = {
            { -1699.99,4284.45,71.98 },
            { -1582.9,4195.15,80.81 },
            { -1417.93,4183.11,49.34 },
            { -1316.07,4186.26,62.7 },
            { -1256.75,4278.24,68.97 },
            { -1045.0,4197.22,120.73 },
            { -922.0,4116.39,154.48 },
            { -757.75,4053.76,150.94 },
            { -539.72,3948.52,96.87 },
            { -388.83,3972.48,55.76 },
            { -221.19,3827.0,37.51 },
            { -112.07,3615.74,44.08 },
            { 77.82,3472.11,39.21 },
            { 346.5,3406.13,36.48 },
            { 82.19,3354.9,34.37 },
            { -76.66,3200.55,38.94 },
            { -303.25,3097.97,36.7 },
            { -424.95,3047.12,28.32 },
            { -600.84,3021.46,24.04 },
            { -784.47,2927.24,27.5 },
            { -909.96,2875.4,23.15 },
            { -1045.66,2884.3,11.02 },
            { -1260.46,2775.82,15.7 },
            { -1488.79,2689.63,3.03 },
            { -1634.51,2714.99,5.11 },
            { -1918.54,2714.05,3.4 },
            { -2145.87,2730.19,3.45 },
            { -2360.05,2851.76,3.17 },
            { -2627.22,2915.19,5.43 },
            { -2913.49,3231.5,10.06 },
            { -2945.07,3481.23,10.03 },
            { -2739.99,3470.01,11.73 },
            { -2507.18,3614.7,13.18 },
            { -2378.8,3905.12,23.83 },
            { -2219.84,4269.25,46.37 },
        },
        ["Padrão"] = {
            { -1380.43,735.34,182.98 },
            { -1280.21,2547.69,18.37 },
            { -459.0,2861.93,35.09 },
            { 346.28,3406.07,36.49 },
            { 1289.77,3630.85,33.2 },
            { 1690.89,3866.74,34.92 },
            { 2414.79,4032.14,36.82 },
            { 2030.48,3184.07,45.18 },
            { 2764.95,3248.69,52.06 },
            { 2456.39,4058.31,38.07 },
            { 1530.14,3778.62,34.52 },
            { 655.49,3505.75,34.01 },
            { 159.13,3133.74,43.57 },
            { 524.41,3080.05,40.49 },
            { 569.32,2796.7,42.02 },
            { 722.1,2331.68,51.76 },
            { 1531.51,1728.1,109.93 },
            { 1552.04,2189.58,78.85 },
            { 1048.33,2652.97,39.56 },
            { 732.7,2523.18,73.23 },
            { 97.95,3682.2,39.74 },
            { 1916.34,3823.94,32.44 },
            { 2566.64,4283.56,41.98 },
            { 2931.97,4486.07,48.04 },
            { 1723.08,6417.75,35.01 },
            { 1088.74,6509.08,21.08 },
            { -38.98,6420.18,31.5 },
            { -246.68,6068.31,32.35 },
            { -1044.22,5327.1,44.6 },
            { -2193.74,4290.4,49.18 },
            { -3190.6,1297.62,19.12 },
            { -2966.64,501.32,15.56 },
            { -2188.11,-409.04,13.16 },
            { -1152.92,-1448.92,4.58 },
            { -887.99,-1515.4,5.18 },
            { -1122.83,-1060.53,2.14 },
            { -2010.13,445.42,103.02 },
            { -128.74,618.63,206.12 },
            { -477.8,218.92,83.71 },
            { 240.07,99.48,93.93 }
        }
    },
    ["Grota"] = {
        ["Exclusivo"] = {
            { -1699.99,4284.45,71.98 },
            { -1582.9,4195.15,80.81 },
            { -1417.93,4183.11,49.34 },
            { -1316.07,4186.26,62.7 },
            { -1256.75,4278.24,68.97 },
            { -1045.0,4197.22,120.73 },
            { -922.0,4116.39,154.48 },
            { -757.75,4053.76,150.94 },
            { -539.72,3948.52,96.87 },
            { -388.83,3972.48,55.76 },
            { -221.19,3827.0,37.51 },
            { -112.07,3615.74,44.08 },
            { 77.82,3472.11,39.21 },
            { 346.5,3406.13,36.48 },
            { 82.19,3354.9,34.37 },
            { -76.66,3200.55,38.94 },
            { -303.25,3097.97,36.7 },
            { -424.95,3047.12,28.32 },
            { -600.84,3021.46,24.04 },
            { -784.47,2927.24,27.5 },
            { -909.96,2875.4,23.15 },
            { -1045.66,2884.3,11.02 },
            { -1260.46,2775.82,15.7 },
            { -1488.79,2689.63,3.03 },
            { -1634.51,2714.99,5.11 },
            { -1918.54,2714.05,3.4 },
            { -2145.87,2730.19,3.45 },
            { -2360.05,2851.76,3.17 },
            { -2627.22,2915.19,5.43 },
            { -2913.49,3231.5,10.06 },
            { -2945.07,3481.23,10.03 },
            { -2739.99,3470.01,11.73 },
            { -2507.18,3614.7,13.18 },
            { -2378.8,3905.12,23.83 },
            { -2219.84,4269.25,46.37 },
        },
        ["Padrão"] = {
            { -1380.43,735.34,182.98 },
            { -1280.21,2547.69,18.37 },
            { -459.0,2861.93,35.09 },
            { 346.28,3406.07,36.49 },
            { 1289.77,3630.85,33.2 },
            { 1690.89,3866.74,34.92 },
            { 2414.79,4032.14,36.82 },
            { 2030.48,3184.07,45.18 },
            { 2764.95,3248.69,52.06 },
            { 2456.39,4058.31,38.07 },
            { 1530.14,3778.62,34.52 },
            { 655.49,3505.75,34.01 },
            { 159.13,3133.74,43.57 },
            { 524.41,3080.05,40.49 },
            { 569.32,2796.7,42.02 },
            { 722.1,2331.68,51.76 },
            { 1531.51,1728.1,109.93 },
            { 1552.04,2189.58,78.85 },
            { 1048.33,2652.97,39.56 },
            { 732.7,2523.18,73.23 },
            { 97.95,3682.2,39.74 },
            { 1916.34,3823.94,32.44 },
            { 2566.64,4283.56,41.98 },
            { 2931.97,4486.07,48.04 },
            { 1723.08,6417.75,35.01 },
            { 1088.74,6509.08,21.08 },
            { -38.98,6420.18,31.5 },
            { -246.68,6068.31,32.35 },
            { -1044.22,5327.1,44.6 },
            { -2193.74,4290.4,49.18 },
            { -3190.6,1297.62,19.12 },
            { -2966.64,501.32,15.56 },
            { -2188.11,-409.04,13.16 },
            { -1152.92,-1448.92,4.58 },
            { -887.99,-1515.4,5.18 },
            { -1122.83,-1060.53,2.14 },
            { -2010.13,445.42,103.02 },
            { -128.74,618.63,206.12 },
            { -477.8,218.92,83.71 },
            { 240.07,99.48,93.93 }
        }
    },
    ["Chernobyl"] = {
        ["Exclusivo"] = {
            { -1699.99,4284.45,71.98 },
            { -1582.9,4195.15,80.81 },
            { -1417.93,4183.11,49.34 },
            { -1316.07,4186.26,62.7 },
            { -1256.75,4278.24,68.97 },
            { -1045.0,4197.22,120.73 },
            { -922.0,4116.39,154.48 },
            { -757.75,4053.76,150.94 },
            { -539.72,3948.52,96.87 },
            { -388.83,3972.48,55.76 },
            { -221.19,3827.0,37.51 },
            { -112.07,3615.74,44.08 },
            { 77.82,3472.11,39.21 },
            { 346.5,3406.13,36.48 },
            { 82.19,3354.9,34.37 },
            { -76.66,3200.55,38.94 },
            { -303.25,3097.97,36.7 },
            { -424.95,3047.12,28.32 },
            { -600.84,3021.46,24.04 },
            { -784.47,2927.24,27.5 },
            { -909.96,2875.4,23.15 },
            { -1045.66,2884.3,11.02 },
            { -1260.46,2775.82,15.7 },
            { -1488.79,2689.63,3.03 },
            { -1634.51,2714.99,5.11 },
            { -1918.54,2714.05,3.4 },
            { -2145.87,2730.19,3.45 },
            { -2360.05,2851.76,3.17 },
            { -2627.22,2915.19,5.43 },
            { -2913.49,3231.5,10.06 },
            { -2945.07,3481.23,10.03 },
            { -2739.99,3470.01,11.73 },
            { -2507.18,3614.7,13.18 },
            { -2378.8,3905.12,23.83 },
            { -2219.84,4269.25,46.37 },
        },
        ["Padrão"] = {
            { -1380.43,735.34,182.98 },
            { -1280.21,2547.69,18.37 },
            { -459.0,2861.93,35.09 },
            { 346.28,3406.07,36.49 },
            { 1289.77,3630.85,33.2 },
            { 1690.89,3866.74,34.92 },
            { 2414.79,4032.14,36.82 },
            { 2030.48,3184.07,45.18 },
            { 2764.95,3248.69,52.06 },
            { 2456.39,4058.31,38.07 },
            { 1530.14,3778.62,34.52 },
            { 655.49,3505.75,34.01 },
            { 159.13,3133.74,43.57 },
            { 524.41,3080.05,40.49 },
            { 569.32,2796.7,42.02 },
            { 722.1,2331.68,51.76 },
            { 1531.51,1728.1,109.93 },
            { 1552.04,2189.58,78.85 },
            { 1048.33,2652.97,39.56 },
            { 732.7,2523.18,73.23 },
            { 97.95,3682.2,39.74 },
            { 1916.34,3823.94,32.44 },
            { 2566.64,4283.56,41.98 },
            { 2931.97,4486.07,48.04 },
            { 1723.08,6417.75,35.01 },
            { 1088.74,6509.08,21.08 },
            { -38.98,6420.18,31.5 },
            { -246.68,6068.31,32.35 },
            { -1044.22,5327.1,44.6 },
            { -2193.74,4290.4,49.18 },
            { -3190.6,1297.62,19.12 },
            { -2966.64,501.32,15.56 },
            { -2188.11,-409.04,13.16 },
            { -1152.92,-1448.92,4.58 },
            { -887.99,-1515.4,5.18 },
            { -1122.83,-1060.53,2.14 },
            { -2010.13,445.42,103.02 },
            { -128.74,618.63,206.12 },
            { -477.8,218.92,83.71 },
            { 240.07,99.48,93.93 }
        }
    },
    ["Crips"] = {
        ["Exclusivo"] = {
            { -1699.99,4284.45,71.98 },
            { -1582.9,4195.15,80.81 },
            { -1417.93,4183.11,49.34 },
            { -1316.07,4186.26,62.7 },
            { -1256.75,4278.24,68.97 },
            { -1045.0,4197.22,120.73 },
            { -922.0,4116.39,154.48 },
            { -757.75,4053.76,150.94 },
            { -539.72,3948.52,96.87 },
            { -388.83,3972.48,55.76 },
            { -221.19,3827.0,37.51 },
            { -112.07,3615.74,44.08 },
            { 77.82,3472.11,39.21 },
            { 346.5,3406.13,36.48 },
            { 82.19,3354.9,34.37 },
            { -76.66,3200.55,38.94 },
            { -303.25,3097.97,36.7 },
            { -424.95,3047.12,28.32 },
            { -600.84,3021.46,24.04 },
            { -784.47,2927.24,27.5 },
            { -909.96,2875.4,23.15 },
            { -1045.66,2884.3,11.02 },
            { -1260.46,2775.82,15.7 },
            { -1488.79,2689.63,3.03 },
            { -1634.51,2714.99,5.11 },
            { -1918.54,2714.05,3.4 },
            { -2145.87,2730.19,3.45 },
            { -2360.05,2851.76,3.17 },
            { -2627.22,2915.19,5.43 },
            { -2913.49,3231.5,10.06 },
            { -2945.07,3481.23,10.03 },
            { -2739.99,3470.01,11.73 },
            { -2507.18,3614.7,13.18 },
            { -2378.8,3905.12,23.83 },
            { -2219.84,4269.25,46.37 },
        },
        ["Padrão"] = {
            { -1380.43,735.34,182.98 },
            { -1280.21,2547.69,18.37 },
            { -459.0,2861.93,35.09 },
            { 346.28,3406.07,36.49 },
            { 1289.77,3630.85,33.2 },
            { 1690.89,3866.74,34.92 },
            { 2414.79,4032.14,36.82 },
            { 2030.48,3184.07,45.18 },
            { 2764.95,3248.69,52.06 },
            { 2456.39,4058.31,38.07 },
            { 1530.14,3778.62,34.52 },
            { 655.49,3505.75,34.01 },
            { 159.13,3133.74,43.57 },
            { 524.41,3080.05,40.49 },
            { 569.32,2796.7,42.02 },
            { 722.1,2331.68,51.76 },
            { 1531.51,1728.1,109.93 },
            { 1552.04,2189.58,78.85 },
            { 1048.33,2652.97,39.56 },
            { 732.7,2523.18,73.23 },
            { 97.95,3682.2,39.74 },
            { 1916.34,3823.94,32.44 },
            { 2566.64,4283.56,41.98 },
            { 2931.97,4486.07,48.04 },
            { 1723.08,6417.75,35.01 },
            { 1088.74,6509.08,21.08 },
            { -38.98,6420.18,31.5 },
            { -246.68,6068.31,32.35 },
            { -1044.22,5327.1,44.6 },
            { -2193.74,4290.4,49.18 },
            { -3190.6,1297.62,19.12 },
            { -2966.64,501.32,15.56 },
            { -2188.11,-409.04,13.16 },
            { -1152.92,-1448.92,4.58 },
            { -887.99,-1515.4,5.18 },
            { -1122.83,-1060.53,2.14 },
            { -2010.13,445.42,103.02 },
            { -128.74,618.63,206.12 },
            { -477.8,218.92,83.71 },
            { 240.07,99.48,93.93 }
        }
    },
    ["Distrito"] = {
        ["Exclusivo"] = {
            { -1699.99,4284.45,71.98 },
            { -1582.9,4195.15,80.81 },
            { -1417.93,4183.11,49.34 },
            { -1316.07,4186.26,62.7 },
            { -1256.75,4278.24,68.97 },
            { -1045.0,4197.22,120.73 },
            { -922.0,4116.39,154.48 },
            { -757.75,4053.76,150.94 },
            { -539.72,3948.52,96.87 },
            { -388.83,3972.48,55.76 },
            { -221.19,3827.0,37.51 },
            { -112.07,3615.74,44.08 },
            { 77.82,3472.11,39.21 },
            { 346.5,3406.13,36.48 },
            { 82.19,3354.9,34.37 },
            { -76.66,3200.55,38.94 },
            { -303.25,3097.97,36.7 },
            { -424.95,3047.12,28.32 },
            { -600.84,3021.46,24.04 },
            { -784.47,2927.24,27.5 },
            { -909.96,2875.4,23.15 },
            { -1045.66,2884.3,11.02 },
            { -1260.46,2775.82,15.7 },
            { -1488.79,2689.63,3.03 },
            { -1634.51,2714.99,5.11 },
            { -1918.54,2714.05,3.4 },
            { -2145.87,2730.19,3.45 },
            { -2360.05,2851.76,3.17 },
            { -2627.22,2915.19,5.43 },
            { -2913.49,3231.5,10.06 },
            { -2945.07,3481.23,10.03 },
            { -2739.99,3470.01,11.73 },
            { -2507.18,3614.7,13.18 },
            { -2378.8,3905.12,23.83 },
            { -2219.84,4269.25,46.37 },
        },
        ["Padrão"] = {
            { -1380.43,735.34,182.98 },
            { -1280.21,2547.69,18.37 },
            { -459.0,2861.93,35.09 },
            { 346.28,3406.07,36.49 },
            { 1289.77,3630.85,33.2 },
            { 1690.89,3866.74,34.92 },
            { 2414.79,4032.14,36.82 },
            { 2030.48,3184.07,45.18 },
            { 2764.95,3248.69,52.06 },
            { 2456.39,4058.31,38.07 },
            { 1530.14,3778.62,34.52 },
            { 655.49,3505.75,34.01 },
            { 159.13,3133.74,43.57 },
            { 524.41,3080.05,40.49 },
            { 569.32,2796.7,42.02 },
            { 722.1,2331.68,51.76 },
            { 1531.51,1728.1,109.93 },
            { 1552.04,2189.58,78.85 },
            { 1048.33,2652.97,39.56 },
            { 732.7,2523.18,73.23 },
            { 97.95,3682.2,39.74 },
            { 1916.34,3823.94,32.44 },
            { 2566.64,4283.56,41.98 },
            { 2931.97,4486.07,48.04 },
            { 1723.08,6417.75,35.01 },
            { 1088.74,6509.08,21.08 },
            { -38.98,6420.18,31.5 },
            { -246.68,6068.31,32.35 },
            { -1044.22,5327.1,44.6 },
            { -2193.74,4290.4,49.18 },
            { -3190.6,1297.62,19.12 },
            { -2966.64,501.32,15.56 },
            { -2188.11,-409.04,13.16 },
            { -1152.92,-1448.92,4.58 },
            { -887.99,-1515.4,5.18 },
            { -1122.83,-1060.53,2.14 },
            { -2010.13,445.42,103.02 },
            { -128.74,618.63,206.12 },
            { -477.8,218.92,83.71 },
            { 240.07,99.48,93.93 }
        }
    },
    ["Dz7"] = {
        ["Exclusivo"] = {
            { -1699.99,4284.45,71.98 },
            { -1582.9,4195.15,80.81 },
            { -1417.93,4183.11,49.34 },
            { -1316.07,4186.26,62.7 },
            { -1256.75,4278.24,68.97 },
            { -1045.0,4197.22,120.73 },
            { -922.0,4116.39,154.48 },
            { -757.75,4053.76,150.94 },
            { -539.72,3948.52,96.87 },
            { -388.83,3972.48,55.76 },
            { -221.19,3827.0,37.51 },
            { -112.07,3615.74,44.08 },
            { 77.82,3472.11,39.21 },
            { 346.5,3406.13,36.48 },
            { 82.19,3354.9,34.37 },
            { -76.66,3200.55,38.94 },
            { -303.25,3097.97,36.7 },
            { -424.95,3047.12,28.32 },
            { -600.84,3021.46,24.04 },
            { -784.47,2927.24,27.5 },
            { -909.96,2875.4,23.15 },
            { -1045.66,2884.3,11.02 },
            { -1260.46,2775.82,15.7 },
            { -1488.79,2689.63,3.03 },
            { -1634.51,2714.99,5.11 },
            { -1918.54,2714.05,3.4 },
            { -2145.87,2730.19,3.45 },
            { -2360.05,2851.76,3.17 },
            { -2627.22,2915.19,5.43 },
            { -2913.49,3231.5,10.06 },
            { -2945.07,3481.23,10.03 },
            { -2739.99,3470.01,11.73 },
            { -2507.18,3614.7,13.18 },
            { -2378.8,3905.12,23.83 },
            { -2219.84,4269.25,46.37 },
        },
        ["Padrão"] = {
            { -1380.43,735.34,182.98 },
            { -1280.21,2547.69,18.37 },
            { -459.0,2861.93,35.09 },
            { 346.28,3406.07,36.49 },
            { 1289.77,3630.85,33.2 },
            { 1690.89,3866.74,34.92 },
            { 2414.79,4032.14,36.82 },
            { 2030.48,3184.07,45.18 },
            { 2764.95,3248.69,52.06 },
            { 2456.39,4058.31,38.07 },
            { 1530.14,3778.62,34.52 },
            { 655.49,3505.75,34.01 },
            { 159.13,3133.74,43.57 },
            { 524.41,3080.05,40.49 },
            { 569.32,2796.7,42.02 },
            { 722.1,2331.68,51.76 },
            { 1531.51,1728.1,109.93 },
            { 1552.04,2189.58,78.85 },
            { 1048.33,2652.97,39.56 },
            { 732.7,2523.18,73.23 },
            { 97.95,3682.2,39.74 },
            { 1916.34,3823.94,32.44 },
            { 2566.64,4283.56,41.98 },
            { 2931.97,4486.07,48.04 },
            { 1723.08,6417.75,35.01 },
            { 1088.74,6509.08,21.08 },
            { -38.98,6420.18,31.5 },
            { -246.68,6068.31,32.35 },
            { -1044.22,5327.1,44.6 },
            { -2193.74,4290.4,49.18 },
            { -3190.6,1297.62,19.12 },
            { -2966.64,501.32,15.56 },
            { -2188.11,-409.04,13.16 },
            { -1152.92,-1448.92,4.58 },
            { -887.99,-1515.4,5.18 },
            { -1122.83,-1060.53,2.14 },
            { -2010.13,445.42,103.02 },
            { -128.74,618.63,206.12 },
            { -477.8,218.92,83.71 },
            { 240.07,99.48,93.93 }
        }
    },
    ["Labirinto"] = {
        ["Exclusivo"] = {
            { -1699.99,4284.45,71.98 },
            { -1582.9,4195.15,80.81 },
            { -1417.93,4183.11,49.34 },
            { -1316.07,4186.26,62.7 },
            { -1256.75,4278.24,68.97 },
            { -1045.0,4197.22,120.73 },
            { -922.0,4116.39,154.48 },
            { -757.75,4053.76,150.94 },
            { -539.72,3948.52,96.87 },
            { -388.83,3972.48,55.76 },
            { -221.19,3827.0,37.51 },
            { -112.07,3615.74,44.08 },
            { 77.82,3472.11,39.21 },
            { 346.5,3406.13,36.48 },
            { 82.19,3354.9,34.37 },
            { -76.66,3200.55,38.94 },
            { -303.25,3097.97,36.7 },
            { -424.95,3047.12,28.32 },
            { -600.84,3021.46,24.04 },
            { -784.47,2927.24,27.5 },
            { -909.96,2875.4,23.15 },
            { -1045.66,2884.3,11.02 },
            { -1260.46,2775.82,15.7 },
            { -1488.79,2689.63,3.03 },
            { -1634.51,2714.99,5.11 },
            { -1918.54,2714.05,3.4 },
            { -2145.87,2730.19,3.45 },
            { -2360.05,2851.76,3.17 },
            { -2627.22,2915.19,5.43 },
            { -2913.49,3231.5,10.06 },
            { -2945.07,3481.23,10.03 },
            { -2739.99,3470.01,11.73 },
            { -2507.18,3614.7,13.18 },
            { -2378.8,3905.12,23.83 },
            { -2219.84,4269.25,46.37 },
        },
        ["Padrão"] = {
            { -1380.43,735.34,182.98 },
            { -1280.21,2547.69,18.37 },
            { -459.0,2861.93,35.09 },
            { 346.28,3406.07,36.49 },
            { 1289.77,3630.85,33.2 },
            { 1690.89,3866.74,34.92 },
            { 2414.79,4032.14,36.82 },
            { 2030.48,3184.07,45.18 },
            { 2764.95,3248.69,52.06 },
            { 2456.39,4058.31,38.07 },
            { 1530.14,3778.62,34.52 },
            { 655.49,3505.75,34.01 },
            { 159.13,3133.74,43.57 },
            { 524.41,3080.05,40.49 },
            { 569.32,2796.7,42.02 },
            { 722.1,2331.68,51.76 },
            { 1531.51,1728.1,109.93 },
            { 1552.04,2189.58,78.85 },
            { 1048.33,2652.97,39.56 },
            { 732.7,2523.18,73.23 },
            { 97.95,3682.2,39.74 },
            { 1916.34,3823.94,32.44 },
            { 2566.64,4283.56,41.98 },
            { 2931.97,4486.07,48.04 },
            { 1723.08,6417.75,35.01 },
            { 1088.74,6509.08,21.08 },
            { -38.98,6420.18,31.5 },
            { -246.68,6068.31,32.35 },
            { -1044.22,5327.1,44.6 },
            { -2193.74,4290.4,49.18 },
            { -3190.6,1297.62,19.12 },
            { -2966.64,501.32,15.56 },
            { -2188.11,-409.04,13.16 },
            { -1152.92,-1448.92,4.58 },
            { -887.99,-1515.4,5.18 },
            { -1122.83,-1060.53,2.14 },
            { -2010.13,445.42,103.02 },
            { -128.74,618.63,206.12 },
            { -477.8,218.92,83.71 },
            { 240.07,99.48,93.93 }
        }
    },
    ["P77"] = {
        ["Exclusivo"] = {
            { -1699.99,4284.45,71.98 },
            { -1582.9,4195.15,80.81 },
            { -1417.93,4183.11,49.34 },
            { -1316.07,4186.26,62.7 },
            { -1256.75,4278.24,68.97 },
            { -1045.0,4197.22,120.73 },
            { -922.0,4116.39,154.48 },
            { -757.75,4053.76,150.94 },
            { -539.72,3948.52,96.87 },
            { -388.83,3972.48,55.76 },
            { -221.19,3827.0,37.51 },
            { -112.07,3615.74,44.08 },
            { 77.82,3472.11,39.21 },
            { 346.5,3406.13,36.48 },
            { 82.19,3354.9,34.37 },
            { -76.66,3200.55,38.94 },
            { -303.25,3097.97,36.7 },
            { -424.95,3047.12,28.32 },
            { -600.84,3021.46,24.04 },
            { -784.47,2927.24,27.5 },
            { -909.96,2875.4,23.15 },
            { -1045.66,2884.3,11.02 },
            { -1260.46,2775.82,15.7 },
            { -1488.79,2689.63,3.03 },
            { -1634.51,2714.99,5.11 },
            { -1918.54,2714.05,3.4 },
            { -2145.87,2730.19,3.45 },
            { -2360.05,2851.76,3.17 },
            { -2627.22,2915.19,5.43 },
            { -2913.49,3231.5,10.06 },
            { -2945.07,3481.23,10.03 },
            { -2739.99,3470.01,11.73 },
            { -2507.18,3614.7,13.18 },
            { -2378.8,3905.12,23.83 },
            { -2219.84,4269.25,46.37 },
        },
        ["Padrão"] = {
            { -1380.43,735.34,182.98 },
            { -1280.21,2547.69,18.37 },
            { -459.0,2861.93,35.09 },
            { 346.28,3406.07,36.49 },
            { 1289.77,3630.85,33.2 },
            { 1690.89,3866.74,34.92 },
            { 2414.79,4032.14,36.82 },
            { 2030.48,3184.07,45.18 },
            { 2764.95,3248.69,52.06 },
            { 2456.39,4058.31,38.07 },
            { 1530.14,3778.62,34.52 },
            { 655.49,3505.75,34.01 },
            { 159.13,3133.74,43.57 },
            { 524.41,3080.05,40.49 },
            { 569.32,2796.7,42.02 },
            { 722.1,2331.68,51.76 },
            { 1531.51,1728.1,109.93 },
            { 1552.04,2189.58,78.85 },
            { 1048.33,2652.97,39.56 },
            { 732.7,2523.18,73.23 },
            { 97.95,3682.2,39.74 },
            { 1916.34,3823.94,32.44 },
            { 2566.64,4283.56,41.98 },
            { 2931.97,4486.07,48.04 },
            { 1723.08,6417.75,35.01 },
            { 1088.74,6509.08,21.08 },
            { -38.98,6420.18,31.5 },
            { -246.68,6068.31,32.35 },
            { -1044.22,5327.1,44.6 },
            { -2193.74,4290.4,49.18 },
            { -3190.6,1297.62,19.12 },
            { -2966.64,501.32,15.56 },
            { -2188.11,-409.04,13.16 },
            { -1152.92,-1448.92,4.58 },
            { -887.99,-1515.4,5.18 },
            { -1122.83,-1060.53,2.14 },
            { -2010.13,445.42,103.02 },
            { -128.74,618.63,206.12 },
            { -477.8,218.92,83.71 },
            { 240.07,99.48,93.93 }
        }
    },
    ["Favela6"] = {
        ["Exclusivo"] = {
            { -1699.99,4284.45,71.98 },
            { -1582.9,4195.15,80.81 },
            { -1417.93,4183.11,49.34 },
            { -1316.07,4186.26,62.7 },
            { -1256.75,4278.24,68.97 },
            { -1045.0,4197.22,120.73 },
            { -922.0,4116.39,154.48 },
            { -757.75,4053.76,150.94 },
            { -539.72,3948.52,96.87 },
            { -388.83,3972.48,55.76 },
            { -221.19,3827.0,37.51 },
            { -112.07,3615.74,44.08 },
            { 77.82,3472.11,39.21 },
            { 346.5,3406.13,36.48 },
            { 82.19,3354.9,34.37 },
            { -76.66,3200.55,38.94 },
            { -303.25,3097.97,36.7 },
            { -424.95,3047.12,28.32 },
            { -600.84,3021.46,24.04 },
            { -784.47,2927.24,27.5 },
            { -909.96,2875.4,23.15 },
            { -1045.66,2884.3,11.02 },
            { -1260.46,2775.82,15.7 },
            { -1488.79,2689.63,3.03 },
            { -1634.51,2714.99,5.11 },
            { -1918.54,2714.05,3.4 },
            { -2145.87,2730.19,3.45 },
            { -2360.05,2851.76,3.17 },
            { -2627.22,2915.19,5.43 },
            { -2913.49,3231.5,10.06 },
            { -2945.07,3481.23,10.03 },
            { -2739.99,3470.01,11.73 },
            { -2507.18,3614.7,13.18 },
            { -2378.8,3905.12,23.83 },
            { -2219.84,4269.25,46.37 },
        },
        ["Padrão"] = {
            { -1380.43,735.34,182.98 },
            { -1280.21,2547.69,18.37 },
            { -459.0,2861.93,35.09 },
            { 346.28,3406.07,36.49 },
            { 1289.77,3630.85,33.2 },
            { 1690.89,3866.74,34.92 },
            { 2414.79,4032.14,36.82 },
            { 2030.48,3184.07,45.18 },
            { 2764.95,3248.69,52.06 },
            { 2456.39,4058.31,38.07 },
            { 1530.14,3778.62,34.52 },
            { 655.49,3505.75,34.01 },
            { 159.13,3133.74,43.57 },
            { 524.41,3080.05,40.49 },
            { 569.32,2796.7,42.02 },
            { 722.1,2331.68,51.76 },
            { 1531.51,1728.1,109.93 },
            { 1552.04,2189.58,78.85 },
            { 1048.33,2652.97,39.56 },
            { 732.7,2523.18,73.23 },
            { 97.95,3682.2,39.74 },
            { 1916.34,3823.94,32.44 },
            { 2566.64,4283.56,41.98 },
            { 2931.97,4486.07,48.04 },
            { 1723.08,6417.75,35.01 },
            { 1088.74,6509.08,21.08 },
            { -38.98,6420.18,31.5 },
            { -246.68,6068.31,32.35 },
            { -1044.22,5327.1,44.6 },
            { -2193.74,4290.4,49.18 },
            { -3190.6,1297.62,19.12 },
            { -2966.64,501.32,15.56 },
            { -2188.11,-409.04,13.16 },
            { -1152.92,-1448.92,4.58 },
            { -887.99,-1515.4,5.18 },
            { -1122.83,-1060.53,2.14 },
            { -2010.13,445.42,103.02 },
            { -128.74,618.63,206.12 },
            { -477.8,218.92,83.71 },
            { 240.07,99.48,93.93 }
        }
    },
    ["Milicia"] = {
        ["Exclusivo"] = {
            { -1699.99,4284.45,71.98 },
            { -1582.9,4195.15,80.81 },
            { -1417.93,4183.11,49.34 },
            { -1316.07,4186.26,62.7 },
            { -1256.75,4278.24,68.97 },
            { -1045.0,4197.22,120.73 },
            { -922.0,4116.39,154.48 },
            { -757.75,4053.76,150.94 },
            { -539.72,3948.52,96.87 },
            { -388.83,3972.48,55.76 },
            { -221.19,3827.0,37.51 },
            { -112.07,3615.74,44.08 },
            { 77.82,3472.11,39.21 },
            { 346.5,3406.13,36.48 },
            { 82.19,3354.9,34.37 },
            { -76.66,3200.55,38.94 },
            { -303.25,3097.97,36.7 },
            { -424.95,3047.12,28.32 },
            { -600.84,3021.46,24.04 },
            { -784.47,2927.24,27.5 },
            { -909.96,2875.4,23.15 },
            { -1045.66,2884.3,11.02 },
            { -1260.46,2775.82,15.7 },
            { -1488.79,2689.63,3.03 },
            { -1634.51,2714.99,5.11 },
            { -1918.54,2714.05,3.4 },
            { -2145.87,2730.19,3.45 },
            { -2360.05,2851.76,3.17 },
            { -2627.22,2915.19,5.43 },
            { -2913.49,3231.5,10.06 },
            { -2945.07,3481.23,10.03 },
            { -2739.99,3470.01,11.73 },
            { -2507.18,3614.7,13.18 },
            { -2378.8,3905.12,23.83 },
            { -2219.84,4269.25,46.37 },
        },
        ["Padrão"] = {
            { -1380.43,735.34,182.98 },
            { -1280.21,2547.69,18.37 },
            { -459.0,2861.93,35.09 },
            { 346.28,3406.07,36.49 },
            { 1289.77,3630.85,33.2 },
            { 1690.89,3866.74,34.92 },
            { 2414.79,4032.14,36.82 },
            { 2030.48,3184.07,45.18 },
            { 2764.95,3248.69,52.06 },
            { 2456.39,4058.31,38.07 },
            { 1530.14,3778.62,34.52 },
            { 655.49,3505.75,34.01 },
            { 159.13,3133.74,43.57 },
            { 524.41,3080.05,40.49 },
            { 569.32,2796.7,42.02 },
            { 722.1,2331.68,51.76 },
            { 1531.51,1728.1,109.93 },
            { 1552.04,2189.58,78.85 },
            { 1048.33,2652.97,39.56 },
            { 732.7,2523.18,73.23 },
            { 97.95,3682.2,39.74 },
            { 1916.34,3823.94,32.44 },
            { 2566.64,4283.56,41.98 },
            { 2931.97,4486.07,48.04 },
            { 1723.08,6417.75,35.01 },
            { 1088.74,6509.08,21.08 },
            { -38.98,6420.18,31.5 },
            { -246.68,6068.31,32.35 },
            { -1044.22,5327.1,44.6 },
            { -2193.74,4290.4,49.18 },
            { -3190.6,1297.62,19.12 },
            { -2966.64,501.32,15.56 },
            { -2188.11,-409.04,13.16 },
            { -1152.92,-1448.92,4.58 },
            { -887.99,-1515.4,5.18 },
            { -1122.83,-1060.53,2.14 },
            { -2010.13,445.42,103.02 },
            { -128.74,618.63,206.12 },
            { -477.8,218.92,83.71 },
            { 240.07,99.48,93.93 }
        }
    },
    ["Medellín"] = {
        ["Exclusivo"] = {
            { -1699.99,4284.45,71.98 },
            { -1582.9,4195.15,80.81 },
            { -1417.93,4183.11,49.34 },
            { -1316.07,4186.26,62.7 },
            { -1256.75,4278.24,68.97 },
            { -1045.0,4197.22,120.73 },
            { -922.0,4116.39,154.48 },
            { -757.75,4053.76,150.94 },
            { -539.72,3948.52,96.87 },
            { -388.83,3972.48,55.76 },
            { -221.19,3827.0,37.51 },
            { -112.07,3615.74,44.08 },
            { 77.82,3472.11,39.21 },
            { 346.5,3406.13,36.48 },
            { 82.19,3354.9,34.37 },
            { -76.66,3200.55,38.94 },
            { -303.25,3097.97,36.7 },
            { -424.95,3047.12,28.32 },
            { -600.84,3021.46,24.04 },
            { -784.47,2927.24,27.5 },
            { -909.96,2875.4,23.15 },
            { -1045.66,2884.3,11.02 },
            { -1260.46,2775.82,15.7 },
            { -1488.79,2689.63,3.03 },
            { -1634.51,2714.99,5.11 },
            { -1918.54,2714.05,3.4 },
            { -2145.87,2730.19,3.45 },
            { -2360.05,2851.76,3.17 },
            { -2627.22,2915.19,5.43 },
            { -2913.49,3231.5,10.06 },
            { -2945.07,3481.23,10.03 },
            { -2739.99,3470.01,11.73 },
            { -2507.18,3614.7,13.18 },
            { -2378.8,3905.12,23.83 },
            { -2219.84,4269.25,46.37 },
        },
        ["Padrão"] = {
            { -1380.43,735.34,182.98 },
            { -1280.21,2547.69,18.37 },
            { -459.0,2861.93,35.09 },
            { 346.28,3406.07,36.49 },
            { 1289.77,3630.85,33.2 },
            { 1690.89,3866.74,34.92 },
            { 2414.79,4032.14,36.82 },
            { 2030.48,3184.07,45.18 },
            { 2764.95,3248.69,52.06 },
            { 2456.39,4058.31,38.07 },
            { 1530.14,3778.62,34.52 },
            { 655.49,3505.75,34.01 },
            { 159.13,3133.74,43.57 },
            { 524.41,3080.05,40.49 },
            { 569.32,2796.7,42.02 },
            { 722.1,2331.68,51.76 },
            { 1531.51,1728.1,109.93 },
            { 1552.04,2189.58,78.85 },
            { 1048.33,2652.97,39.56 },
            { 732.7,2523.18,73.23 },
            { 97.95,3682.2,39.74 },
            { 1916.34,3823.94,32.44 },
            { 2566.64,4283.56,41.98 },
            { 2931.97,4486.07,48.04 },
            { 1723.08,6417.75,35.01 },
            { 1088.74,6509.08,21.08 },
            { -38.98,6420.18,31.5 },
            { -246.68,6068.31,32.35 },
            { -1044.22,5327.1,44.6 },
            { -2193.74,4290.4,49.18 },
            { -3190.6,1297.62,19.12 },
            { -2966.64,501.32,15.56 },
            { -2188.11,-409.04,13.16 },
            { -1152.92,-1448.92,4.58 },
            { -887.99,-1515.4,5.18 },
            { -1122.83,-1060.53,2.14 },
            { -2010.13,445.42,103.02 },
            { -128.74,618.63,206.12 },
            { -477.8,218.92,83.71 },
            { 240.07,99.48,93.93 }
        }
    },
    ["Mare"] = {
        ["Exclusivo"] = {
            { -1699.99,4284.45,71.98 },
            { -1582.9,4195.15,80.81 },
            { -1417.93,4183.11,49.34 },
            { -1316.07,4186.26,62.7 },
            { -1256.75,4278.24,68.97 },
            { -1045.0,4197.22,120.73 },
            { -922.0,4116.39,154.48 },
            { -757.75,4053.76,150.94 },
            { -539.72,3948.52,96.87 },
            { -388.83,3972.48,55.76 },
            { -221.19,3827.0,37.51 },
            { -112.07,3615.74,44.08 },
            { 77.82,3472.11,39.21 },
            { 346.5,3406.13,36.48 },
            { 82.19,3354.9,34.37 },
            { -76.66,3200.55,38.94 },
            { -303.25,3097.97,36.7 },
            { -424.95,3047.12,28.32 },
            { -600.84,3021.46,24.04 },
            { -784.47,2927.24,27.5 },
            { -909.96,2875.4,23.15 },
            { -1045.66,2884.3,11.02 },
            { -1260.46,2775.82,15.7 },
            { -1488.79,2689.63,3.03 },
            { -1634.51,2714.99,5.11 },
            { -1918.54,2714.05,3.4 },
            { -2145.87,2730.19,3.45 },
            { -2360.05,2851.76,3.17 },
            { -2627.22,2915.19,5.43 },
            { -2913.49,3231.5,10.06 },
            { -2945.07,3481.23,10.03 },
            { -2739.99,3470.01,11.73 },
            { -2507.18,3614.7,13.18 },
            { -2378.8,3905.12,23.83 },
            { -2219.84,4269.25,46.37 },
        },
        ["Padrão"] = {
            { -1380.43,735.34,182.98 },
            { -1280.21,2547.69,18.37 },
            { -459.0,2861.93,35.09 },
            { 346.28,3406.07,36.49 },
            { 1289.77,3630.85,33.2 },
            { 1690.89,3866.74,34.92 },
            { 2414.79,4032.14,36.82 },
            { 2030.48,3184.07,45.18 },
            { 2764.95,3248.69,52.06 },
            { 2456.39,4058.31,38.07 },
            { 1530.14,3778.62,34.52 },
            { 655.49,3505.75,34.01 },
            { 159.13,3133.74,43.57 },
            { 524.41,3080.05,40.49 },
            { 569.32,2796.7,42.02 },
            { 722.1,2331.68,51.76 },
            { 1531.51,1728.1,109.93 },
            { 1552.04,2189.58,78.85 },
            { 1048.33,2652.97,39.56 },
            { 732.7,2523.18,73.23 },
            { 97.95,3682.2,39.74 },
            { 1916.34,3823.94,32.44 },
            { 2566.64,4283.56,41.98 },
            { 2931.97,4486.07,48.04 },
            { 1723.08,6417.75,35.01 },
            { 1088.74,6509.08,21.08 },
            { -38.98,6420.18,31.5 },
            { -246.68,6068.31,32.35 },
            { -1044.22,5327.1,44.6 },
            { -2193.74,4290.4,49.18 },
            { -3190.6,1297.62,19.12 },
            { -2966.64,501.32,15.56 },
            { -2188.11,-409.04,13.16 },
            { -1152.92,-1448.92,4.58 },
            { -887.99,-1515.4,5.18 },
            { -1122.83,-1060.53,2.14 },
            { -2010.13,445.42,103.02 },
            { -128.74,618.63,206.12 },
            { -477.8,218.92,83.71 },
            { 240.07,99.48,93.93 }
        }
    },
    ["Crateva"] = {
        ["Exclusivo"] = {
            { -1699.99,4284.45,71.98 },
            { -1582.9,4195.15,80.81 },
            { -1417.93,4183.11,49.34 },
            { -1316.07,4186.26,62.7 },
            { -1256.75,4278.24,68.97 },
            { -1045.0,4197.22,120.73 },
            { -922.0,4116.39,154.48 },
            { -757.75,4053.76,150.94 },
            { -539.72,3948.52,96.87 },
            { -388.83,3972.48,55.76 },
            { -221.19,3827.0,37.51 },
            { -112.07,3615.74,44.08 },
            { 77.82,3472.11,39.21 },
            { 346.5,3406.13,36.48 },
            { 82.19,3354.9,34.37 },
            { -76.66,3200.55,38.94 },
            { -303.25,3097.97,36.7 },
            { -424.95,3047.12,28.32 },
            { -600.84,3021.46,24.04 },
            { -784.47,2927.24,27.5 },
            { -909.96,2875.4,23.15 },
            { -1045.66,2884.3,11.02 },
            { -1260.46,2775.82,15.7 },
            { -1488.79,2689.63,3.03 },
            { -1634.51,2714.99,5.11 },
            { -1918.54,2714.05,3.4 },
            { -2145.87,2730.19,3.45 },
            { -2360.05,2851.76,3.17 },
            { -2627.22,2915.19,5.43 },
            { -2913.49,3231.5,10.06 },
            { -2945.07,3481.23,10.03 },
            { -2739.99,3470.01,11.73 },
            { -2507.18,3614.7,13.18 },
            { -2378.8,3905.12,23.83 },
            { -2219.84,4269.25,46.37 },
        },
        ["Padrão"] = {
            { -1380.43,735.34,182.98 },
            { -1280.21,2547.69,18.37 },
            { -459.0,2861.93,35.09 },
            { 346.28,3406.07,36.49 },
            { 1289.77,3630.85,33.2 },
            { 1690.89,3866.74,34.92 },
            { 2414.79,4032.14,36.82 },
            { 2030.48,3184.07,45.18 },
            { 2764.95,3248.69,52.06 },
            { 2456.39,4058.31,38.07 },
            { 1530.14,3778.62,34.52 },
            { 655.49,3505.75,34.01 },
            { 159.13,3133.74,43.57 },
            { 524.41,3080.05,40.49 },
            { 569.32,2796.7,42.02 },
            { 722.1,2331.68,51.76 },
            { 1531.51,1728.1,109.93 },
            { 1552.04,2189.58,78.85 },
            { 1048.33,2652.97,39.56 },
            { 732.7,2523.18,73.23 },
            { 97.95,3682.2,39.74 },
            { 1916.34,3823.94,32.44 },
            { 2566.64,4283.56,41.98 },
            { 2931.97,4486.07,48.04 },
            { 1723.08,6417.75,35.01 },
            { 1088.74,6509.08,21.08 },
            { -38.98,6420.18,31.5 },
            { -246.68,6068.31,32.35 },
            { -1044.22,5327.1,44.6 },
            { -2193.74,4290.4,49.18 },
            { -3190.6,1297.62,19.12 },
            { -2966.64,501.32,15.56 },
            { -2188.11,-409.04,13.16 },
            { -1152.92,-1448.92,4.58 },
            { -887.99,-1515.4,5.18 },
            { -1122.83,-1060.53,2.14 },
            { -2010.13,445.42,103.02 },
            { -128.74,618.63,206.12 },
            { -477.8,218.92,83.71 },
            { 240.07,99.48,93.93 }
        }
    },
}

Cfg.NotifyConfig = {
    ["NoPerm"] = "Você não tem permissão para acessar.",
    ["MaxLvl"] = "Você ja esta nivel maximo.",
    ["SucessPayment"] = "Pagamento concluido.",
    ["FailedPayment"] = "<b>Dinheiro</b> insuficiente.",
    ["StartFixedRoute"] = "Rota fixa iniciada.",
    ["StartRandomRoute"] = "Rota aleatoria iniciada.",
}