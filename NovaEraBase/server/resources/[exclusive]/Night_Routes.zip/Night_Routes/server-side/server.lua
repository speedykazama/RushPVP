-----------------------------------------------------------------------------------------------------------------------------------------
-- VRP
-----------------------------------------------------------------------------------------------------------------------------------------
local Tunnel = module("vrp","lib/Tunnel")
local Proxy = module("vrp","lib/Proxy")
vRPC = Tunnel.getInterface("vRP")
vRP = Proxy.getInterface("vRP")
-----------------------------------------------------------------------------------------------------------------------------------------
-- CONNECTION
-----------------------------------------------------------------------------------------------------------------------------------------
Creative = {}
Tunnel.bindInterface("Night_Routes",Creative)
vCLIENT = Tunnel.getInterface("Night_Routes")
-----------------------------------------------------------------------------------------------------------------------------------------
-- PREPARES
-----------------------------------------------------------------------------------------------------------------------------------------
vRP.Prepare("night_farm/getOrg","SELECT * FROM night_farm WHERE Org = @Org")
vRP.Prepare("night_farm/updateFarm","UPDATE night_farm SET Lvl = Lvl + 1 WHERE Org = @Org")
-----------------------------------------------------------------------------------------------------------------------------------------
-- Check Org
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.CheckOrg(farm)
    local source = source
    local user_id = vRP.Passport(source)
    if user_id then
        for k,v in pairs(Cfg.FarmConfig) do
         if k == farm then
                local query = vRP.Query("night_farm/getOrg",{ Org = k })
                if query[1] then
                    if v["PermToAcess"] ~= nil then
                        if vRP.HasGroup(user_id,v["PermToAcess"]) or vRP.HasGroup(user_id,"Admin") then
                            if not vRP.HasGroup(user_id,v["PermToAcess"]) then
                                TriggerClientEvent("Notify",source,"verde","Você forçou a abertura do farm com sua permissão de Admin.",4000)
                            end
                            
                            return query[1]["Org"]
                        end
                    else
                        return query[1]["Org"]
                    end
                end
            end
        end
       
        TriggerClientEvent("Notify",source,"vermelho",Cfg.NotifyConfig["NoPerm"],4000)
        return false
    end
end

function Creative.GetLvl(OrgName)
    local source = source
    local user_id = vRP.Passport(source)
    if user_id then
        local query = vRP.Query("night_farm/getOrg",{ Org = OrgName })
        if query[1] then
            return query[1]["Lvl"]
        end
    end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- Upgrade Farm
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.PaymentCollect(OrgName,RouteName,Lvl)
    local source = source
    local user_id = vRP.Passport(source)
    if user_id then
        Player(source)["state"]["Buttons"] = true
        Player(source)["state"]["Cancel"] = true

        if not vRPC.inVehicle(source) then
            vRPC.playAnim(source,false,{Cfg.FarmConfig[OrgName]["Animation"][1],Cfg.FarmConfig[OrgName]["Animation"][2]},true)
            TriggerClientEvent("Progress",source,"Coletando",Cfg.FarmConfig[OrgName]["AnimDuration"],5000)
            Wait(Cfg.FarmConfig[OrgName]["AnimDuration"])
            vRPC.stopAnim(source, false)
        end
        local quantidade = math.random(Cfg.FarmConfig[OrgName]["ItemFarm"][RouteName]["ItemAmount"]["Lvl"..Lvl][1],Cfg.FarmConfig[OrgName]["ItemFarm"][RouteName]["ItemAmount"]["Lvl"..Lvl][2])

        Player(source)["state"]["Buttons"] = false
        Player(source)["state"]["Cancel"] = false
        if (vRP.InventoryWeight(user_id) + itemWeight(Cfg.FarmConfig[OrgName]["ItemFarm"][RouteName]["ItemSpawn"]) * quantidade) <= vRP.GetWeight(user_id) then
            vRP.GenerateItem(user_id,Cfg.FarmConfig[OrgName]["ItemFarm"][RouteName]["ItemSpawn"],quantidade,true)
            return true
        else
            TriggerClientEvent("Notify",source,"vermelho","Mochila cheia.",5000)
            return false
        end    
    end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- Upgrade Farm
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.UpgradeFarm(farm)
    local source = source
    local user_id = vRP.Passport(source)
    if user_id then
        local OrgInfo = farm--Creative.CheckOrg(source)
        if OrgInfo then
            local query = vRP.Query("night_farm/getOrg",{ Org = OrgInfo })
            if (query[1]["Lvl"]+1) > 5 then
                TriggerClientEvent("Notify",source,"amarelo",Cfg.NotifyConfig["MaxLvl"],3000)
                return
            end
            vCLIENT.CloseSystem(source)
            if vRP.Request(source,"Upgrade no farm para o LVL "..(query[1]["Lvl"]+1).." por <b>$"..parseFormat(Cfg.FarmConfig[OrgInfo]["UpgradeValue"][query[1]["Lvl"]+1]).."</b>?", "Melhore as entregas") then
                if vRP.PaymentFull(user_id,Cfg.FarmConfig[OrgInfo]["UpgradeValue"][query[1]["Lvl"]+1]) then
                    vRP.Query("night_farm/updateFarm",{ Org = OrgInfo })
                    TriggerClientEvent("Notify",source,"verde",Cfg.NotifyConfig["SucessPayment"],3000)
                else
                    TriggerClientEvent("Notify",source,"vermelho",Cfg.NotifyConfig["FailedPayment"],5000)
                end
            else
                return
            end
        end
    end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- Level Identify
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.levelIdentify(farm)
	local source = source
	local user_id = vRP.getUserId(source)
    local OrgInfo = farm --Creative.CheckOrg(source)
    if OrgInfo then
        local query = vRP.Query("night_farm/getOrg",{ Org = OrgInfo })
        if query[1] then
            if user_id then
                return 
                {
                    query[1]["Lvl"]
                }
            end	
        end
    end
end