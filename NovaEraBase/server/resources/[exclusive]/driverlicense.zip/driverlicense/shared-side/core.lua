Categories = {
    [1] = { 
        ["category"] = "A",
        ["description"] = "Moto",
        ["price"] = 2000,
        ["taxs"] = {
            theoretical = 100,
            practice = 350
        },
    },
    [2] = {  
        ["category"] = "B",
        ["description"] = "Carro",
        ["price"] = 5000,
        ["taxs"] = {
            theoretical = 100,
            practice = 350
        },
    },
    [3] = {  
        ["category"] = "C",
        ["description"] = "Ônibus",
        ["price"] = 8000,
        ["taxs"] = {
            theoretical = 100,
            practice = 350
        },
    },
    [4] = {  
        ["category"] = "D",
        ["description"] = "Caminhão",
        ["price"] = 12000,
        ["taxs"] = {
            theoretical = 100,
            practice = 350
        },
    },
}

Locations = {
    [1] = {
        ["coords"] = { -697.84,-1673.4,25.0,2.84 },
        ["categories"] = {
            [1] = { 
                vehicles = {"cg160"},
                maxErros = 3,
                instructor = "a_m_y_genstreet_01",
                spawn = { 
                    {-716.03,-1689.17,23.43,0.0} 
                },
                route = {
                    { coords = { -676.48,-1768.48,24.97,209.77 }, text = "Verifique os dois lados da via, para garantir que está livre para prosseguir." },
                    { coords = { -504.27,-1796.43,21.96,337.33 }, text = "Não é obrigatório esperar os semafaros, porém você deve parar em todos e garantir que a via está livre para seguir." },
                    { coords = { -270.29,-1454.1,31.32,357.17 }, text = "Mantenha uma distância segura do veículo à frente." },
                    { coords = { -438.75,-1417.75,29.32,76.54 }, text = "Atenção e cuidado ao atravessar esquinas." },
                    { coords = { -478.19,-1224.23,22.07,0.0 }, text = "Dirigir embriagado é crime!" },
                    { coords = { -539.65,-980.96,23.37,0.0 }, text = "O limite de velocidade das auto-estradas é de 120Km/h.", limiteSpeed = 120 },
                    { coords = { -615.3,-954.67,21.48,87.88 }, text = "É proíbido estacionar em áreas cuja uma faixa vermelha está pintada na calçada." },
                    { coords = { -663.95,-1042.69,17.15,136.07 }, text = "O limite de velocidade de áreas comerciais é de 80Km/h.", limiteSpeed = 80 },
                    { coords = { -753.62,-1102.31,10.73,119.06 }, text = "O limite de velocidade de áreas residenciais é de 60Km/h.", limiteSpeed = 60 },
                    { coords = { -707.3,-1220.12,10.62,215.44 }, text = "Transitar com veículos danificados é crime!" },
                    { coords = { -659.32,-1438.86,10.58,175.75 }, text = "Veículos de emergência possuem prioridade, de passagem!" },
                    { coords = { -695.01,-1573.12,18.3,138.9 }, text = "Você terminou seu teste, estacione na auto-escola para finalizar o percurso." },
                    { coords = { -710.63,-1681.88,25.0,87.88 }, text = "Aguarde, o examinador dará o resultado." },
                },
            },
            [2] = {  
                vehicles = {"golg9"},
                maxErros = 3,
                instructor = "s_m_y_uscg_01",
                spawn = { 
                    {-715.88,-1689.86,25.0,0.0} 
                },
                route = {
                    { coords = { -676.48,-1768.48,24.97,209.77 }, text = "Verifique os dois lados da via, para garantir que está livre para prosseguir." },
                    { coords = { -504.27,-1796.43,21.96,337.33 }, text = "Não é obrigatório esperar os semafaros, porém você deve parar em todos e garantir que a via está livre para seguir." },
                    { coords = { -270.29,-1454.1,31.32,357.17 }, text = "Mantenha uma distância segura do veículo à frente." },
                    { coords = { -438.75,-1417.75,29.32,76.54 }, text = "Atenção e cuidado ao atravessar esquinas." },
                    { coords = { -478.19,-1224.23,22.07,0.0 }, text = "Dirigir embriagado é crime!" },
                    { coords = { -539.65,-980.96,23.37,0.0 }, text = "O limite de velocidade das auto-estradas é de 120Km/h.", limiteSpeed = 120 },
                    { coords = { -615.3,-954.67,21.48,87.88 }, text = "É proíbido estacionar em áreas cuja uma faixa vermelha está pintada na calçada." },
                    { coords = { -663.95,-1042.69,17.15,136.07 }, text = "O limite de velocidade de áreas comerciais é de 80Km/h.", limiteSpeed = 80 },
                    { coords = { -753.62,-1102.31,10.73,119.06 }, text = "O limite de velocidade de áreas residenciais é de 60Km/h.", limiteSpeed = 60 },
                    { coords = { -707.3,-1220.12,10.62,215.44 }, text = "Transitar com veículos danificados é crime!" },
                    { coords = { -659.32,-1438.86,10.58,175.75 }, text = "Veículos de emergência possuem prioridade, de passagem!" },
                    { coords = { -695.01,-1573.12,18.3,138.9 }, text = "Você terminou seu teste, estacione na auto-escola para finalizar o percurso." },
                    { coords = { -710.63,-1681.88,25.0,87.88 }, text = "Aguarde, o examinador dará o resultado." },
                },
            },
            [3] = {  
                vehicles = {"coachrv"},
                maxErros = 3,
                instructor = "ig_mp_agent14",
                spawn = { 
                    {-711.85,-1682.29,25.0,272.13} 
                },
                route = {
                    { coords = { -676.48,-1768.48,24.97,209.77 }, text = "Verifique os dois lados da via, para garantir que está livre para prosseguir." },
                    { coords = { -504.27,-1796.43,21.96,337.33 }, text = "Não é obrigatório esperar os semafaros, porém você deve parar em todos e garantir que a via está livre para seguir." },
                    { coords = { -270.29,-1454.1,31.32,357.17 }, text = "Mantenha uma distância segura do veículo à frente." },
                    { coords = { -438.75,-1417.75,29.32,76.54 }, text = "Atenção e cuidado ao atravessar esquinas." },
                    { coords = { -478.19,-1224.23,22.07,0.0 }, text = "Dirigir embriagado é crime!" },
                    { coords = { -539.65,-980.96,23.37,0.0 }, text = "O limite de velocidade das auto-estradas é de 120Km/h.", limiteSpeed = 120 },
                    { coords = { -615.3,-954.67,21.48,87.88 }, text = "É proíbido estacionar em áreas cuja uma faixa vermelha está pintada na calçada." },
                    { coords = { -663.95,-1042.69,17.15,136.07 }, text = "O limite de velocidade de áreas comerciais é de 80Km/h.", limiteSpeed = 80 },
                    { coords = { -753.62,-1102.31,10.73,119.06 }, text = "O limite de velocidade de áreas residenciais é de 60Km/h.", limiteSpeed = 60 },
                    { coords = { -707.3,-1220.12,10.62,215.44 }, text = "Transitar com veículos danificados é crime!" },
                    { coords = { -659.32,-1438.86,10.58,175.75 }, text = "Veículos de emergência possuem prioridade, de passagem!" },
                    { coords = { -695.01,-1573.12,18.3,138.9 }, text = "Você terminou seu teste, estacione na auto-escola para finalizar o percurso." },
                    { coords = { -710.63,-1681.88,25.0,87.88 }, text = "Aguarde, o examinador dará o resultado." },
                },
            },
            [4] = {  
                vehicles = {"hauler"},
                maxErros = 3,
                instructor = "cs_drfriedlander",
                spawn = { 
                    {-711.85,-1682.29,25.0,272.13} 
                },
                route = {
                    { coords = { -676.48,-1768.48,24.97,209.77 }, text = "Verifique os dois lados da via, para garantir que está livre para prosseguir." },
                    { coords = { -504.27,-1796.43,21.96,337.33 }, text = "Não é obrigatório esperar os semafaros, porém você deve parar em todos e garantir que a via está livre para seguir." },
                    { coords = { -270.29,-1454.1,31.32,357.17 }, text = "Mantenha uma distância segura do veículo à frente." },
                    { coords = { -438.75,-1417.75,29.32,76.54 }, text = "Atenção e cuidado ao atravessar esquinas." },
                    { coords = { -478.19,-1224.23,22.07,0.0 }, text = "Dirigir embriagado é crime!" },
                    { coords = { -539.65,-980.96,23.37,0.0 }, text = "O limite de velocidade das auto-estradas é de 120Km/h.", limiteSpeed = 120 },
                    { coords = { -615.3,-954.67,21.48,87.88 }, text = "É proíbido estacionar em áreas cuja uma faixa vermelha está pintada na calçada." },
                    { coords = { -663.95,-1042.69,17.15,136.07 }, text = "O limite de velocidade de áreas comerciais é de 80Km/h.", limiteSpeed = 80 },
                    { coords = { -753.62,-1102.31,10.73,119.06 }, text = "O limite de velocidade de áreas residenciais é de 60Km/h.", limiteSpeed = 60 },
                    { coords = { -707.3,-1220.12,10.62,215.44 }, text = "Transitar com veículos danificados é crime!" },
                    { coords = { -659.32,-1438.86,10.58,175.75 }, text = "Veículos de emergência possuem prioridade, de passagem!" },
                    { coords = { -695.01,-1573.12,18.3,138.9 }, text = "Você terminou seu teste, estacione na auto-escola para finalizar o percurso." },
                    { coords = { -710.63,-1681.88,25.0,87.88 }, text = "Aguarde, o examinador dará o resultado." },
                },
            },
        }
    },
}

ListQuestions = {
    [1] = {
        {            
            pergunta = 'Condutores que possuem habilitação A, podem dirigir quais veículos?',
            a = 'Todos veículo, menos trem.',
            b = 'Avião de caça e carro hatch.',
            c = 'Veículos motorizados com duas/três rodas.',
            d = 'Apenas carro.',
            resposta = 'C'
        },{                     
            pergunta = 'A carteira B, permite que o condutor transite com qual veículo?',
            a = 'Carro',
            b = 'Moto',
            c = 'Caminhão',
            d = 'Ônibus',
            resposta = 'A'
        },{                         
            pergunta = 'Estacionar o veículo na contramão, será punido com ?',
            a = 'Multa de dez mil dólares.',
            b = 'Não será punido, pois é permitido por lei.',
            c = 'Multa e apreensão do veículo.',
            d = 'Apreensão do veículo, multa, condenado a cadeira elétrica.',
            resposta = 'C'
        },{                      
            pergunta = 'Transitar com o veículo em mau estado de conservação e segurança é considerada uma infração, podendo ser punida com ?',
            a = 'Multa',
            b = 'Multa e apreensão do veículo.',
            c = 'Multa e retenção do veículo até ocorrer a regularização.',
            d = 'Cadeia.',
            resposta = 'C'
        },{
            pergunta = 'Em caso de acidente de trânsito com vítima(s), podemos dizer que primeiros socorros são ?',
            a = 'as providências tomadas no local, iniciais e temporárias, até a chegada de socorro',
            b = 'o pronto atendimento da(s) vítima(s) em substituição às equipes da saúde',
            c = 'as ações que só podem ser realizadas por equipes profissionais',
            d = 'procedimentos de competência exclusiva de médicos no local do acidente',
            resposta = 'A'
        },{
            pergunta = 'Caso você esteja sendo ultrapassado por um veículo em uma rodovia, o que você deve fazer?',
            a = 'Acelerar o carro para evitar ser ultrapassado',
            b = 'Abrir a janela e xingar o outro motorista que está indo rápido demais.',
            c = 'Reduzir a velocidade para que o outro veículo consiga ultrapassar com segurança.',
            d = 'Jogar seu carro para cima do outro veículo para bater e jogar ele no acostamento.',
            resposta = 'C'
        },{
            pergunta = 'A distância percorrida pelo veículo do momento em que o condutor tira o pé do acelerador e o coloca sobre o pedal do freio é denominada ?',
            a = 'distância de frenagem',
            b = 'distância de seguimento',
            c = 'distância de reação',
            d = 'distância de parada',
            resposta = 'C'
        },{
            pergunta = 'Quando o motorista estacionar junto de hidrantes de incêndio devidamente identificados, terá como medida administrativa ?',
            a = 'remoção do veículo',
            b = 'recolhimento do CRLV',
            c = 'retenção do veículo',
            d = 'recolhimento da CNH',
            resposta = 'A'
        },{
            pergunta = 'A remoção do veículo pode ocorrer quando o condutor ?',
            a = 'Parar o veículo em um estacionamento',
            b = 'Não pagar seus impostos ou deixar carro estacionado em local impróprio',
            c = 'Dançar em lugar público',
            d = 'Andar com quantidade excessiva de pizzas em seu veículo',
            resposta = 'B'
        },{
            pergunta = 'O condutor que for pego andando de moto sem capacete, será punido com ?',
            a = 'Amor e carinho.',
            b = 'Somente uma multa de cem dólares',
            c = 'Não será punido pois é permitido por lei',
            d = 'Multa, apreensão do veículo.',
            resposta = 'D'
        },{
            pergunta = 'O condutor que for pego promovendo ou participando de competições esportivas na via pública, sem autorização, será punido com',
            a = 'Multa de quatrocentos dólares e pode ficar de 2 a 5 anos preso.',
            b = 'Multa, remoção da sua habilitação, apreensão do veículo.',
            c = 'Uma passagem para o Brasil',
            d = 'Multa e perde direito de utilizar o banco da cidade',
            resposta = 'B'
        },{
            pergunta = 'Caso seu pneu furar, você deve ?',
            a = 'Parar meu carro e chamar um mecânico porque não é possível andar sem pneu.',
            b = 'Andar devagar porque está furado e chamar a polícia',
            c = 'Andar mais rápido possível para evitar capotar',
            d = 'Acelerar máximo possível até perder a roda também',
            resposta = 'A'
        },{
            pergunta = 'Caso você possuir apenas habilitação A e for pego dirigindo um carro, você pode ser punido ?',
            a = 'Multa de 100 doláres, apreensão de veículo e retenção da sua habilitação',
            b = 'Apreendido e encaminhado a delegacia',
            c = 'Multa de 500 dólares e remoção de veículo.',
            d = 'Multa de 100 dólares e 2 anos de prisão',
            resposta = 'A'
        },{
            pergunta = 'O objetivo principal da sinalização de trânsito é ?',
            a = 'Controlar a velocidade dos veículos',
            b = 'Garantir uma via com bom fluxo e segura',
            c = 'Enfeitar a cidade',
            d = 'Proporcionar um ambiente amigável para motoristas',
            resposta = 'B'
        },
    },   
    [2] = {
        {            
            pergunta = 'Condutores que possuem habilitação A, podem dirigir quais veículos?',
            a = 'Todos veículo, menos trem.',
            b = 'Avião de caça e carro hatch.',
            c = 'Veículos motorizados com duas/três rodas.',
            d = 'Apenas carro.',
            resposta = 'C'
        },{                     
            pergunta = 'A carteira B, permite que o condutor transite com qual veículo?',
            a = 'Carro',
            b = 'Moto',
            c = 'Caminhão',
            d = 'Ônibus',
            resposta = 'A'
        },{                         
            pergunta = 'Estacionar o veículo na contramão, será punido com ?',
            a = 'Multa de dez mil dólares.',
            b = 'Não será punido, pois é permitido por lei.',
            c = 'Multa e apreensão do veículo.',
            d = 'Apreensão do veículo, multa, condenado a cadeira elétrica.',
            resposta = 'C'
        },{                      
            pergunta = 'Transitar com o veículo em mau estado de conservação e segurança é considerada uma infração, podendo ser punida com ?',
            a = 'Multa',
            b = 'Multa e apreensão do veículo.',
            c = 'Multa e retenção do veículo até ocorrer a regularização.',
            d = 'Cadeia.',
            resposta = 'C'
        },{
            pergunta = 'Em caso de acidente de trânsito com vítima(s), podemos dizer que primeiros socorros são ?',
            a = 'as providências tomadas no local, iniciais e temporárias, até a chegada de socorro',
            b = 'o pronto atendimento da(s) vítima(s) em substituição às equipes da saúde',
            c = 'as ações que só podem ser realizadas por equipes profissionais',
            d = 'procedimentos de competência exclusiva de médicos no local do acidente',
            resposta = 'A'
        },{
            pergunta = 'Caso você esteja sendo ultrapassado por um veículo em uma rodovia, o que você deve fazer?',
            a = 'Acelerar o carro para evitar ser ultrapassado',
            b = 'Abrir a janela e xingar o outro motorista que está indo rápido demais.',
            c = 'Reduzir a velocidade para que o outro veículo consiga ultrapassar com segurança.',
            d = 'Jogar seu carro para cima do outro veículo para bater e jogar ele no acostamento.',
            resposta = 'C'
        },{
            pergunta = 'A distância percorrida pelo veículo do momento em que o condutor tira o pé do acelerador e o coloca sobre o pedal do freio é denominada ?',
            a = 'distância de frenagem',
            b = 'distância de seguimento',
            c = 'distância de reação',
            d = 'distância de parada',
            resposta = 'C'
        },{
            pergunta = 'Quando o motorista estacionar junto de hidrantes de incêndio devidamente identificados, terá como medida administrativa ?',
            a = 'remoção do veículo',
            b = 'recolhimento do CRLV',
            c = 'retenção do veículo',
            d = 'recolhimento da CNH',
            resposta = 'A'
        },{
            pergunta = 'A remoção do veículo pode ocorrer quando o condutor ?',
            a = 'Parar o veículo em um estacionamento',
            b = 'Não pagar seus impostos ou deixar carro estacionado em local impróprio',
            c = 'Dançar em lugar público',
            d = 'Andar com quantidade excessiva de pizzas em seu veículo',
            resposta = 'B'
        },{
            pergunta = 'O condutor que for pego andando de moto sem capacete, será punido com ?',
            a = 'Amor e carinho.',
            b = 'Somente uma multa de cem dólares',
            c = 'Não será punido pois é permitido por lei',
            d = 'Multa, apreensão do veículo.',
            resposta = 'D'
        },{
            pergunta = 'O condutor que for pego promovendo ou participando de competições esportivas na via pública, sem autorização, será punido com',
            a = 'Multa de quatrocentos dólares e pode ficar de 2 a 5 anos preso.',
            b = 'Multa, remoção da sua habilitação, apreensão do veículo.',
            c = 'Uma passagem para o Brasil',
            d = 'Multa e perde direito de utilizar o banco da cidade',
            resposta = 'B'
        },{
            pergunta = 'Caso seu pneu furar, você deve ?',
            a = 'Parar meu carro e chamar um mecânico porque não é possível andar sem pneu.',
            b = 'Andar devagar porque está furado e chamar a polícia',
            c = 'Andar mais rápido possível para evitar capotar',
            d = 'Acelerar máximo possível até perder a roda também',
            resposta = 'A'
        },{
            pergunta = 'Caso você possuir apenas habilitação A e for pego dirigindo um carro, você pode ser punido ?',
            a = 'Multa de 100 doláres, apreensão de veículo e retenção da sua habilitação',
            b = 'Apreendido e encaminhado a delegacia',
            c = 'Multa de 500 dólares e remoção de veículo.',
            d = 'Multa de 100 dólares e 2 anos de prisão',
            resposta = 'A'
        },{
            pergunta = 'O objetivo principal da sinalização de trânsito é ?',
            a = 'Controlar a velocidade dos veículos',
            b = 'Garantir uma via com bom fluxo e segura',
            c = 'Enfeitar a cidade',
            d = 'Proporcionar um ambiente amigável para motoristas',
            resposta = 'B'
        },
    },  
    [3] = {
        {            
            pergunta = 'Condutores que possuem habilitação A, podem dirigir quais veículos?',
            a = 'Todos veículo, menos trem.',
            b = 'Avião de caça e carro hatch.',
            c = 'Veículos motorizados com duas/três rodas.',
            d = 'Apenas carro.',
            resposta = 'C'
        },{                     
            pergunta = 'A carteira B, permite que o condutor transite com qual veículo?',
            a = 'Carro',
            b = 'Moto',
            c = 'Caminhão',
            d = 'Ônibus',
            resposta = 'A'
        },{                         
            pergunta = 'Estacionar o veículo na contramão, será punido com ?',
            a = 'Multa de dez mil dólares.',
            b = 'Não será punido, pois é permitido por lei.',
            c = 'Multa e apreensão do veículo.',
            d = 'Apreensão do veículo, multa, condenado a cadeira elétrica.',
            resposta = 'C'
        },{                      
            pergunta = 'Transitar com o veículo em mau estado de conservação e segurança é considerada uma infração, podendo ser punida com ?',
            a = 'Multa',
            b = 'Multa e apreensão do veículo.',
            c = 'Multa e retenção do veículo até ocorrer a regularização.',
            d = 'Cadeia.',
            resposta = 'C'
        },{
            pergunta = 'Em caso de acidente de trânsito com vítima(s), podemos dizer que primeiros socorros são ?',
            a = 'as providências tomadas no local, iniciais e temporárias, até a chegada de socorro',
            b = 'o pronto atendimento da(s) vítima(s) em substituição às equipes da saúde',
            c = 'as ações que só podem ser realizadas por equipes profissionais',
            d = 'procedimentos de competência exclusiva de médicos no local do acidente',
            resposta = 'A'
        },{
            pergunta = 'Caso você esteja sendo ultrapassado por um veículo em uma rodovia, o que você deve fazer?',
            a = 'Acelerar o carro para evitar ser ultrapassado',
            b = 'Abrir a janela e xingar o outro motorista que está indo rápido demais.',
            c = 'Reduzir a velocidade para que o outro veículo consiga ultrapassar com segurança.',
            d = 'Jogar seu carro para cima do outro veículo para bater e jogar ele no acostamento.',
            resposta = 'C'
        },{
            pergunta = 'A distância percorrida pelo veículo do momento em que o condutor tira o pé do acelerador e o coloca sobre o pedal do freio é denominada ?',
            a = 'distância de frenagem',
            b = 'distância de seguimento',
            c = 'distância de reação',
            d = 'distância de parada',
            resposta = 'C'
        },{
            pergunta = 'Quando o motorista estacionar junto de hidrantes de incêndio devidamente identificados, terá como medida administrativa ?',
            a = 'remoção do veículo',
            b = 'recolhimento do CRLV',
            c = 'retenção do veículo',
            d = 'recolhimento da CNH',
            resposta = 'A'
        },{
            pergunta = 'A remoção do veículo pode ocorrer quando o condutor ?',
            a = 'Parar o veículo em um estacionamento',
            b = 'Não pagar seus impostos ou deixar carro estacionado em local impróprio',
            c = 'Dançar em lugar público',
            d = 'Andar com quantidade excessiva de pizzas em seu veículo',
            resposta = 'B'
        },{
            pergunta = 'O condutor que for pego andando de moto sem capacete, será punido com ?',
            a = 'Amor e carinho.',
            b = 'Somente uma multa de cem dólares',
            c = 'Não será punido pois é permitido por lei',
            d = 'Multa, apreensão do veículo.',
            resposta = 'D'
        },{
            pergunta = 'O condutor que for pego promovendo ou participando de competições esportivas na via pública, sem autorização, será punido com',
            a = 'Multa de quatrocentos dólares e pode ficar de 2 a 5 anos preso.',
            b = 'Multa, remoção da sua habilitação, apreensão do veículo.',
            c = 'Uma passagem para o Brasil',
            d = 'Multa e perde direito de utilizar o banco da cidade',
            resposta = 'B'
        },{
            pergunta = 'Caso seu pneu furar, você deve ?',
            a = 'Parar meu carro e chamar um mecânico porque não é possível andar sem pneu.',
            b = 'Andar devagar porque está furado e chamar a polícia',
            c = 'Andar mais rápido possível para evitar capotar',
            d = 'Acelerar máximo possível até perder a roda também',
            resposta = 'A'
        },{
            pergunta = 'Caso você possuir apenas habilitação A e for pego dirigindo um carro, você pode ser punido ?',
            a = 'Multa de 100 doláres, apreensão de veículo e retenção da sua habilitação',
            b = 'Apreendido e encaminhado a delegacia',
            c = 'Multa de 500 dólares e remoção de veículo.',
            d = 'Multa de 100 dólares e 2 anos de prisão',
            resposta = 'A'
        },{
            pergunta = 'O objetivo principal da sinalização de trânsito é ?',
            a = 'Controlar a velocidade dos veículos',
            b = 'Garantir uma via com bom fluxo e segura',
            c = 'Enfeitar a cidade',
            d = 'Proporcionar um ambiente amigável para motoristas',
            resposta = 'B'
        },
    },    
    [4] = {
        {            
            pergunta = 'Condutores que possuem habilitação A, podem dirigir quais veículos?',
            a = 'Todos veículo, menos trem.',
            b = 'Avião de caça e carro hatch.',
            c = 'Veículos motorizados com duas/três rodas.',
            d = 'Apenas carro.',
            resposta = 'C'
        },{                     
            pergunta = 'A carteira B, permite que o condutor transite com qual veículo?',
            a = 'Carro',
            b = 'Moto',
            c = 'Caminhão',
            d = 'Ônibus',
            resposta = 'A'
        },{                         
            pergunta = 'Estacionar o veículo na contramão, será punido com ?',
            a = 'Multa de dez mil dólares.',
            b = 'Não será punido, pois é permitido por lei.',
            c = 'Multa e apreensão do veículo.',
            d = 'Apreensão do veículo, multa, condenado a cadeira elétrica.',
            resposta = 'C'
        },{                      
            pergunta = 'Transitar com o veículo em mau estado de conservação e segurança é considerada uma infração, podendo ser punida com ?',
            a = 'Multa',
            b = 'Multa e apreensão do veículo.',
            c = 'Multa e retenção do veículo até ocorrer a regularização.',
            d = 'Cadeia.',
            resposta = 'C'
        },{
            pergunta = 'Em caso de acidente de trânsito com vítima(s), podemos dizer que primeiros socorros são ?',
            a = 'as providências tomadas no local, iniciais e temporárias, até a chegada de socorro',
            b = 'o pronto atendimento da(s) vítima(s) em substituição às equipes da saúde',
            c = 'as ações que só podem ser realizadas por equipes profissionais',
            d = 'procedimentos de competência exclusiva de médicos no local do acidente',
            resposta = 'A'
        },{
            pergunta = 'Caso você esteja sendo ultrapassado por um veículo em uma rodovia, o que você deve fazer?',
            a = 'Acelerar o carro para evitar ser ultrapassado',
            b = 'Abrir a janela e xingar o outro motorista que está indo rápido demais.',
            c = 'Reduzir a velocidade para que o outro veículo consiga ultrapassar com segurança.',
            d = 'Jogar seu carro para cima do outro veículo para bater e jogar ele no acostamento.',
            resposta = 'C'
        },{
            pergunta = 'A distância percorrida pelo veículo do momento em que o condutor tira o pé do acelerador e o coloca sobre o pedal do freio é denominada ?',
            a = 'distância de frenagem',
            b = 'distância de seguimento',
            c = 'distância de reação',
            d = 'distância de parada',
            resposta = 'C'
        },{
            pergunta = 'Quando o motorista estacionar junto de hidrantes de incêndio devidamente identificados, terá como medida administrativa ?',
            a = 'remoção do veículo',
            b = 'recolhimento do CRLV',
            c = 'retenção do veículo',
            d = 'recolhimento da CNH',
            resposta = 'A'
        },{
            pergunta = 'A remoção do veículo pode ocorrer quando o condutor ?',
            a = 'Parar o veículo em um estacionamento',
            b = 'Não pagar seus impostos ou deixar carro estacionado em local impróprio',
            c = 'Dançar em lugar público',
            d = 'Andar com quantidade excessiva de pizzas em seu veículo',
            resposta = 'B'
        },{
            pergunta = 'O condutor que for pego andando de moto sem capacete, será punido com ?',
            a = 'Amor e carinho.',
            b = 'Somente uma multa de cem dólares',
            c = 'Não será punido pois é permitido por lei',
            d = 'Multa, apreensão do veículo.',
            resposta = 'D'
        },{
            pergunta = 'O condutor que for pego promovendo ou participando de competições esportivas na via pública, sem autorização, será punido com',
            a = 'Multa de quatrocentos dólares e pode ficar de 2 a 5 anos preso.',
            b = 'Multa, remoção da sua habilitação, apreensão do veículo.',
            c = 'Uma passagem para o Brasil',
            d = 'Multa e perde direito de utilizar o banco da cidade',
            resposta = 'B'
        },{
            pergunta = 'Caso seu pneu furar, você deve ?',
            a = 'Parar meu carro e chamar um mecânico porque não é possível andar sem pneu.',
            b = 'Andar devagar porque está furado e chamar a polícia',
            c = 'Andar mais rápido possível para evitar capotar',
            d = 'Acelerar máximo possível até perder a roda também',
            resposta = 'A'
        },{
            pergunta = 'Caso você possuir apenas habilitação A e for pego dirigindo um carro, você pode ser punido ?',
            a = 'Multa de 100 doláres, apreensão de veículo e retenção da sua habilitação',
            b = 'Apreendido e encaminhado a delegacia',
            c = 'Multa de 500 dólares e remoção de veículo.',
            d = 'Multa de 100 dólares e 2 anos de prisão',
            resposta = 'A'
        },{
            pergunta = 'O objetivo principal da sinalização de trânsito é ?',
            a = 'Controlar a velocidade dos veículos',
            b = 'Garantir uma via com bom fluxo e segura',
            c = 'Enfeitar a cidade',
            d = 'Proporcionar um ambiente amigável para motoristas',
            resposta = 'B'
        },
    },           
}

function shuffleKeys(tbl, correctAnswer)
    local Questions = {}
    local correctKey = nil  -- Para armazenar a nova chave da resposta correta após embaralhamento

    for key in pairs(tbl) do
        table.insert(Questions, key)
    end
    -- Embaralhar
    for i = #Questions, 2, -1 do
        local j = math.random(i)
        Questions[i], Questions[j] = Questions[j], Questions[i]
    end

    local numbers = 1
    local shuffled = {}
    for Key,Question in pairs(tbl) do
        shuffled[Key] = tbl[Questions[numbers]]
        if Questions[numbers] == correctAnswer then
            correctKey = Key
        end
        numbers = numbers + 1
    end
    return shuffled, correctKey
end

function Questions(index)
    if ListQuestions[tonumber(index)] then
        local allQuestions = ListQuestions[tonumber(index)]
        local selectedQuestions = getRandomQuestions(9, allQuestions)  -- Substituir por sua própria função
        local data = {}
        for index, value in ipairs(selectedQuestions) do
            local shuffledOptions,correctKey = shuffleKeys({
                ["A"] = value["a"],
                ["B"] = value["b"],
                ["C"] = value["c"],
                ["D"] = value["d"],
            }, value["resposta"])
            table.insert(data, {
                ["id"] = index,
                ["pergunta"] =  value["pergunta"],
                ["a"] = shuffledOptions["A"],
                ["b"] = shuffledOptions["B"],
                ["c"] = shuffledOptions["C"],
                ["d"] = shuffledOptions["D"],
                ["resposta"] = correctKey..index
            })
        end
        return data
    end
end

function getRandomQuestions(n, list)
    local randomIndices = {}
    local randomQuestions = {}
    while #randomIndices < n do
        local randIndex = math.random(1, #list)
        if not randomIndices[randIndex] then
            randomIndices[randIndex] = true
            table.insert(randomQuestions, list[randIndex])
        end
    end
    return randomQuestions
end