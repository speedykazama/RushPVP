fx_version "bodacious"
game "gta5"

client_scripts {
	"@vrp/lib/Utils.lua",
	"@vrp/config/Vehicle.lua",
	"client-side/*.lua",
	"config/*.lua"
}

server_scripts {
	"@vrp/config/Item.lua",
	"@vrp/lib/Utils.lua",
	"@vrp/config/Vehicle.lua",
	"server-side/*.lua",
	"config/*.lua"
}