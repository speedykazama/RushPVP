-----------------------------------------------------------------------------------------------------------------------------------------
-- VRP
-----------------------------------------------------------------------------------------------------------------------------------------
local Tunnel = module("vrp","lib/Tunnel")
local Proxy = module("vrp","lib/Proxy")
vRPC = Tunnel.getInterface("vRP")
vRP = Proxy.getInterface("vRP")
-----------------------------------------------------------------------------------------------------------------------------------------
-- CONNECTION
-----------------------------------------------------------------------------------------------------------------------------------------
local Creative = {}
Tunnel.bindInterface("Night_Desmanche", Creative)
vCLIENT = Tunnel.getInterface("Night_Desmanche")
-----------------------------------------------------------------------------------------------------------------------------------------
-- VARIABLES
-----------------------------------------------------------------------------------------------------------------------------------------
local vehicle_dismantle = {}
-----------------------------------------------------------------------------------------------------------------------------------------
-- CHECKPERM
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.CheckPerm(org_name) 
	local source = source
	local Passport = vRP.Passport(source)
	local org_perm = Config_Desmanche[org_name].Permission

	if Passport then
		if not org_perm or vRP.HasGroup(Passport, org_perm) then
			return true
		else
			TriggerClientEvent("Notify", source, "vermelho", "Sem permissão.", 5000)
			return false
		end
	end

	return false
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- CHECKITEM
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.CheckItem(org_name)
	local source = source
	local Passport = vRP.Passport(source)
	local org_config = Config_Desmanche[org_name]

	if Passport and org_config then
		local itemName = org_config.RequireItem
		local itemAmount = org_config.ItemAmount

		if vRP.ConsultItem(Passport, itemName, itemAmount) then
            vRP.TakeItem(Passport, itemName, itemAmount)
			return true
        else
			TriggerClientEvent("Notify", source, "vermelho", "Você precisa de <b>"..itemAmount.."x Maçarico</b>.", 5000)
		end
	end

	return false
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- SETVEHICLEDISMANTLE
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.setVehicleDismantle(data)
	local source = source
	local Passport = vRP.Passport(source)
	if Passport then
		if not vehicle_dismantle[source] then
			vehicle_dismantle[source] = { veh = data.veh, veh_plate = data.veh_plate }
		end
	end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- DISMANTLEVEHICLE
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.dismantleVehicle(vehicle, veh_plate, veh_name)
    local source = source
    local Passport = vRP.Passport(source)
    local PassportPlate = vRP.PassportPlate(veh_plate)

    if PassportPlate and PassportPlate.Passport then
        if Passport == PassportPlate.Passport then
            TriggerClientEvent("garages:Delete", source, vehicle)
            TriggerClientEvent("Notify", source, "vermelho", "Você não pode desmanchar seu próprio veículo.", 5000)
            return
        end

        if vehicle and veh_plate then
            local identity = vRP.Identity(Passport)
            local OtherPassport = vRP.Identity(PassportPlate.Passport)
            local price_veh = VehiclePrice(veh_name) * Config_Valores.Dinheiro
            local price_fines = VehiclePrice(veh_name) * Config_Valores.Multa

            vRP.GiveItem(Passport, Config_Itens.DinheiroSujo, parseInt(price_veh), true)

            local thumbnailUrl = Config_Discord.Imagem

            PerformHttpRequest(Config_Discord.Webhook, function(err, text, headers) end, 'POST', json.encode({
                username = "NIGHT DESMANCHE",
                embeds = {
                    {
                        title = "🚗 Desmanche de Veículo 🚗",
                        fields = {
                            { 
                                name =  "", 
                                value = "👤 **Quem desmanchou:** " .. Passport .. " • " .. (identity and identity.name .. " " .. identity.name2 or "Desconhecido") ..
                                        "\n🚗 **Veículo desmanchado:** " .. veh_name ..
                                        "\n🛑 **Placa do Veículo:** " .. veh_plate ..
                                        "\n👤 **Proprietário do Veículo:** " .. PassportPlate.Passport .. " • " .. (OtherPassport and OtherPassport.name .. " " .. OtherPassport.name2 or "Desconhecido") ..
                                        os.date("\n\n**⏰ ・ %d/%m/%Y - %H:%M:%S**")
                            },
                        },
                        footer = { 
                            text = ("Night Store • Todos Direitos Reservados.")
                        },
                        thumbnail = {
                            url = thumbnailUrl
                        },
                        color = 16711680
                    }
                }
            }), { ['Content-Type'] = 'application/json' })

            TriggerClientEvent("garages:Delete", source, vehicle)
            vehicle_dismantle[source] = nil

            if OtherPassport then
                vRP.GiveFine(PassportPlate.Passport, parseInt(price_fines))
                exports["bank"]:AddFines(PassportPlate.Passport, Passport, parseInt(price_fines), "Desmanche de veículo")

                TriggerClientEvent("Notify", source, "verde", "Multa aplicada ao dono do veículo.", 5000)
            end
        else
            TriggerClientEvent("garages:Delete", source, vehicle)
            TriggerClientEvent("Notify", source, "amarelo", "Veículo incorreto!", 5000)
        end
    else
        TriggerClientEvent("garages:Delete", source, vehicle)
        TriggerClientEvent("Notify", source, "amarelo", "Placa do veículo não encontrada!", 5000)
    end
end