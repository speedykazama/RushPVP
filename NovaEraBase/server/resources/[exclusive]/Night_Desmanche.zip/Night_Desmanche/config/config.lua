Config_Desmanche = {
    Desmanche_1 = {
        Permission = "P77",         --  Deixe nil para ficar sem permissão
        RequireItem = "macarico",
        ItemAmount = 50,
        Locations = {
            Init = vector3( 1942.67,384.56,173.23 ),
            Body = vector3( 1933.05,381.55,173.23 ),
            Tire = vector3( 1933.05,381.55,173.23 ),
        }
    },
    Desmanche_2 = {
        Permission = "Favela6",
        RequireItem = "macarico",
        ItemAmount = 50,
        Locations = {
            Init = vector3( -2356.56,2632.16,20.22 ),
            Body = vector3( -2364.88,2634.49,20.22 ),
            Tire = vector3( -2364.88,2634.49,20.22 ),
        }
    }
}

Config_Itens = {
    DinheiroSujo = "dollarsroll", -- Item que representa o dinheiro sujo
}

Config_Valores = {
    Dinheiro = 0.20, -- Valor para cálculo do dinheiro sujo (20% do valor do veículo retido)
    Multa = 0.10,   -- Valor para cálculo da multa (10% do valor do veículo)
}

Config_Discord = {
    Webhook = "",
    Imagem = ""
}