-----------------------------------------------------------------------------------------------------------------------------------------
-- VRP
-----------------------------------------------------------------------------------------------------------------------------------------
local Tunnel = module("vrp","lib/Tunnel")
local Proxy = module("vrp","lib/Proxy")
vRP = Proxy.getInterface("vRP")
-----------------------------------------------------------------------------------------------------------------------------------------
-- CONNECTION
-----------------------------------------------------------------------------------------------------------------------------------------
Creative = {}
Tunnel.bindInterface("cemitery",Creative)
vSERVER = Tunnel.getInterface("cemitery")
-----------------------------------------------------------------------------------------------------------------------------------------
-- VARIABLES
-----------------------------------------------------------------------------------------------------------------------------------------
local Selected = nil
local CheckItem = 0
local SpawnPed = nil
local Active = false
local Blip = nil
-----------------------------------------------------------------------------------------------------------------------------------------
-- SPAWNNEWNPC
-----------------------------------------------------------------------------------------------------------------------------------------
function SpawnNewNPC()
    CheckItem = 0
    Selected = math.random(#LocationsCemitery)
    local PedSelected = math.random(#PedListCemitery)

    if Blip then
        RemoveBlip(Blip)
        Blip = nil
    end

    if SpawnPed and DoesEntityExist(SpawnPed) then
        DeleteEntity(SpawnPed)
        SpawnPed = nil
    end

    if LoadModel(PedListCemitery[PedSelected]) then
        SpawnPed = CreatePed(4, PedListCemitery[PedSelected], LocationsCemitery[Selected][1], LocationsCemitery[Selected][2], LocationsCemitery[Selected][3] - 1, LocationsCemitery[Selected][4] - 180.0, false, false)

        SetPedArmour(SpawnPed, 99)
        SetEntityInvincible(SpawnPed, true)
        FreezeEntityPosition(SpawnPed, true)
        SetBlockingOfNonTemporaryEvents(SpawnPed, true)

        SetModelAsNoLongerNeeded(PedListCemitery[PedSelected])

        if LoadAnim("dead") then
            TaskPlayAnim(SpawnPed, "dead", "dead_a", 8.0, 8.0, -1, 1, 0, 0, 0, 0)
        end

        exports["target"]:AddCircleZone("Cemitery:"..Selected, vec3(LocationsCemitery[Selected][1], LocationsCemitery[Selected][2], LocationsCemitery[Selected][3]), 0.5, {
            name = "Cemitery:"..Selected,
            heading = 3374176
        }, {
            Distance = 1.0,
            options = {
                {
                    event = "cemitery:finishBody",
                    label = "Pegar Pertences",
                    tunnel = "client"
                }
            }
        })

        Blip = AddBlipForCoord(LocationsCemitery[Selected][1], LocationsCemitery[Selected][2], LocationsCemitery[Selected][3])
        SetBlipSprite(Blip, 280)
        SetBlipColour(Blip, 3)
        SetBlipScale(Blip, 0.7)
        SetBlipAsShortRange(Blip, false)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString("Cadaver")
        EndTextCommandSetBlipName(Blip)

        TriggerEvent("Notify", "amarelo", "Parece que estão efetuando uma limpeza em um dos túmulos, guarde essa informação e veja se você encontra alguns objetos de valor.", 10000)
    end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- TARGET
-----------------------------------------------------------------------------------------------------------------------------------------
CreateThread(function()
    exports["target"]:AddCircleZone("Cemitery", InitWorkCemitery, 1.5, {
        name = "Cemitery",
        heading = 3374176
    }, {
        Distance = 1.0,
        options = {
            {
                event = "cemitery:Init",
                label = "Trabalhar",
                tunnel = "client"
            }, {
                event = "preset:cemitery",
                label = "Traje Coveiro",
                tunnel = "server"
            }, {
                event = "shops:Cemitery",
                label = "Vender Itens",
                tunnel = "client"
            }
        }
    })
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- CEMITERY:INIT
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("cemitery:Init")
AddEventHandler("cemitery:Init", function()
    if vSERVER.CheckWork(CheckWorkCemitery) then
		if Active then
			if Selected ~= nil then
				exports["target"]:RemCircleZone("Cemitery:"..Selected)
				Selected = nil
			end

			if SpawnPed and DoesEntityExist(SpawnPed) then
				DeleteEntity(SpawnPed)
				SpawnPed = nil
			end

			if Blip then
				RemoveBlip(Blip)
				Blip = nil
			end

			exports["target"]:LabelText("Cemitery", "Trabalhar")
			TriggerEvent("Notify", "amarelo", "Trabalho finalizado.", 5000)
			Active = false
			CheckItem = 0
		else
			Active = true
			exports["target"]:LabelText("Cemitery", "Finalizar")
			TriggerEvent("Notify", "verde", "Trabalho iniciado.", 5000)

			SpawnNewNPC()
		end
    end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- CEMITERY:FINISHBODY
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("cemitery:finishBody")
AddEventHandler("cemitery:finishBody", function()
    TriggerEvent("Progress", "Coletando Pertences", 2500)
    vRP.playAnim(false, {"amb@prop_human_parking_meter@female@idle_a", "idle_a_female"}, true)
    Wait(2500)
    vRP.stopAnim()

    TriggerServerEvent("cemitery:payment")
    CheckItem = CheckItem + 1

    if CheckItem >= MaxCollectionsPerNPC then
        exports["target"]:RemCircleZone("Cemitery:"..Selected)

        if SpawnPed and DoesEntityExist(SpawnPed) then
            DeleteEntity(SpawnPed)
            SpawnPed = nil
        end

        if Blip then
            RemoveBlip(Blip)
            Blip = nil
        end

        Selected = nil

        SpawnNewNPC()
    end
end)