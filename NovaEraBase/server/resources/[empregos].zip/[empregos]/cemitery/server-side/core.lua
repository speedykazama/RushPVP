-----------------------------------------------------------------------------------------------------------------------------------------
-- VRP
-----------------------------------------------------------------------------------------------------------------------------------------
local Tunnel = module("vrp","lib/Tunnel")
local Proxy = module("vrp","lib/Proxy")
vRP = Proxy.getInterface("vRP")
-----------------------------------------------------------------------------------------------------------------------------------------
-- CONNECTION
-----------------------------------------------------------------------------------------------------------------------------------------
Creative = {}
Tunnel.bindInterface("cemitery",Creative)
vINVENTORY = Tunnel.getInterface("inventory")
-----------------------------------------------------------------------------------------------------------------------------------------
-- CEMITERY:PAYMENT
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("cemitery:payment")
AddEventHandler("cemitery:payment", function()
    local source = source
    local Passport = vRP.Passport(source)
    if Passport then
        local Experience = vRP.GetExperience(Passport, ExperienceWorkCemitery)
        local Category = ClassCategory(Experience)
        local Valuation = PaymentDefaultCemitery + (CategoryIncrementsCemitery[Category] or 0)

        vRP.PutExperience(Passport, ExperienceWorkCemitery, LevelExperienceWorkCemitery)

        local RandomItem = math.random(1, #ItensWorkCemitery)
        local Data = ItensWorkCemitery[RandomItem]
        local Amount = math.random(Data.Amount[1], Data.Amount[2])

        local weight = vRP.GetItemWeight(Data.item) or 0
        if (vRP.InventoryWeight(Passport) + weight * Amount) <= vRP.GetWeight(Passport) then
            vRP.GenerateItem(Passport, Data.item, Amount, true)
        else
            exports["inventory"]:Drops(Passport, source, Data.item, Amount)
            TriggerClientEvent("Notify", source, "amarelo", "Mochila cheia, sua recompensa foi dropada no chão.", 5000)
        end

        vRP.GenerateItem(Passport, ItemPaymentCemitery, Valuation, true)
    end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- PRESET:BUS
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("preset:cemitery")
AddEventHandler("preset:cemitery", function(Number)
    local source = source
    local Passport = vRP.Passport(source)
    if Passport then
        local Model = vRP.ModelPlayer(source)

        if Model == "mp_m_freemode_01" or Model == "mp_f_freemode_01" then
            TriggerClientEvent("skinshop:Apply", source, PresetCemitery[Model])
			TriggerClientEvent('Notify', source, 'verde', 'Você vestiu o Traje de Coveiro', 5000)
        end
    end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- CHECKWORK
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.CheckWork(Work)
	local source = source
	local Passport = vRP.Passport(source)
	if Passport then
		if vRP.GetWork(Passport) == Work then
			return true
		else
			TriggerClientEvent("Notify", source, "amarelo", "Você precisa ter a sua <b>Carteira de Trabalho</b> assinada no emprego de <b>"..ClassWork(Work).."</b> para conseguir trabalhar aqui.",  5000)
		end

		return false
	end
end