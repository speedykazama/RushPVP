fx_version "bodacious"
game "gta5"
lua54 "yes"

shared_scripts {
    "shared-side/*",
    "@vrp/lib/Utils.lua"
}

client_scripts {
    "@vrp/config/Global.lua",
    "@vrp/lib/Utils.lua",
    "@vrp/config/Native.lua",
    "client-side/*"
}

server_scripts {
    "@vrp/config/Global.lua",
    "@vrp/lib/Utils.lua",
    "server-side/*"
}