-----------------------------------------------------------------------------------------------------------------------------------------
-- VRP
-----------------------------------------------------------------------------------------------------------------------------------------
local Tunnel = module("vrp","lib/Tunnel")
local Proxy = module("vrp","lib/Proxy")
vRP = Proxy.getInterface("vRP")
-----------------------------------------------------------------------------------------------------------------------------------------
-- CONNECTION
-----------------------------------------------------------------------------------------------------------------------------------------
Creative = {}
Tunnel.bindInterface("postop", Creative)
vSERVER = Tunnel.getInterface("postop")
-----------------------------------------------------------------------------------------------------------------------------------------
-- VARIABLES
-----------------------------------------------------------------------------------------------------------------------------------------
local BoxVehicles = {}
-----------------------------------------------------------------------------------------------------------------------------------------
-- ADDPACKAGE
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.AddPackage(Plate)
	if BoxVehicles[Plate] == nil then
		BoxVehicles[Plate] = 1
	else
		if BoxVehicles[Plate] < MaximumPackages then
			BoxVehicles[Plate] = BoxVehicles[Plate] + 1
		else
			TriggerClientEvent("Notify", source, "amarelo", "Vocé excedeu o limite de caixas.", 5000)
			return false
		end
	end

	TriggerClientEvent("postop:Update", -1, BoxVehicles)
	return true
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- PAYMENTPACKAGE
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.PaymentPackage()
    local source = source
    local Passport = vRP.Passport(source)
    if Passport then
        local Experience = vRP.GetExperience(Passport, ExperienceWorkPostOp)
        local Category = ClassCategory(Experience)
        local Valuation = PaymentDefaultPostOp + (CategoryIncrementsPostOp[Category] or 0)

        vRP.PutExperience(Passport, ExperienceWorkPostOp, LevelExperienceWorkPostOp)
        vRP.GenerateItem(Passport, ItemPaymentPostOp, Valuation, true)
    end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- PRESET:POSTOP
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("preset:postop")
AddEventHandler("preset:postop", function(Number)
    local source = source
    local Passport = vRP.Passport(source)
    if Passport then
        local Model = vRP.ModelPlayer(source)

        if Model == "mp_m_freemode_01" or Model == "mp_f_freemode_01" then
            TriggerClientEvent("skinshop:Apply", source, PresetPostOp[Model])
			TriggerClientEvent('Notify', source, 'verde', 'Você vestiu o Traje de Carteiro', 5000)
        end
    end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- CHECKWORK
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.CheckWork(Work)
	local source = source
	local Passport = vRP.Passport(source)
	if Passport then
		if vRP.GetWork(Passport) == Work then
			return true
		else
			TriggerClientEvent("Notify", source, "amarelo", "Você precisa ter a sua <b>Carteira de Trabalho</b> assinada no emprego de <b>"..ClassWork(Work).."</b> para conseguir trabalhar aqui.",  5000)
		end

		return false
	end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- POSTOP:REMOVE
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("postop:Remove")
AddEventHandler("postop:Remove", function(Plate)
	if BoxVehicles[Plate] then
		BoxVehicles[Plate] = BoxVehicles[Plate] - 1

		if BoxVehicles[Plate] <= 0 then
			BoxVehicles[Plate] = nil
		end

		TriggerClientEvent("postop:Update", -1, BoxVehicles)
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- CONNECT
-----------------------------------------------------------------------------------------------------------------------------------------
AddEventHandler("Connect", function(Passport, source)
	TriggerClientEvent("postop:Update", source, BoxVehicles)
end)