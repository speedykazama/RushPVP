-----------------------------------------------------------------------------------------------------------------------------------------
-- VRP
-----------------------------------------------------------------------------------------------------------------------------------------
local Tunnel = module("vrp","lib/Tunnel")
local Proxy = module("vrp","lib/Proxy")
vRP = Proxy.getInterface("vRP")
-----------------------------------------------------------------------------------------------------------------------------------------
-- CONNECTION
-----------------------------------------------------------------------------------------------------------------------------------------
vSERVER = Tunnel.getInterface("towdriver")
vGARAGE = Tunnel.getInterface("garages")
-----------------------------------------------------------------------------------------------------------------------------------------
-- VARIABLES
-----------------------------------------------------------------------------------------------------------------------------------------
local inTowed = nil
local VehTower = nil
local SpawnSelect = 0
local SpawnCoords = 0
local Active = false
local SpawnVehicle = false
local TimeService = GetGameTimer()
-----------------------------------------------------------------------------------------------------------------------------------------
-- TARGET
-----------------------------------------------------------------------------------------------------------------------------------------
CreateThread(function()
	exports["target"]:AddCircleZone("Towdriver", InitWorkTowdriver, 1.5, {
		name = "Towdriver",
		heading = 3374176
	},{
		Distance = 1.5,
		options = {
			{
				event = "towdriver:Init",
				label = "Trabalhar",
				tunnel = "client"
			},{
				event = "preset:towdriver",
				label = "Traje Rebocador",
				tunnel = "server"
			},{
				event = "garages:Impound",
				label = "Apreendidos",
				tunnel = "shop"
			}
		}
	})
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- TOWDRIVER:INIT
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("towdriver:Init")
AddEventHandler("towdriver:Init",function()
	if GetGameTimer() >= TimeService then
		TimeService = GetGameTimer() + 2000
		if vSERVER.CheckWork(CheckWorkTowdriver) then
			if Active then
				exports["target"]:LabelText("Towdriver","Trabalhar")
				TriggerEvent("Notify","amarelo","Trabalho finalizado.",5000)
				Active = false
			else
				Active = true
				exports["target"]:LabelText("Towdriver","Finalizar")
				TriggerEvent("Notify","verde","Trabalho iniciado.",5000)

				SpawnSelect = math.random(#VehiclesTowdriver)
				SpawnCoords = math.random(#SpawnVehiclesTowdriver)

				local coord = SpawnVehiclesTowdriver[SpawnCoords]
				TriggerEvent("NotifyPush",{
					code = 20,
					title = "Registro de Veículo",
					x = coord[1], y = coord[2], z = coord[3],
					name = "Aguardando reboque",
					blipColor = 3
				})
			end

			vSERVER.toggleService()
		end
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- THREAD
-----------------------------------------------------------------------------------------------------------------------------------------
CreateThread(function()
	while true do
		if Active and not SpawnVehicle then
			local Ped = PlayerPedId()
			local Coords = GetEntityCoords(Ped)
			local coord = SpawnVehiclesTowdriver[SpawnCoords]
			local Distance = #(Coords - vec3(coord[1],coord[2],coord[3]))

			if Distance <= 100 then
				SpawnVehicle = true
				local vehName = VehiclesTowdriver[SpawnSelect]
				local heading = coord[4]

				vGARAGE.ServerVehicle(vehName, coord[1], coord[2], coord[3], heading, nil, 0, nil, 100)
			end
		end
		Wait(5000)
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- TOWDRIVER:TOW
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("towdriver:Tow")
AddEventHandler("towdriver:Tow",function(entity)
	if entity[2] == VehiclesTowdriver[SpawnSelect] then
		SpawnVehicle = false
		SpawnSelect = math.random(#VehiclesTowdriver)
		vSERVER.PaymentMethod(entity[4],entity[1])
		SpawnCoords = math.random(#SpawnVehiclesTowdriver)

		local coord = SpawnVehiclesTowdriver[SpawnCoords]
		TriggerEvent("NotifyPush",{
			code = 20,
			title = "Registro de Veículo",
			x = coord[1], y = coord[2], z = coord[3],
			name = "Aguardando reboque.",
			blipColor = 2
		})
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- TOWDRIVER:INVOKETOW
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("towdriver:invokeTow")
AddEventHandler("towdriver:invokeTow",function()
	local Ped = PlayerPedId()
	local Vehicle = GetLastDrivenVehicle()
	local vehicleModel = GetEntityModel(Vehicle)
	local isTowVehicle = false

	for _,model in ipairs(VehiclesWorkTowdriver) do
		if vehicleModel == GetHashKey(model) then
			isTowVehicle = true
			break
		end
	end

	if isTowVehicle and not IsPedInAnyVehicle(Ped) then
		local vehTowed = vRP.ClosestVehicle(10)

		if IsEntityAVehicle(Vehicle) and IsEntityAVehicle(vehTowed) then
			local vehCoords01 = GetEntityCoords(Vehicle)
			local vehCoords02 = GetEntityCoords(vehTowed)
			local vehDistance = #(vehCoords01 - vehCoords02)

			if vehDistance <= 15 then
				if inTowed then
					TriggerServerEvent("towdriver:ServerTow",VehToNet(Vehicle),VehToNet(inTowed),"out")
					VehTower = nil
					inTowed = nil
				else
					if Vehicle ~= vehTowed then
						VehTower = vehTowed
						LocalPlayer["state"]["Cancel"] = true
						TriggerEvent("sounds:source","tow",0.5)
						LocalPlayer["state"]["Commands"] = true
						TaskTurnPedToFaceEntity(Ped,vehTowed,5000)
						vRP.playAnim(false,{"mini@repair","fixing_a_player"},true)

						Wait(4500)

						inTowed = vehTowed
						vRP.Destroy()
						LocalPlayer["state"]["Cancel"] = false
						LocalPlayer["state"]["Commands"] = false
						TriggerServerEvent("towdriver:ServerTow",VehToNet(Vehicle),VehToNet(vehTowed),"in")
					end
				end
			else
				TriggerEvent("Notify","amarelo","Reboque precisa estar próximo do veículo.",3000)
			end
		end
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- TOWDRIVER:CLIENTTOW
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("towdriver:ClientTow")
AddEventHandler("towdriver:ClientTow",function(veh01,veh02,mode)
	if NetworkDoesNetworkIdExist(veh01) and NetworkDoesNetworkIdExist(veh02) then
		local vehicle = NetToEnt(veh01)
		local vehTowed = NetToEnt(veh02)
		if DoesEntityExist(vehicle) and DoesEntityExist(vehTowed) then
			if mode == "in" then
				local min,max = GetModelDimensions(GetEntityModel(vehTowed))
				AttachEntityToEntity(vehTowed,vehicle,GetEntityBoneIndexByName(vehicle,"bodyshell"),0,-2.2,0.4 - min["z"],0,0,0,1,1,0,1,0,1)
			elseif mode == "out" then
				DetachEntity(vehTowed,false,false)

				local vehHeading = GetEntityHeading(vehicle)
				local vehCoords = GetOffsetFromEntityInWorldCoords(vehicle,0.0,-10.0,0.0)
				SetEntityCoords(vehTowed,vehCoords["x"],vehCoords["y"],vehCoords["z"],false,false,false,false)
				SetEntityHeading(vehTowed,vehHeading)
				SetVehicleOnGroundProperly(vehTowed)
			end
		end
	end
end)