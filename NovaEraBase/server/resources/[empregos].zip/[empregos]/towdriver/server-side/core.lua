-----------------------------------------------------------------------------------------------------------------------------------------
-- VRP
-----------------------------------------------------------------------------------------------------------------------------------------
local Tunnel = module("vrp","lib/Tunnel")
local Proxy = module("vrp","lib/Proxy")
vRPC = Tunnel.getInterface("vRP")
vRP = Proxy.getInterface("vRP")
-----------------------------------------------------------------------------------------------------------------------------------------
-- CONNECTION
-----------------------------------------------------------------------------------------------------------------------------------------
Creative = {}
Tunnel.bindInterface("towdriver",Creative)
-----------------------------------------------------------------------------------------------------------------------------------------
-- ITENSLIST
-----------------------------------------------------------------------------------------------------------------------------------------
local Active = {}
local userList = {}
-----------------------------------------------------------------------------------------------------------------------------------------
-- TOGGLESERVICE
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.toggleService()
	local source = source
	local Passport = vRP.Passport(source)
	if Passport then
		if userList[Passport] then
			userList[Passport] = nil
		else
			userList[Passport] = source
		end
	end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- TOWDRIVER:CALL
-----------------------------------------------------------------------------------------------------------------------------------------
AddEventHandler("towdriver:Call",function(source,vehName,Plate)
	local Ped = GetPlayerPed(source)
	if DoesEntityExist(Ped) then
		local Coords = GetEntityCoords(Ped)

		for k,v in pairs(userList) do
			async(function()
				TriggerClientEvent("NotifyPush",v,{ code = 51, title = "Registro de Veículo", x = Coords["x"], y = Coords["y"], z = Coords["z"], vehicle = VehicleName(vehName).." - "..Plate, time = "Recebido às "..os.date("%H:%M"), blipColor = 33 })
			end)
		end
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- PAYMENTMETHOD
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.PaymentMethod(Network,Plate)
	local source = source
	local Passport = vRP.Passport(source)
	if Passport and not Active[Passport] then
		Active[Passport] = true

		TriggerEvent("garages:deleteVehicle",Network,Plate)

        local Experience = vRP.GetExperience(Passport, ExperienceWorkTowdriver)
        local Category = ClassCategory(Experience)
        local Valuation = PaymentDefaultTowdriver + (CategoryIncrementsTowdriver[Category] or 0)

		vRP.PutExperience(Passport, ExperienceWorkTowdriver, LevelExperienceWorkTowdriver)

		local RandomItem = math.random(1, #ItensWorkTowdriver)
        local Data = ItensWorkTowdriver[RandomItem]
        local Amount = math.random(Data.Amount[1], Data.Amount[2])

        local weight = vRP.GetItemWeight(Data.item) or 0
        if (vRP.InventoryWeight(Passport) + weight * Amount) <= vRP.GetWeight(Passport) then
            vRP.GenerateItem(Passport, Data.item, Amount, true)
        else
            exports["inventory"]:Drops(Passport, source, Data.item, Amount)
            TriggerClientEvent("Notify", source, "amarelo", "Mochila cheia, sua recompensa foi dropada no chão.", 5000)
        end

        vRP.GenerateItem(Passport, ItemPaymentTowdriver, Valuation, true)

		Active[Passport] = nil
	end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- TOWDRIVER:SERVERTOW
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("towdriver:ServerTow")
AddEventHandler("towdriver:ServerTow",function(veh01,veh02,mode)
	local source = source
	local Players = vRPC.Players(source)
	for _,v in pairs(Players) do
		async(function()
			TriggerClientEvent("towdriver:ClientTow",v,veh01,veh02,mode)
		end)
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- PRESET:TOWDRIVER
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("preset:towdriver")
AddEventHandler("preset:towdriver", function(Number)
    local source = source
    local Passport = vRP.Passport(source)
    if Passport then
        local Model = vRP.ModelPlayer(source)

        if Model == "mp_m_freemode_01" or Model == "mp_f_freemode_01" then
            TriggerClientEvent("skinshop:Apply", source, PresetTowdriver[Model])
			TriggerClientEvent('Notify', source, 'verde', 'Você vestiu o Traje de Rebocador', 5000)
        end
    end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- CHECKWORK
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.CheckWork(Work)
	local source = source
	local Passport = vRP.Passport(source)
	if Passport then
		if vRP.GetWork(Passport) == Work then
			return true
		else
			TriggerClientEvent("Notify", source, "amarelo", "Você precisa ter a sua <b>Carteira de Trabalho</b> assinada no emprego de <b>"..ClassWork(Work).."</b> para conseguir trabalhar aqui.",  5000)
		end

		return false
	end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- DISCONNECT
-----------------------------------------------------------------------------------------------------------------------------------------
AddEventHandler("Disconnect",function(Passport)
	if userList[Passport] then
		userList[Passport] = nil
	end

	if Active[Passport] then
		Active[Passport] = nil
	end
end)