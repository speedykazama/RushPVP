fx_version "bodacious"
game "gta5"
lua54 "yes"

client_scripts {
    "@vrp/config/Global.lua",
	"@vrp/config/Native.lua",
	"@vrp/lib/Utils.lua",
	"client-side/*"
}

server_scripts {
    "@vrp/config/Global.lua",
	"@vrp/config/Item.lua",
	"@vrp/config/Vehicle.lua",
	"@vrp/lib/Utils.lua",
	"server-side/*"
}

shared_scripts {
	"shared-side/*"
}