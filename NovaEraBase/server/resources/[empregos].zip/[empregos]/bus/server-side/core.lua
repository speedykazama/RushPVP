-----------------------------------------------------------------------------------------------------------------------------------------
-- VRP
-----------------------------------------------------------------------------------------------------------------------------------------
local Tunnel = module("vrp","lib/Tunnel")
local Proxy = module("vrp","lib/Proxy")
vRP = Proxy.getInterface("vRP")
-----------------------------------------------------------------------------------------------------------------------------------------
-- CONNECTION
-----------------------------------------------------------------------------------------------------------------------------------------
Creative = {}
Tunnel.bindInterface("bus",Creative)
-----------------------------------------------------------------------------------------------------------------------------------------
-- PAYMENT
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.Payment(Service)
    local source = source
    local Passport = vRP.Passport(source)
    if Passport then
        local Experience = vRP.GetExperience(Passport, ExperienceWorkBus)
        local Category = ClassCategory(Experience)
        local Valuation = PaymentDefaultBus + (CategoryIncrementsBus[Category] or 0)

        vRP.PutExperience(Passport, ExperienceWorkBus, LevelExperienceWorkBus)
        vRP.GenerateItem(Passport, ItemPaymentBus, Valuation, true)
    end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- PRESET:BUS
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("preset:bus")
AddEventHandler("preset:bus", function(Number)
    local source = source
    local Passport = vRP.Passport(source)
    if Passport then
        local Model = vRP.ModelPlayer(source)

        if Model == "mp_m_freemode_01" or Model == "mp_f_freemode_01" then
            TriggerClientEvent("skinshop:Apply", source, PresetBus[Model])
			TriggerClientEvent('Notify', source, 'verde', 'Você vestiu o Traje de Motorita de Ônibus', 5000)
        end
    end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- CHECKWORK
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.CheckWork(Work)
	local source = source
	local Passport = vRP.Passport(source)
	if Passport then
		if vRP.GetWork(Passport) == Work then
			return true
		else
			TriggerClientEvent("Notify", source, "amarelo", "Você precisa ter a sua <b>Carteira de Trabalho</b> assinada no emprego de <b>"..ClassWork(Work).."</b> para conseguir trabalhar aqui.",  5000)
		end

		return false
	end
end