-----------------------------------------------------------------------------------------------------------------------------------------
-- VRP
-----------------------------------------------------------------------------------------------------------------------------------------
local Tunnel = module("vrp","lib/Tunnel")
local Proxy = module("vrp","lib/Proxy")
vRP = Proxy.getInterface("vRP")
-----------------------------------------------------------------------------------------------------------------------------------------
-- CONNECTION
-----------------------------------------------------------------------------------------------------------------------------------------
vSERVER = Tunnel.getInterface("bus")
-----------------------------------------------------------------------------------------------------------------------------------------
-- VARIABLES
-----------------------------------------------------------------------------------------------------------------------------------------
local Blip = nil
local Selected = 1
local Active = false
-----------------------------------------------------------------------------------------------------------------------------------------
-- TARGET
-----------------------------------------------------------------------------------------------------------------------------------------
CreateThread(function()
	exports["target"]:AddCircleZone("Bus", InitWorkBus, 1.5, {
		name = "Bus",
		heading = 3374176
	}, {
		Distance = 2.0,
		options = {
			{
				event = "bus:Init",
				label = "Trabalhar",
				tunnel = "client"
			},{
				event = "preset:bus",
				label = "Traje Motorista",
				tunnel = "server"
			}
		}
	})
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- BUS:INIT
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("bus:Init")
AddEventHandler("bus:Init",function()
	if vSERVER.CheckWork(CheckWorkBus) then
		if Active then
			if DoesBlipExist(Blip) then
				RemoveBlip(Blip)
				Blip = nil
			end

			exports["target"]:LabelText("Bus","Trabalhar")
			TriggerEvent("Notify","amarelo","Trabalho finalizado.",5000)
			Active = false
		else
			Active = true
			exports["target"]:LabelText("Bus","Finalizar")
			TriggerEvent("Notify","verde","Trabalho iniciado.",5000)
			MakeBlips()
		end
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- THREADACTIVE
-----------------------------------------------------------------------------------------------------------------------------------------
CreateThread(function()
	while true do
		local TimeDistance = 999
		if Active then
			local Ped = PlayerPedId()
			if IsPedInAnyVehicle(Ped) then
				local Vehicle = GetVehiclePedIsUsing(Ped)
				if GetEntityArchetypeName(Vehicle) == VehicleWorkBus then
					local Coords = GetEntityCoords(Ped)
					local Distance = #(Coords - LocationsBus[Selected])

					if Distance <= 200 then
						TimeDistance = 1

						DrawMarker(22,LocationsBus[Selected]["x"],LocationsBus[Selected]["y"],LocationsBus[Selected]["z"] + 3.0,0.0,0.0,0.0,0.0,180.0,0.0,7.5,7.5,5.0,52,152,235,100,0,0,0,1)
						DrawMarker(1,LocationsBus[Selected]["x"],LocationsBus[Selected]["y"],LocationsBus[Selected]["z"] - 3.0,0.0,0.0,0.0,0.0,0.0,0.0,15.0,15.0,10.0,255,255,255,50,0,0,0,0)

						if Distance <= 10 then
							vSERVER.Payment(Selected)

							if Selected >= #LocationsBus then
								Selected = 1
							else
								Selected = Selected + 1
							end

							MakeBlips()
						end
					end
				end
			end
		end

		Wait(TimeDistance)
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- MAKEBLIPS
-----------------------------------------------------------------------------------------------------------------------------------------
function MakeBlips()
	if DoesBlipExist(Blip) then
		RemoveBlip(Blip)
		Blip = nil
	end

	Blip = AddBlipForCoord(LocationsBus[Selected]["x"],LocationsBus[Selected]["y"],LocationsBus[Selected]["z"])
	SetBlipSprite(Blip,1)
	SetBlipDisplay(Blip,4)
	SetBlipHighDetail(Blip,true)
	SetBlipAsShortRange(Blip,true)
	SetBlipColour(Blip,3)
	SetBlipScale(Blip,0.75)
	SetBlipRoute(Blip,true)
	BeginTextCommandSetBlipName("STRING")
	AddTextComponentString("Motorista")
	EndTextCommandSetBlipName(Blip)
end