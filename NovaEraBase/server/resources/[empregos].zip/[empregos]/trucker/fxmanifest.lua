fx_version "bodacious"
game "gta5"

shared_scripts {
	"shared-side/*"
}

client_scripts {
    "@vrp/config/Global.lua",
	"@vrp/config/Native.lua",
	"@vrp/lib/Utils.lua",
	"client-side/*"
}

server_scripts {
    "@vrp/config/Global.lua",
	"@vrp/lib/Utils.lua",
	"server-side/*"
}