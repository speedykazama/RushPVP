-----------------------------------------------------------------------------------------------------------------------------------------
-- VRP
-----------------------------------------------------------------------------------------------------------------------------------------
local Tunnel = module("vrp","lib/Tunnel")
local Proxy = module("vrp","lib/Proxy")
vRP = Proxy.getInterface("vRP")
-----------------------------------------------------------------------------------------------------------------------------------------
-- CONNECTION
-----------------------------------------------------------------------------------------------------------------------------------------
Creative = {}
Tunnel.bindInterface("trucker",Creative)
vSERVER = Tunnel.getInterface("trucker")
vGARAGE = Tunnel.getInterface("garages")
-----------------------------------------------------------------------------------------------------------------------------------------
-- VARIABLES
-----------------------------------------------------------------------------------------------------------------------------------------
local Blip = nil
local Position = 1
local Package = false
local Service = "vehicles"
local Active = false
-----------------------------------------------------------------------------------------------------------------------------------------
-- TARGET
-----------------------------------------------------------------------------------------------------------------------------------------
CreateThread(function()
	exports["target"]:AddCircleZone("Trucker", InitWorkTrucker, 0.5, {
		name = "Trucker",
		heading = 3374176
	}, {
		Distance = 1.25,
		options = {
			{
				event = "trucker:Init",
				label = "Trabalhar",
				tunnel = "client"
			}, {
				event = "trucker:InitVehicles",
				label = "Entrega de Veículos",
				tunnel = "client"
			}, {
				event = "trucker:InitiDiesel",
				label = "Entrega de Diesel",
				tunnel = "client"
			}, {
				event = "trucker:InitFuel",
				label = "Entrega de Gasolina",
				tunnel = "client"
			}, {
				event = "trucker:InitWood",
				label = "Entrega de Madeira",
				tunnel = "client"
			}, {
				event = "preset:trucker",
				label = "Traje Caminhoneiro",
				tunnel = "server"
			}, {
				event = "shops:Trucker",
				label = "Vender Materiais",
				tunnel = "client"
			}
		}
	})
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- TRUCKER:INIT
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("trucker:Init")
AddEventHandler("trucker:Init", function()
    if vSERVER.CheckWork(CheckWorkTrucker) then
        if Active then
            Active = false
            Package = false
            Position = 1

            if DoesBlipExist(Blip) then
                RemoveBlip(Blip)
                Blip = nil
            end

            exports["target"]:LabelText("Trucker", "Trabalhar")
            TriggerEvent("Notify", "amarelo", "Serviço finalizado.", 5000)
        else
            Active = true
            exports["target"]:LabelText("Trucker", "Finalizar")
            TriggerEvent("Notify", "verde", "Serviço iniciado, escolha o tipo de entrega.", 5000)
        end
    end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- TRUCKER:INITVEHICLES
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("trucker:InitVehicles")
AddEventHandler("trucker:InitVehicles", function()
		if Active then
			if not Package then
				Position = 1
				Package = true
				Service = "vehicles"
				TriggerEvent("Notify","amarelo","Dirija-se até seu caminhão, buzine o mesmo<br>para receber a carga responsável pelo transporte.",5000)
				MakeBlipMarked()
			else
				TriggerEvent("Notify","amarelo","Você já está em uma entrega.",5000)
			end
		else
			TriggerEvent("Notify","amarelo","Você precisa entrar em serviço primeiro.",5000)
		end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- TRUCKER:INITDIESEL
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("trucker:InitiDiesel")
AddEventHandler("trucker:InitiDiesel", function()
		if Active then
			if not Package then
				Position = 1
				Package = true
				Service = "diesel"
				TriggerEvent("Notify","amarelo","Dirija-se até seu caminhão, buzine o mesmo<br>para receber a carga responsável pelo transporte.",5000)
				MakeBlipMarked()
			else
				TriggerEvent("Notify","amarelo","Você já está em uma entrega.",5000)
			end
		else
			TriggerEvent("Notify","amarelo","Você precisa entrar em serviço primeiro.",5000)
		end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- TRUCKER:INITFUEL
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("trucker:InitFuel")
AddEventHandler("trucker:InitFuel", function()
		if Active then
			if not Package then
				Position = 1
				Package = true
				Service = "fuel"
				TriggerEvent("Notify","amarelo","Dirija-se até seu caminhão, buzine o mesmo<br>para receber a carga responsável pelo transporte.",5000)
				MakeBlipMarked()
			else
				TriggerEvent("Notify","amarelo","Você já está em uma entrega.",5000)
			end
		else
			TriggerEvent("Notify","amarelo","Você precisa entrar em serviço primeiro.",5000)
		end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- TRUCKER:INITWOOD
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("trucker:InitWood")
AddEventHandler("trucker:InitWood", function()
		if Active then
			if not Package then
				Position = 1
				Package = true
				Service = "wood"
				TriggerEvent("Notify","amarelo","Dirija-se até seu caminhão, buzine o mesmo<br>para receber a carga responsável pelo transporte.",5000)
				MakeBlipMarked()
			else
				TriggerEvent("Notify","amarelo","Você já está em uma entrega.",5000)
			end
		else
			TriggerEvent("Notify","amarelo","Você precisa entrar em serviço primeiro.",5000)
		end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- THREAD
-----------------------------------------------------------------------------------------------------------------------------------------
CreateThread(function()
	while true do
		local TimeDistance = 999
		if Package then
			local Vehicle = GetPlayersLastVehicle()
			if IsEntityAVehicle(Vehicle) then
				local vehModel = GetEntityModel(Vehicle)
				if Truckers[vehModel] then
					local Ped = PlayerPedId()
					local Coords = GetEntityCoords(Ped)
					local Distance = #(Coords - vec3(PackServiceTruckers[Service]["Coords"][Position][1],PackServiceTruckers[Service]["Coords"][Position][2],PackServiceTruckers[Service]["Coords"][Position][3]))

					if Distance <= 200 then
						TimeDistance = 1
						DrawMarker(1,PackServiceTruckers[Service]["Coords"][Position][1],PackServiceTruckers[Service]["Coords"][Position][2],PackServiceTruckers[Service]["Coords"][Position][3] - 3,0,0,0,0,0,0,12.0,12.0,8.0,255,255,255,25,0,0,0,0)
						DrawMarker(21,PackServiceTruckers[Service]["Coords"][Position][1],PackServiceTruckers[Service]["Coords"][Position][2],PackServiceTruckers[Service]["Coords"][Position][3] + 1,0,0,0,0,180.0,130.0,3.0,3.0,2.0,52,152,235,100,0,0,0,1)

						if Distance <= 10 then
							if Position >= #PackServiceTruckers[Service]["Coords"] then
								Package = false
								vSERVER.Payment(Service)

								if DoesBlipExist(Blip) then
									RemoveBlip(Blip)
									Blip = nil
								end
							else
								if Position == 1 then
									if IsControlJustPressed(1,38) then
										local Heading = GetEntityHeading(Vehicle)
										local vehCoords = GetOffsetFromEntityInWorldCoords(Vehicle,0.0,-12.0,0.0)
										local Trailer = vGARAGE.ServerVehicle(PackServiceTruckers[Service]["trailer"],vehCoords["x"],vehCoords["y"],vehCoords["z"],Heading,nil,0,nil,1000)

										if NetworkDoesNetworkIdExist(Trailer) then
											local vehicleNet = NetToEnt(Trailer)
											if NetworkDoesNetworkIdExist(vehicleNet) then
												SetVehicleOnGroundProperly(vehicleNet)
											end
										end

										Position = Position + 1
										MakeBlipMarked()
									end
								else
									if PackServiceTruckers[Service]["Coords"][Position][4] ~= nil then
										if not IsPedInAnyVehicle(Ped) and IsControlJustPressed(1,38) then
											TriggerEvent("Progress", "Descarregando carga", 2500)
											vRP.playAnim(false, {"amb@prop_human_parking_meter@female@idle_a", "idle_a_female"}, true)
											Wait(2500)
											vRP.stopAnim()

											local Vehicle,Network,Plate,vehModel = vRP.VehicleList(10)
											if Vehicle then
												if vehModel == PackServiceTruckers[Service]["trailer"] then
													TriggerEvent("Notify","amarelo","Volte para receber o pagamento.",5000)
													TriggerServerEvent("garages:deleteVehicle",Network,Plate)
													Position = Position + 1
													MakeBlipMarked()
												end
											end
										end
									else
										Position = Position + 1
										MakeBlipMarked()
									end
								end
							end
						end
					end
				end
			end
		end

		Wait(TimeDistance)
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- MAKEBLIPMARKED
-----------------------------------------------------------------------------------------------------------------------------------------
function MakeBlipMarked()
	if DoesBlipExist(Blip) then
		RemoveBlip(Blip)
		Blip = nil
	end

	Blip = AddBlipForCoord(PackServiceTruckers[Service]["Coords"][Position][1],PackServiceTruckers[Service]["Coords"][Position][2],PackServiceTruckers[Service]["Coords"][Position][3])
	SetBlipSprite(Blip,12)
	SetBlipColour(Blip,3)
	SetBlipScale(Blip,0.9)
	SetBlipRoute(Blip,true)
	SetBlipAsShortRange(Blip,true)
	BeginTextCommandSetBlipName("STRING")
	AddTextComponentString("Caminhoneiro")
	EndTextCommandSetBlipName(Blip)
end