-----------------------------------------------------------------------------------------------------------------------------------------
-- VRP
-----------------------------------------------------------------------------------------------------------------------------------------
local Tunnel = module("vrp","lib/Tunnel")
local Proxy = module("vrp","lib/Proxy")
vRP = Proxy.getInterface("vRP")
-----------------------------------------------------------------------------------------------------------------------------------------
-- CONNECTION
-----------------------------------------------------------------------------------------------------------------------------------------
Creative = {}
Tunnel.bindInterface("trucker",Creative)
-----------------------------------------------------------------------------------------------------------------------------------------
-- CHECKEXIST
-----------------------------------------------------------------------------------------------------------------------------------------
local Delay = {}
local Active = {}
-----------------------------------------------------------------------------------------------------------------------------------------
-- PAYMENT
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.Payment(Service)
	local source = source
	local Passport = vRP.Passport(source)
	if Passport and not Active[Passport] then
		Active[Passport] = true
        local Experience = vRP.GetExperience(Passport, ExperienceWorkTrucker)
        local Category = ClassCategory(Experience)
        local Valuation = PaymentDefaultTrucker + (CategoryIncrementsTrucker[Category] or 0)

		if Delay[Passport] == nil then
			Delay[Passport] = 0
		end

		vRP.PutExperience(Passport, ExperienceWorkTrucker, LevelExperienceWorkTrucker)

		if (vRP.InventoryWeight(Passport) + 3) <= vRP.GetWeight(Passport) then
			for k,v in pairs(Delivery[Service]) do
				local Rand = math.random(v["min"], v["max"])
				vRP.GenerateItem(Passport, v["item"], Rand, true)
			end
		else
			for k,v in pairs(Delivery[Service]) do
				local Rand = math.random(v["min"], v["max"])
				exports["inventory"]:Drops(Passport, source, v["item"], Rand)
			end

			TriggerClientEvent("Notify", source, "vermelho", "Mochila cheia. Os itens foram dropados no chão.", 5000)
		end

		vRP.GenerateItem(Passport, ItemPaymentTrucker, Valuation, true)

		Delay[Passport] = Delay[Passport] + 1
		Active[Passport] = nil
	end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- PRESET:TRUCKER
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("preset:trucker")
AddEventHandler("preset:trucker", function(Number)
    local source = source
    local Passport = vRP.Passport(source)
    if Passport then
        local Model = vRP.ModelPlayer(source)

        if Model == "mp_m_freemode_01" or Model == "mp_f_freemode_01" then
            TriggerClientEvent("skinshop:Apply", source, PresetTrucker[Model])
			TriggerClientEvent('Notify', source, 'verde', 'Você vestiu o Traje de Caminhoneiro', 5000)
        end
    end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- CHECKWORK
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.CheckWork(Work)
	local source = source
	local Passport = vRP.Passport(source)
	if Passport then
		if vRP.GetWork(Passport) == Work then
			return true
		else
			TriggerClientEvent("Notify", source, "amarelo", "Você precisa ter a sua <b>Carteira de Trabalho</b> assinada no emprego de <b>"..ClassWork(Work).."</b> para conseguir trabalhar aqui.",  5000)
		end

		return false
	end
end