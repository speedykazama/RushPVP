-----------------------------------------------------------------------------------------------------------------------------------------
-- VRP
-----------------------------------------------------------------------------------------------------------------------------------------
local Tunnel = module("vrp", "lib/Tunnel")
local Proxy = module("vrp", "lib/Proxy")
vRP = Proxy.getInterface("vRP")
-----------------------------------------------------------------------------------------------------------------------------------------
-- CONNECTION
-----------------------------------------------------------------------------------------------------------------------------------------
vSERVER = Tunnel.getInterface("tractor")
-----------------------------------------------------------------------------------------------------------------------------------------
-- VARIABLES
-----------------------------------------------------------------------------------------------------------------------------------------
local NextSwitchTime = 0
local state = 1
local Blip = nil
local Position = 1
local Locate = 1
local Active = false
-----------------------------------------------------------------------------------------------------------------------------------------
-- TARGET
-----------------------------------------------------------------------------------------------------------------------------------------
CreateThread(function()
	exports["target"]:AddCircleZone("Tractor", InitWorkTractor, 1.5, {
		name = "Tractor",
		heading = 3374176
	}, {
		Distance = 2.0,
		options = {
			{
				event = "tractor:Init",
				label = "Trabalhar",
				tunnel = "shop"
			},{
            	event = "preset:tractor",
				label = "Traje Tratorista",
				tunnel = "server"
			}
		}
	})
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- TRACTOR:INIT
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("tractor:Init")
AddEventHandler("tractor:Init", function(Service)
    if vSERVER.CheckWork(CheckWorkTractor) then
        if Active then
            if DoesBlipExist(Blip) then
                RemoveBlip(Blip)
                Blip = nil
            end
            
			exports["target"]:LabelText("Tractor","Trabalhar")
			TriggerEvent("Notify","amarelo","Trabalho finalizado.",5000)
			Active = false
        else
            Position = 1
            Active = true
			exports["target"]:LabelText("Tractor","Finalizar")
			TriggerEvent("Notify","verde","Trabalho iniciado.",5000)
            TriggerEvent("Notify", "amarelo", "1° Siga os pontos no gps.<br>2° dirija-se à garagem e selecione um arado ou uma carroça para acoplar ao trator.", 10000)
            RouteStart()
        end
    end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- ROUTESTART
-----------------------------------------------------------------------------------------------------------------------------------------
function RouteStart()
    CreateThread(function()
        while Active do
            local TimeDistance = 999
            local Ped = PlayerPedId()
            if IsPedInAnyVehicle(Ped) and GetEntityHealth(Ped) > 100 then
                if GetEntityModel(GetVehiclePedIsUsing(Ped)) == GetHashKey(VehicleWorkTractor) then
                    local hasTrailer, trailer = GetVehicleTrailerVehicle(GetVehiclePedIsUsing(Ped))
                    if hasTrailer and GetEntityModel(trailer) == GetHashKey(VehicleWorkTractor2) then
                        if not DoesBlipExist(Blip) then
                            MakeBlipMarked(LocationsTractor[Position].x, LocationsTractor[Position].y, LocationsTractor[Position].z)
                        end
                        
                        local pedCoords = GetEntityCoords(Ped)
                        local loc = LocationsTractor[Position]
                        local distance = #(pedCoords - vec3(loc.x, loc.y, loc.z))
                        
                        if distance <= 100 then
                            TimeDistance = 1
                            if Position >= #LocationsTractor then
                                DrawMarker(4, loc.x, loc.y, loc.z + 3.0, 0.0, 0.0, 0.0, 0.0, 180.0, 0.0, 4.5, 4.5, 2.0, 65, 130, 226, 100, 0, 0, 0, 1)
                                DrawMarker(1, loc.x, loc.y, loc.z - 0.6, 0, 0, 0, 0.0, 0, 0, 5.0, 5.0, 2.0, 250, 250, 250, 50, 0, 0, 0, 1)
                            else
                                drawMarker(loc.x, loc.y, loc.z, loc.w - 180.0 or 0.0)
                            end
                        end
                        
                        if distance <= 5 then
                            if Position >= #LocationsTractor then
                                Position = 1
                                vSERVER.Payment()
                            else
                                Position = Position + 1
                            end
                            PlaySound(-1, "RACE_PLACED", "HUD_AWARDS", 0, 0, 1)
                            local nextLoc = LocationsTractor[Position]
                            MakeBlipMarked(nextLoc.x, nextLoc.y, nextLoc.z)
                        end
                    end
                end
            end
            Citizen.Wait(TimeDistance)
        end
    end)
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- MAKEBLIPMARKED
-----------------------------------------------------------------------------------------------------------------------------------------
function MakeBlipMarked(x, y, z)
    if DoesBlipExist(Blip) then
        RemoveBlip(Blip)
        Blip = nil
    end
    Blip = AddBlipForCoord(x, y, z)
    SetBlipSprite(Blip, 1)
    SetBlipColour(Blip, 3)
    SetBlipScale(Blip, 0.7)
    SetBlipAsShortRange(Blip, false)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("CheckPoint")
    EndTextCommandSetBlipName(Blip)
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- DRAWMAKER
-----------------------------------------------------------------------------------------------------------------------------------------
function drawMarker(x,y,z,h)
	local currentTime = GetGameTimer()
	if currentTime >= NextSwitchTime then
		state = state % 4 + 1 
		NextSwitchTime = currentTime + 500 
	end
	local offset = 1.0
	local angle_rad = math.rad(h)
    local offsetX = math.sin(angle_rad) * offset
    local offsetY = math.cos(angle_rad) * offset
    local frontX = x - offsetX
    local frontY = y + offsetY
    local backX = x + offsetX
    local backY = y - offsetY
	if state == 1 then
		DrawMarker(20, frontX, frontY, z + 3.0, 0.0, 0.0, 0.0,90.0, h, 90.0, 4.5, 4.5, 2.0, 250, 250, 250, 50, 0, 0, 0, 0) 
		DrawMarker(20, x, y, z + 3.0, 0.0, 0.0, 0.0,90.0, h, 90.0, 4.5, 4.5, 2.0, 250, 250, 250, 50, 0, 0, 0, 0) 
		DrawMarker(20, backX, backY, z + 3.0, 0.0, 0.0, 0.0,90.0, h, 90.0, 4.5, 4.5, 2.0, 250, 250, 250, 50, 0, 0, 0, 0) 
	elseif state == 2 then 
		DrawMarker(20, frontX, frontY, z + 3.0, 0.0, 0.0, 0.0,90.0, h, 90.0, 4.5, 4.5, 2.0, 52, 152, 235, 100, 0, 0, 0, 0) 
		DrawMarker(20, x, y, z + 3.0, 0.0, 0.0, 0.0,90.0, h, 90.0, 4.5, 4.5, 2.0, 250, 250, 250, 50, 0, 0, 0, 0) 
		DrawMarker(20, backX, backY, z + 3.0, 0.0, 0.0, 0.0,90.0, h, 90.0, 4.5, 4.5, 2.0, 250, 250, 250, 50, 0, 0, 0, 0) 
	elseif state == 3 then 
		DrawMarker(20, frontX, frontY, z + 3.0, 0.0, 0.0, 0.0,90.0, h, 90.0, 4.5, 4.5, 2.0, 52, 152, 235, 100, 0, 0, 0, 0) 
		DrawMarker(20, x, y, z + 3.0, 0.0, 0.0, 0.0,90.0, h, 90.0, 4.5, 4.5, 2.0, 52, 152, 235, 100, 0, 0, 0, 0) 
		DrawMarker(20, backX, backY, z + 3.0, 0.0, 0.0, 0.0,90.0, h, 90.0, 4.5, 4.5, 2.0, 250, 250, 250, 50, 0, 0, 0, 0) 
	elseif state == 4 then
		DrawMarker(20, frontX, frontY, z + 3.0, 0.0, 0.0, 0.0,90.0, h, 90.0, 4.5, 4.5, 2.0, 52, 152, 235, 100, 0, 0, 0, 0) 
		DrawMarker(20, x, y, z + 3.0, 0.0, 0.0, 0.0, 90.0, h, 90.0, 4.5, 4.5, 2.0, 52, 152, 235, 100, 0, 0, 0, 0) 
		DrawMarker(20, backX, backY, z + 3.0, 0.0, 0.0, 0.0, 90.0, h, 90.0, 4.5, 4.5, 2.0, 52, 152, 235, 100, 0, 0, 0, 0) 
	end
	DrawMarker(1,x,y,z-1.0,0,0,0,0.0,0,0,5.0,5.0,2.0,250,250,250,50,0,0,0,1)
end