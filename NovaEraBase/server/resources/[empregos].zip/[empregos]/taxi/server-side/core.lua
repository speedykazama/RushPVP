-----------------------------------------------------------------------------------------------------------------------------------------
-- VRP
-----------------------------------------------------------------------------------------------------------------------------------------
local Tunnel = module("vrp","lib/Tunnel")
local Proxy = module("vrp","lib/Proxy")
vRP = Proxy.getInterface("vRP")
-----------------------------------------------------------------------------------------------------------------------------------------
-- CONNECTION
-----------------------------------------------------------------------------------------------------------------------------------------
Creative = {}
Tunnel.bindInterface("taxi",Creative)
-----------------------------------------------------------------------------------------------------------------------------------------
-- PAYMENTSERVICE
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.PaymentService()
	local source = source
	local Passport = vRP.Passport(source)
	if Passport then
        local Experience = vRP.GetExperience(Passport, ExperienceWorkTaxi)
        local Category = ClassCategory(Experience)
        local Valuation = PaymentDefaultTaxi + (CategoryIncrementsTaxi[Category] or 0)

        vRP.PutExperience(Passport, ExperienceWorkTaxi, LevelExperienceWorkTaxi)
        vRP.GenerateItem(Passport, ItemPaymentTaxi, Valuation, true)
	end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- PRESET:TAXI
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("preset:taxi")
AddEventHandler("preset:taxi", function(Number)
    local source = source
    local Passport = vRP.Passport(source)
    if Passport then
        local Model = vRP.ModelPlayer(source)

        if Model == "mp_m_freemode_01" or Model == "mp_f_freemode_01" then
            TriggerClientEvent("skinshop:Apply", source, PresetTaxi[Model])
			TriggerClientEvent('Notify', source, 'verde', 'Você vestiu o Traje de Taxista', 5000)
        end
    end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- CHECKWORK
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.CheckWork(Work)
	local source = source
	local Passport = vRP.Passport(source)
	if Passport then
		if vRP.GetWork(Passport) == Work then
			return true
		else
			TriggerClientEvent("Notify", source, "amarelo", "Você precisa ter a sua <b>Carteira de Trabalho</b> assinada no emprego de <b>"..ClassWork(Work).."</b> para conseguir trabalhar aqui.",  5000)
		end

		return false
	end
end