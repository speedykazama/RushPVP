-----------------------------------------------------------------------------------------------------------------------------------------
-- VRP
-----------------------------------------------------------------------------------------------------------------------------------------
local Tunnel = module("vrp","lib/Tunnel")
local Proxy = module("vrp","lib/Proxy")
vRP = Proxy.getInterface("vRP")
-----------------------------------------------------------------------------------------------------------------------------------------
-- CONNECTION
-----------------------------------------------------------------------------------------------------------------------------------------
Creative = {}
Tunnel.bindInterface("taxi", Creative)
vSERVER = Tunnel.getInterface("taxi")
-----------------------------------------------------------------------------------------------------------------------------------------
-- VARIÁVEIS
-----------------------------------------------------------------------------------------------------------------------------------------
local LastPosition = 1
local ServiceBlip = nil
local SelectPosition = 1
local LastPassenger = nil
local CurrentStatus = false
local ServiceStatus = false
local CurrentPassenger = nil
-----------------------------------------------------------------------------------------------------------------------------------------
-- TARGET
-----------------------------------------------------------------------------------------------------------------------------------------
CreateThread(function()
    exports["target"]:AddCircleZone("Taxi", InitWorkTaxi, 1.5, {
        name = "Taxi",
        heading = 3374176
    }, {
        Distance = 2.0,
        options = {
            {
                event = "taxi:Init",
                label = "Trabalhar",
                tunnel = "client"
            },
            {
                event = "preset:taxi",
                label = "Traje Taxista",
                tunnel = "server"
            }
        }
    })
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- TAXI:INIT
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("taxi:Init")
AddEventHandler("taxi:Init", function()
    if vSERVER.CheckWork(CheckWorkTaxi) then
        if ServiceStatus then
            ServiceStatus = false

            if DoesBlipExist(ServiceBlip) then
                RemoveBlip(ServiceBlip)
                ServiceBlip = nil
            end

            if CurrentPassenger ~= nil then
                TriggerServerEvent("tryDeleteObject", PedToNet(CurrentPassenger))
                CurrentPassenger = nil
            end

            if LastPassenger ~= nil then
                TriggerServerEvent("tryDeleteObject", LastPassenger)
                LastPassenger = nil
            end

            exports["target"]:LabelText("Taxi", "Trabalhar")
            TriggerEvent("Notify", "amarelo", "Trabalho finalizado.", 5000)
        else
            repeat
                if LastPosition == SelectPosition then
                    SelectPosition = math.random(#StopVehicleTaxi)
                end
            until LastPosition ~= SelectPosition

            CurrentPassenger = nil
            CurrentStatus = false
            ServiceStatus = true
            LastPassenger = nil
            BlipPassenger()

            exports["target"]:LabelText("Taxi", "Finalizar")
            TriggerEvent("Notify", "verde", "Trabalho iniciado.", 5000)
        end
    end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- THREAD
-----------------------------------------------------------------------------------------------------------------------------------------
CreateThread(function()
    while true do
        local timeDistance = 999
        local ped = PlayerPedId()
        local coords = GetEntityCoords(ped)

        if IsPedInAnyVehicle(ped) and ServiceStatus then
            local vehicle = GetVehiclePedIsUsing(ped)
            local stopCoords = vector3(StopVehicleTaxi[SelectPosition][1], StopVehicleTaxi[SelectPosition][2], StopVehicleTaxi[SelectPosition][3])
            local distance = #(coords - stopCoords)

            if distance <= 100 then
                timeDistance = 1

                DrawMarker(1, stopCoords.x, stopCoords.y, stopCoords.z - 3, 0, 0, 0, 0, 0, 0, 5.0, 5.0, 3.0, 52, 152, 235, 25, 0, 0, 0, 0)
                DrawMarker(21, stopCoords.x, stopCoords.y, stopCoords.z, 0, 0, 0, 0, 180.0, 130.0, 1.5, 1.5, 1.0, 42, 137, 255, 100, 0, 0, 0, 1)

                if IsControlJustPressed(1, 38) and distance <= 2.5 and GetEntityModel(vehicle) == GetHashKey(VehicleWorkTaxi) then
                    if CurrentStatus then
                        FreezeEntityPosition(vehicle, true)

                        if DoesEntityExist(CurrentPassenger) then
                            vSERVER.PaymentService()
                            Wait(1000)
                            TaskLeaveVehicle(CurrentPassenger, vehicle, 262144)
                            TaskWanderStandard(CurrentPassenger, 10.0, 10)
                            Wait(1000)
                            SetVehicleDoorShut(vehicle, 3, 0)
                            Wait(1000)
                        end

                        FreezeEntityPosition(vehicle, false)

                        LastPassenger = PedToNet(CurrentPassenger)
                        LastPosition = SelectPosition
                        CurrentStatus = false

                        repeat
                            if LastPosition == SelectPosition then
                                SelectPosition = math.random(#StopVehicleTaxi)
                            end
                        until LastPosition ~= SelectPosition

                        BlipPassenger()

                        SetTimeout(10000, function()
                            if LastPassenger ~= nil then
                                TriggerServerEvent("tryDeleteObject", LastPassenger)
                                LastPassenger = nil
                            end
                        end)
                    else
                        GeneratePassenger(vehicle)
                    end
                end
            end
        end

        Wait(timeDistance)
    end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- GENERATEPASSENGER
-----------------------------------------------------------------------------------------------------------------------------------------
function GeneratePassenger(vehicle)
    if LastPassenger ~= nil then
        TriggerServerEvent("tryDeleteObject", LastPassenger)
        LastPassenger = nil
    end

    local RandModels = math.random(#SpawnModelsTaxi)
    local mHash = GetHashKey(SpawnModelsTaxi[RandModels][1])

    RequestModel(mHash)
    while not HasModelLoaded(mHash) do
        Wait(1)
    end

    if HasModelLoaded(mHash) then
        CurrentPassenger = CreatePed(4, SpawnModelsTaxi[RandModels][2], SpawnPedsTaxi[SelectPosition][1], SpawnPedsTaxi[SelectPosition][2], SpawnPedsTaxi[SelectPosition][3], 3374176, true, false)
        SetEntityAsMissionEntity(CurrentPassenger, true, true)
        SetEntityInvincible(CurrentPassenger, true)
        SetModelAsNoLongerNeeded(mHash)

        local SeatCoords = GetWorldPositionOfEntityBone(vehicle, GetEntityBoneIndexByName(vehicle, "door_pside_f"))
        TaskGoStraightToCoord(CurrentPassenger, SeatCoords.x, SeatCoords.y, SeatCoords.z, 1.0, -1, 0.0, 0.0)

        while #(GetEntityCoords(CurrentPassenger) - SeatCoords) > 1.5 do
            Wait(100)
        end

        while not IsPedSittingInVehicle(CurrentPassenger, vehicle) do
            TaskEnterVehicle(CurrentPassenger, vehicle, -1, 2, 1.0, 1, 0)
            Wait(1000)
        end

        LastPosition = SelectPosition
        repeat
            if LastPosition == SelectPosition then
                SelectPosition = math.random(#StopVehicleTaxi)
            end
        until LastPosition ~= SelectPosition

        CurrentStatus = true
        BlipPassenger()
    end
end

-----------------------------------------------------------------------------------------------------------------------------------------
-- BLIPPASSENGER
-----------------------------------------------------------------------------------------------------------------------------------------
function BlipPassenger()
    if DoesBlipExist(ServiceBlip) then
        RemoveBlip(ServiceBlip)
        ServiceBlip = nil
    end

    ServiceBlip = AddBlipForCoord(StopVehicleTaxi[SelectPosition][1], StopVehicleTaxi[SelectPosition][2], StopVehicleTaxi[SelectPosition][3])
    SetBlipSprite(ServiceBlip, 12)
    SetBlipColour(ServiceBlip, 3)
    SetBlipScale(ServiceBlip, 0.9)
    SetBlipRoute(ServiceBlip, true)
    SetBlipAsShortRange(ServiceBlip, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("Taxista")
    EndTextCommandSetBlipName(ServiceBlip)
end