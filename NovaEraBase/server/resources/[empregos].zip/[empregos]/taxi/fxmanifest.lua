fx_version "bodacious"
game "gta5"
lua54 "yes"

shared_scripts {
	"shared-side/*"
}

client_scripts {
    "@vrp/config/Global.lua",
	"@vrp/lib/utils.lua",
	"client-side/*"
}

server_scripts {
    "@vrp/config/Global.lua",
	"@vrp/lib/utils.lua",
	"server-side/*"
}