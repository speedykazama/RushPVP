-----------------------------------------------------------------------------------------------------------------------------------------
-- INITWORKFRUITMAN
-----------------------------------------------------------------------------------------------------------------------------------------
InitWorkFruitman = vec3(1997.91,5111.08,43.0)
-----------------------------------------------------------------------------------------------------------------------------------------
-- CHECKWORKFRUITMAN
-----------------------------------------------------------------------------------------------------------------------------------------
CheckWorkFruitman = "Fruitman"
-----------------------------------------------------------------------------------------------------------------------------------------
-- EXPERIENCEWORKFRUITMAN
-----------------------------------------------------------------------------------------------------------------------------------------
ExperienceWorkFruitman = "Fruitman"
LevelExperienceWorkFruitman = 1
-----------------------------------------------------------------------------------------------------------------------------------------
-- REQUIREDITEMWORKFRUITMAN
-----------------------------------------------------------------------------------------------------------------------------------------
RequiredItemWorkFruitman = "WEAPON_HATCHET"
-----------------------------------------------------------------------------------------------------------------------------------------
-- ITENSWORKFRUITMAN
-----------------------------------------------------------------------------------------------------------------------------------------
ItensWorkFruitman = {
    { item = "acerola", Amount = {1,3} },
    { item = "banana", Amount = {2,5} },
    { item = "guarana", Amount = {1,4} },
    { item = "tomato", Amount = {1,2} },
    { item = "passion", Amount = {1,3} },
    { item = "grape", Amount = {1,4} },
    { item = "tange", Amount = {1,3} },
    { item = "orange", Amount = {2,5} },
    { item = "apple", Amount = {1,4} },
    { item = "strawberry", Amount = {1,3} },
    { item = "coffee2", Amount = {1,2} }
}
-----------------------------------------------------------------------------------------------------------------------------------------
-- PRESETFRUITMAN
-----------------------------------------------------------------------------------------------------------------------------------------
PresetFruitman = {
	["mp_m_freemode_01"] = {
		["hat"] = { item = 0, texture = 0 }, -- ["p0"] = --chapeu
		["pants"] = { item = 15, texture = 12 }, -- [4] =  --calça
		["vest"] = { item = 0, texture = 0 }, -- [9] =--COLETE
		["bracelet"] = { item = -1, texture = 0 }, -- ["p6"] =  --braço esquerdo
		["backpack"] = { item = 0, texture = 0 }, -- [5] =  --Mochila
		["decals"] = { item = 56, texture = 0 }, -- [10] = --adesivo
		["mask"] = { item = 0, texture = 0 }, -- [1] =-- mascara
		["shoes"] = { item = 27, texture = 0 }, -- [6] =  --sapatos
		["tshirt"] = { item = 15, texture = 0 }, -- [8] = --camisa1
		["torso"] = { item = 22, texture = 1 }, -- [11] = --jaqueta
		["accessory"] = { item = 155, texture = 4 }, -- [7] =  --accessorio
		["watch"] = { item = -1, texture = 0 }, -- ["p7"] = --braço direitoaaa
		["arms"] = { item = 0, texture = 0 }, -- [3] =  --mãos
		["glass"] = { item = 0, texture = 0 }, -- ["p1"] = -- oculos
		["ear"] = { item = -1, texture = 0 } -- ["p2"] =  -- orelha
	},
	["mp_f_freemode_01"] = {
		["hat"] = { item = -1, texture = 0 }, -- ["p0"] = --chapeu
		["pants"] = { item = 2, texture = 1 }, -- [4] =  --calça
		["vest"] = { item = -1, texture = 0 }, -- [9] =--COLETE
		["bracelet"] = { item = -1, texture = 0 }, -- ["p6"] =  --braço esquerdo
		["backpack"] = { item = 0, texture = 0 }, -- [5] =  --Mochila
		["decals"] = { item = 56, texture = 0 }, -- [10] = --adesivo
		["mask"] = { item = 0, texture = 0 }, -- [1] =-- mascara
		["shoes"] = { item = 26, texture = 0 }, -- [6] =  --sapatos
		["tshirt"] = { item = 14, texture = 0 }, -- [8] = --camisa1
		["torso"] = { item = 27, texture = 1 }, -- [11] = --jaqueta
		["accessory"] = { item = 155, texture = 4 }, -- [7] =  --accessorio
		["watch"] = { item = -1, texture = 0 }, -- ["p7"] = --braço direitoaaa
		["arms"] = { item = 20, texture = 0 }, -- [3] =  --mãos
		["glass"] = { item = 58, texture = 4 }, -- ["p1"] = -- oculos
		["ear"] = { item = -1, texture = 0 } -- ["p2"] =  -- orelha
	}
}