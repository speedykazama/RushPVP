-----------------------------------------------------------------------------------------------------------------------------------------
-- VRP
-----------------------------------------------------------------------------------------------------------------------------------------
local Tunnel = module("vrp","lib/Tunnel")
local Proxy = module("vrp","lib/Proxy")
vRPC = Tunnel.getInterface("vRP")
vRP = Proxy.getInterface("vRP")
-----------------------------------------------------------------------------------------------------------------------------------------
-- CONNECTION
-----------------------------------------------------------------------------------------------------------------------------------------
Creative = {}
Tunnel.bindInterface("farmer",Creative)
vCLIENT = Tunnel.getInterface("farmer")
vSKINSHOP = Tunnel.getInterface("skinshop")
-----------------------------------------------------------------------------------------------------------------------------------------
-- VARIABLES
-----------------------------------------------------------------------------------------------------------------------------------------
local Active = {}
-----------------------------------------------------------------------------------------------------------------------------------------
-- FARMER:FRUITMAN
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("farmer:Fruitman")
AddEventHandler("farmer:Fruitman", function(Number)
    if Objects[Number] then
        if GlobalState["Work"] >= Objects[Number]["Time"] then
            local source = source
            local Passport = vRP.Passport(source)
            if Passport and not Active[Passport] then
				if vRP.GetWork(Passport) == CheckWorkFruitman then
					Active[Passport] = true

					local Ped = GetPlayerPed(source)
					if GetSelectedPedWeapon(Ped) == GetHashKey(RequiredItemWorkFruitman) then
						local Select = math.random(#ItensWorkFruitman)
						local itemEntry = ItensWorkFruitman[Select]
						local itemName = itemEntry.item
						local minAmount = itemEntry.Amount[1]
						local maxAmount = itemEntry.Amount[2]
						local Amount = math.random(minAmount, maxAmount)

						if (vRP.InventoryWeight(Passport) + itemWeight(itemName) * Amount) <= vRP.GetWeight(Passport) then
							vRPC.playAnim(source, false, {"lumberjackaxe@idle","idle"}, true)
							TriggerClientEvent("Progress", source, "Colhendo", 5000)

							Objects[Number]["Time"] = GlobalState["Work"] + 25
							Player(source)["state"]["Buttons"] = true
							Player(source)["state"]["Cancel"] = true

							local timeProgress = 5
							repeat
								if timeProgress ~= 5 then
									Wait(400)
								end

								Wait(700)
								TriggerClientEvent("sounds:source", source, "lumberman", 0.1)
								timeProgress = timeProgress - 1
							until timeProgress <= 0

							Wait(400)

							TriggerClientEvent("farmer:Remover", -1, Number, Objects[Number]["Time"])
							vRP.GenerateItem(Passport, itemName, Amount, true)
							Player(source)["state"]["Buttons"] = false
							Player(source)["state"]["Cancel"] = false
							vRP.UpgradeStress(Passport, 2)
							vRP.PutExperience(Passport, ExperienceWorkFruitman, LevelExperienceWorkFruitman)
							vRPC.removeObjects(source)
							vRPC.Destroy(source)
						else
							TriggerClientEvent("Notify", source, "vermelho", "Mochila cheia.", 5000)
						end
					else
						TriggerClientEvent("Notify", source, "vermelho", "<b>Machado</b> não encontrado.", 5000)
					end

                	Active[Passport] = nil
				else
					TriggerClientEvent("Notify", source, "amarelo", "Você precisa ter a sua <b>Carteira de Trabalho</b> assinada no emprego de <b>"..ClassWork(CheckWorkFruitman).."</b> para conseguir trabalhar aqui.", 5000)
				end
            end
        end
    end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- FARMER:MINERMAN
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("farmer:Minerman")
AddEventHandler("farmer:Minerman", function(Number)
	if Objects[Number] then
		if GlobalState["Work"] >= Objects[Number]["Time"] then
			local source = source
			local Passport = vRP.Passport(source)
			if Passport and not Active[Passport] then
				if vRP.GetWork(Passport) == CheckWorkMinerman then
					Active[Passport] = true

					local itemEntry, itemName, minAmount, maxAmount, Amount

					if vRP.ConsultItem(Passport, RequiredItemWorkMinerman, 1) then
						itemEntry = ItensWorkMinerman[math.random(#ItensWorkMinerman)]
						itemName = itemEntry.item
						minAmount = itemEntry.Amount[1]
						maxAmount = itemEntry.Amount[2]
						Amount = math.random(minAmount, maxAmount)

						if (vRP.InventoryWeight(Passport) + itemWeight(itemName) * Amount) <= vRP.GetWeight(Passport) then
							vRPC.CreateObjects(source,"melee@large_wpn@streamed_core","ground_attack_on_spot","prop_tool_pickaxe",1,18905,0.10,-0.1,0.0,-92.0,260.0,5.0)
							TriggerClientEvent("Progress", source, "Mineirando", 10000)
							Objects[Number]["Time"] = GlobalState["Work"] + 60
							Player(source)["state"]["Buttons"] = true
							Player(source)["state"]["Cancel"] = true

							local timeProgress = 10
							repeat
								Wait(1000)
								timeProgress = timeProgress - 1
							until timeProgress <= 0

							Wait(1000)

							TriggerClientEvent("farmer:Remover", -1, Number, Objects[Number]["Time"])
							vRP.GenerateItem(Passport, itemName, Amount, true)
							Player(source)["state"]["Buttons"] = false
							Player(source)["state"]["Cancel"] = false
							vRP.UpgradeStress(Passport, 2)
							vRP.PutExperience(Passport, ExperienceWorkMinerman, LevelExperienceWorkMinerman)
							vRPC.Destroy(source)
						else
							TriggerClientEvent("Notify", source, "vermelho", "Mochila cheia.", 5000)
						end
					elseif vRP.ConsultItem(Passport, RequiredItemWorkMinermanPlus, 1) then
						itemEntry = ItensWorkMinermanPlus[math.random(#ItensWorkMinermanPlus)]
						itemName = itemEntry.item
						minAmount = itemEntry.Amount[1]
						maxAmount = itemEntry.Amount[2]
						Amount = math.random(minAmount, maxAmount)

						if (vRP.InventoryWeight(Passport) + itemWeight(itemName) * Amount) <= vRP.GetWeight(Passport) then
							vRPC.CreateObjects(source,"melee@large_wpn@streamed_core","ground_attack_on_spot","prop_tool_pickaxe",1,18905,0.10,-0.1,0.0,-92.0,260.0,5.0)
							TriggerClientEvent("Progress", source, "Mineirando", 3000)
							Objects[Number]["Time"] = GlobalState["Work"] + 10
							Player(source)["state"]["Buttons"] = true
							Player(source)["state"]["Cancel"] = true

							local timeProgress = 3
							repeat
								Wait(1000)
								timeProgress = timeProgress - 1
							until timeProgress <= 0

							Wait(1000)

							TriggerClientEvent("farmer:Remover", -1, Number, Objects[Number]["Time"])
							vRP.GenerateItem(Passport, itemName, Amount, true)
							Player(source)["state"]["Buttons"] = false
							Player(source)["state"]["Cancel"] = false
							vRP.UpgradeStress(Passport, 1)
							vRP.PutExperience(Passport, ExperienceWorkMinerman, LevelExperienceWorkMinermanPlus)
							vRPC.Destroy(source)
						else
							TriggerClientEvent("Notify", source, "vermelho", "Mochila cheia.", 5000)
						end

					else
						TriggerClientEvent("Notify", source, "vermelho", "<b>Picareta</b> não encontrada.", 5000)
					end

					Active[Passport] = nil
				else
					TriggerClientEvent("Notify", source, "amarelo", "Você precisa ter a sua <b>Carteira de Trabalho</b> assinada no emprego de <b>"..ClassWork(CheckWorkMinerman).."</b> para conseguir trabalhar aqui.", 5000)
				end
			end
		end
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- FARMER:LUMBERMAN
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("farmer:Lumberman")
AddEventHandler("farmer:Lumberman", function(Number)
    if Objects[Number] then
        if GlobalState["Work"] >= Objects[Number]["Time"] then
            local source = source
            local Passport = vRP.Passport(source)
            if Passport and not Active[Passport] then
				if vRP.GetWork(Passport) == CheckWorkLumberman then
					Active[Passport] = true

					local Ped = GetPlayerPed(source)
					if GetSelectedPedWeapon(Ped) == GetHashKey(RequiredItemWorkLuberman) then
						local itemEntry = ItensWorkLuberman[1]
						local itemName = itemEntry.item
						local minAmount = itemEntry.Amount[1]
						local maxAmount = itemEntry.Amount[2]
						local Amount = math.random(minAmount, maxAmount)

						if (vRP.InventoryWeight(Passport) + itemWeight(itemName) * Amount) <= vRP.GetWeight(Passport) then
							vRPC.playAnim(source, false, { "lumberjackaxe@idle", "idle" }, true)
							TriggerClientEvent("Progress", source, "Cortando", 11000)
							Objects[Number]["Time"] = GlobalState["Work"] + 15
							Player(source)["state"]["Buttons"] = true
							Player(source)["state"]["Cancel"] = true

							local timeProgress = 10
							repeat
								if timeProgress ~= 10 then Wait(400) end
								Wait(700)
								TriggerClientEvent("sounds:source", source, "lumberman", 0.1)
								timeProgress = timeProgress - 1
							until timeProgress <= 0

							Wait(400)

							TriggerClientEvent("farmer:Remover", -1, Number, Objects[Number]["Time"])
							vRP.GenerateItem(Passport, itemName, Amount, true)
							Player(source)["state"]["Buttons"] = false
							Player(source)["state"]["Cancel"] = false
							vRP.UpgradeStress(Passport, 2)
							vRP.PutExperience(Passport, ExperienceWorkLumberman, LevelExperienceWorkLumberman)
							vRPC.removeObjects(source)
							vRPC.Destroy(source)
						else
							TriggerClientEvent("Notify", source, "Aviso", "Mochila cheia.", 5000)
						end
					else
						TriggerClientEvent("Notify", source, "Aviso", "<b>Machado</b> não encontrado.", 5000)
					end

					Active[Passport] = nil
				else
					TriggerClientEvent("Notify", source, "amarelo", "Você precisa ter a sua <b>Carteira de Trabalho</b> assinada no emprego de <b>"..ClassWork(CheckWorkLumberman).."</b> para conseguir trabalhar aqui.", 5000)
				end
            end
        end
    end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- FARMER:TRANSPORTER
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("farmer:Transporter")
AddEventHandler("farmer:Transporter", function(Number)
	if Objects[Number] then
		if GlobalState["Work"] >= Objects[Number]["Time"] then
			local source = source
			local Passport = vRP.Passport(source)
			if Passport and not Active[Passport] then
				if vRP.GetWork(Passport) == CheckWorkTransporter then
					Active[Passport] = true

					local itemEntry = ItensWorkTransporter[1]
					local itemName = itemEntry.item
					local minAmount = itemEntry.Amount[1]
					local maxAmount = itemEntry.Amount[2]
					local Amount = math.random(minAmount, maxAmount)

					if (vRP.InventoryWeight(Passport) + itemWeight(itemName) * Amount) <= vRP.GetWeight(Passport) then
						vRPC.playAnim(source, false, {"pickup_object","pickup_low"}, true)
						TriggerClientEvent("Progress", source, "Coletando", 1000)
						Objects[Number]["Time"] = GlobalState["Work"] + 10
						Player(source)["state"]["Buttons"] = true
						Player(source)["state"]["Cancel"] = true

						Wait(1000)

						TriggerClientEvent("farmer:Remover", -1, Number, Objects[Number]["Time"])
						Player(source)["state"]["Buttons"] = false
						Player(source)["state"]["Cancel"] = false
						vRP.GenerateItem(Passport, itemName, Amount, true)
						vRP.UpgradeStress(Passport, 2)
						vRP.PutExperience(Passport, ExperienceWorkTransporter, LevelExperienceWorkTransporter)
						vRPC.removeObjects(source)
						vRPC.Destroy(source)
					else
						TriggerClientEvent("Notify", source, "Aviso", "Mochila cheia.", 5000)
					end

					Active[Passport] = nil
				else
					TriggerClientEvent("Notify", source, "amarelo", "Você precisa ter a sua <b>Carteira de Trabalho</b> assinada no emprego de <b>"..ClassWork(CheckWorkTransporter).."</b> para conseguir trabalhar aqui.", 5000)
				end
			end
		end
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- FARMER:DIVER
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("farmer:Diver")
AddEventHandler("farmer:Diver", function(Number)
	if Objects[Number] then
		if GlobalState["Work"] >= Objects[Number]["Time"] then
			local source = source
			local Passport = vRP.Passport(source)
			if Passport and not Active[Passport] then
				if vRP.GetWork(Passport) == CheckWorkDiver then
					Active[Passport] = true

					local itemEntry = ItensWorkDiver[1]
					local itemName = itemEntry.item
					local minAmount = itemEntry.Amount[1]
					local maxAmount = itemEntry.Amount[2]
					local Amount = math.random(minAmount, maxAmount)

					if (vRP.InventoryWeight(Passport) + itemWeight(itemName) * Amount) <= vRP.GetWeight(Passport) then
						vRPC.playAnim(source, false, {"anim@amb@clubhouse@tutorial@bkr_tut_ig3@", "machinic_loop_mechandplayer"}, true)
						TriggerClientEvent("Progress", source, "Coletando", 30000)
						Objects[Number]["Time"] = GlobalState["Work"] + 10
						Player(source)["state"]["Buttons"] = true
						Player(source)["state"]["Cancel"] = true

						Wait(30000)

						TriggerClientEvent("farmer:Remover", -1, Number, Objects[Number]["Time"])
						Player(source)["state"]["Buttons"] = false
						Player(source)["state"]["Cancel"] = false
						vRP.GenerateItem(Passport, itemName, Amount, true)
						vRP.UpgradeStress(Passport, 2)
						vRP.PutExperience(Passport, ExperienceWorkDiver, LevelExperienceWorkDiver)
						vRPC.Destroy(source)
					else
						TriggerClientEvent("Notify", source, "Aviso", "Mochila cheia.", 5000)
					end

					Active[Passport] = nil
				else
					TriggerClientEvent("Notify", source, "amarelo", "Você precisa ter a sua <b>Carteira de Trabalho</b> assinada no emprego de <b>"..ClassWork(CheckWorkDiver).."</b> para conseguir trabalhar aqui.", 5000)
				end
			end
		end
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- PAYMENT:LUMBERMAN
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("payment:Lumberman")
AddEventHandler("payment:Lumberman", function()
	local source = source
	local Passport = vRP.Passport(source)

	if Passport then
		if vRP.ConsultItem(Passport, ItemSellingLumberman, 1) then

			if not vRPC.LastVehicle(source,VehicleWorkLumberman) then
				TriggerClientEvent("Notify",source,"amarelo","Precisa utilizar o veículo do <b>Lenhador</b>.",3000)
				return
			end

			TriggerClientEvent("Progress", source, "Entregando", 2500)
			vRPC.playAnim(source,false,{ "amb@prop_human_parking_meter@female@idle_a", "idle_a_female" },true)
			Wait(2500)
			vRPC.stopAnim(source)

			local Experience = vRP.GetExperience(Passport, ExperienceWorkLumberman)
			local Category = ClassCategory(Experience)
			local Valuation = PaymentDefaultLumberman + (CategoryIncrementsLumberman[Category] or 0)

			vRP.RemoveItem(Passport, ItemSellingLumberman, 1, true)
			vRP.PutExperience(Passport, ExperienceWorkLumberman, LevelExperienceWorkLumberman)
			vRP.GenerateItem(Passport, ItemPaymentLumberman, Valuation, true)

			TriggerClientEvent("job:NextRoute", source)
		else
			TriggerClientEvent("Notify", source, "vermelho", "Você não possui <b>"..itemName(ItemSellingLumberman).."</b> para entregar.", 5000)
		end
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- PAYMENT:TRANSPORTER
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("payment:Transporter")
AddEventHandler("payment:Transporter", function()
	local source = source
	local Passport = vRP.Passport(source)

	if Passport then
		if vRP.ConsultItem(Passport, ItemSellingTransporter, 1) then

			if not vRPC.LastVehicle(source,VehicleWorkTransporter) then
				TriggerClientEvent("Notify",source,"amarelo","Precisa utilizar o veículo do <b>Transportador</b>.",3000)
				return
			end

			TriggerClientEvent("Progress", source, "Entregando", 2500)
			vRPC.playAnim(source,false,{ "amb@prop_human_parking_meter@female@idle_a", "idle_a_female" },true)
			Wait(2500)
			vRPC.stopAnim(source)

			local Experience = vRP.GetExperience(Passport, ExperienceWorkTransporter)
			local Category = ClassCategory(Experience)
			local Valuation = PaymentDefaultTransporter + (CategoryIncrementsTransporter[Category] or 0)

			vRP.RemoveItem(Passport, ItemSellingTransporter, 1, true)
			vRP.PutExperience(Passport, ExperienceWorkTransporter, LevelExperienceWorkTransporter)
			vRP.GenerateItem(Passport, ItemPaymentTransporter, Valuation, true)

			TriggerClientEvent("job:NextRoute", source)
		else
			TriggerClientEvent("Notify", source, "vermelho", "Você não possui <b>"..itemName(ItemSellingTransporter).."</b> para entregar.", 5000)
		end
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- PAYMENT:MILKMAN
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("payment:Milkman")
AddEventHandler("payment:Milkman", function()
	local source = source
	local Passport = vRP.Passport(source)

	if Passport then
		if vRP.ConsultItem(Passport, ItemSellingMilkman, 1) then

			if not vRPC.LastVehicle(source,VehicleWorkMilkman) then
				TriggerClientEvent("Notify",source,"amarelo","Precisa utilizar o veículo do <b>Entregador de Leite</b>.",3000)
				return
			end

			TriggerClientEvent("Progress", source, "Entregando", 2500)
			vRPC.playAnim(source,false,{ "amb@prop_human_parking_meter@female@idle_a", "idle_a_female" },true)
			Wait(2500)
			vRPC.stopAnim(source)

			local Experience = vRP.GetExperience(Passport, ExperienceWorkMilkman)
			local Category = ClassCategory(Experience)
			local Valuation = PaymentDefaultMilkman + (CategoryIncrementsMilkman[Category] or 0)

			vRP.RemoveItem(Passport, ItemSellingMilkman, 1, true)
			vRP.PutExperience(Passport, ExperienceWorkMilkman, LevelExperienceWorkMilkman)
			vRP.GenerateItem(Passport, ItemPaymentMilkman, Valuation, true)

			TriggerClientEvent("job:NextRoute", source)
		else
			TriggerClientEvent("Notify", source, "vermelho", "Você não possui <b>"..itemName(ItemSellingMilkman).."</b> para entregar.", 5000)
		end
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- PRESET:FRUITMAN
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("preset:fruitman")
AddEventHandler("preset:fruitman", function(Number)
    local source = source
    local Passport = vRP.Passport(source)
    if Passport then
        local Model = vRP.ModelPlayer(source)

        if Model == "mp_m_freemode_01" or Model == "mp_f_freemode_01" then
            TriggerClientEvent("skinshop:Apply", source, PresetFruitman[Model])
			TriggerClientEvent('Notify', source, 'verde', 'Você vestiu o Traje do Agricultor', 5000)
        end
    end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- PRESET:MINERMAN
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("preset:minerman")
AddEventHandler("preset:minerman", function(Number)
    local source = source
    local Passport = vRP.Passport(source)
    if Passport then
        local Model = vRP.ModelPlayer(source)

        if Model == "mp_m_freemode_01" or Model == "mp_f_freemode_01" then
            TriggerClientEvent("skinshop:Apply", source, PresetMinerman[Model])
			TriggerClientEvent('Notify', source, 'verde', 'Você vestiu o Traje de Minerador', 5000)
        end
    end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- PRESET:MILKMAN
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("preset:milkman")
AddEventHandler("preset:milkman", function(Number)
    local source = source
    local Passport = vRP.Passport(source)
    if Passport then
        local Model = vRP.ModelPlayer(source)

        if Model == "mp_m_freemode_01" or Model == "mp_f_freemode_01" then
            TriggerClientEvent("skinshop:Apply", source, PresetMilkman[Model])
			TriggerClientEvent('Notify', source, 'verde', 'Você vestiu o Traje de Pecuária', 5000)
        end
    end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- PRESET:LUMBERMAN
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("preset:lumberman")
AddEventHandler("preset:lumberman", function(Number)
    local source = source
    local Passport = vRP.Passport(source)
    if Passport then
        local Model = vRP.ModelPlayer(source)

        if Model == "mp_m_freemode_01" or Model == "mp_f_freemode_01" then
            TriggerClientEvent("skinshop:Apply", source, PresetLumberman[Model])
			TriggerClientEvent('Notify', source, 'verde', 'Você vestiu o Traje de Lenhador', 5000)
        end
    end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- PRESET:TRANSPORTER
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("preset:transporter")
AddEventHandler("preset:transporter", function(Number)
    local source = source
    local Passport = vRP.Passport(source)
    if Passport then
        local Model = vRP.ModelPlayer(source)

        if Model == "mp_m_freemode_01" or Model == "mp_f_freemode_01" then
            TriggerClientEvent("skinshop:Apply", source, PresetTransporter[Model])
			TriggerClientEvent('Notify', source, 'verde', 'Você vestiu o Traje de Transportador', 5000)
        end
    end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- PRESET:DIVER
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("preset:diver")
AddEventHandler("preset:diver", function(Number)
    local source = source
    local Passport = vRP.Passport(source)
    if Passport then
        local Model = vRP.ModelPlayer(source)

        if Model == "mp_m_freemode_01" or Model == "mp_f_freemode_01" then
            TriggerClientEvent("skinshop:Apply", source, PresetDiver[Model])
			TriggerClientEvent('Notify', source, 'verde', 'Você vestiu o Traje de Mergulhador', 5000)
        end
    end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- CHECKWORK
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.CheckWork(Work)
	local source = source
	local Passport = vRP.Passport(source)
	if Passport then
		if vRP.GetWork(Passport) == Work then
			return true
		else
			TriggerClientEvent("Notify", source, "amarelo", "Você precisa ter a sua <b>Carteira de Trabalho</b> assinada no emprego de <b>"..ClassWork(Work).."</b> para conseguir trabalhar aqui.",  5000)
		end

		return false
	end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- CONNECT
-----------------------------------------------------------------------------------------------------------------------------------------
AddEventHandler("Connect",function(Passport,source)
	TriggerClientEvent("farmer:Table",source,Objects)
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- DISCONNECT
-----------------------------------------------------------------------------------------------------------------------------------------
AddEventHandler("Disconnect",function(Passport,source)
	if Active[Passport] then
		Active[Passport] = nil
	end
end)