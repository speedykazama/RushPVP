-----------------------------------------------------------------------------------------------------------------------------------------
-- VRP
-----------------------------------------------------------------------------------------------------------------------------------------
local Tunnel = module("vrp","lib/Tunnel")
local Proxy = module("vrp","lib/Proxy")
vRP = Proxy.getInterface("vRP")
-----------------------------------------------------------------------------------------------------------------------------------------
-- CONNECTION
-----------------------------------------------------------------------------------------------------------------------------------------
Creative = {}
Tunnel.bindInterface("farmer",Creative)
vSERVER = Tunnel.getInterface("farmer")
-----------------------------------------------------------------------------------------------------------------------------------------
-- VARIABLES
-----------------------------------------------------------------------------------------------------------------------------------------
local Objects = {}
local Displayed = {}
local Blip = nil
local ActiveJob = nil
local Selected = 1
local Active = false
-----------------------------------------------------------------------------------------------------------------------------------------
-- INPUTTARGETPOSITION
-----------------------------------------------------------------------------------------------------------------------------------------
function InputTargetPosition(Number,v)
	if v["Model"] == "prop_money_bag_01" then
		exports["target"]:AddBoxZone("Farmer:"..Number,v["Coords"],v["Width"],v["Width"],{
			name = "Farmer:"..Number,
			heading = v["Heading"],
			minZ = v["Coords"]["z"] - 1.0,
			maxZ = v["Coords"]["z"] - 0.5
		},{
			shop = Number,
			Distance = v["Distance"],
			options = {
				{
					event = v["Event"],
					label = v["Label"],
					tunnel = "server"
				}
			}
		})
	else
		exports["target"]:AddCircleZone("Farmer:"..Number,v["Coords"],v["Width"],{
			name = "Farmer:"..Number,
			heading = v["Heading"]
		},{
			shop = Number,
			Distance = v["Distance"],
			options = {
				{
					event = v["Event"],
					label = v["Label"],
					tunnel = "server"
				}
			}
		})
	end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- TARGET
-----------------------------------------------------------------------------------------------------------------------------------------
CreateThread(function()
	local TargetJobs = {
		{
			key = "Fruitman",
			coords = InitWorkFruitman,
			options = {
				{ 
					event = "shops:Fruteira",
					label = "Vender Frutas",
					tunnel = "client" 
				},{ 
					event = "preset:fruitman",
					label = "Traje Agricultor",
					tunnel = "server"
				}
			}
		},
		{
			key = "Minerman",
			coords = InitWorkMinerman,
			options = {
				{ 
					event = "shops:Miners",
					label = "Vender Minérios",
					tunnel = "client" 
				},{ 
					event = "preset:minerman",
					label = "Traje Minerador",
					tunnel = "server"
				}
			}
		},
		{
			key = "Diver",
			coords = InitWorkDiver,
			options = {
				{
					event = "shops:Diver",
					label = "Comprar Acessórios",
					tunnel = "client" 
				},{ 
					event = "shops:Diver2",
					label = "Vender Itens",
					tunnel = "client" 
				},{ 
					event = "preset:diver",
					label = "Traje Mergulhador",
					tunnel = "server"
				}
			}
		},
		{
			key = "Lumberman",
			coords = InitWorkLumberman,
			options = {
				{ 
					event = "lumberman:Init",
					label = "Trabalhar",
					tunnel = "client" 
				},{ 
					event = "preset:lumberman",
					label = "Traje Lenhador",
					tunnel = "server"
				}
			}
		},
		{
			key = "Transporter",
			coords = InitWorkTransporter,
			options = {
				{ 
					event = "transporter:Init",
					label = "Trabalhar",
					tunnel = "client" 
				},{ 
					event = "preset:transporter",
					label = "Traje Transportador",
					tunnel = "server"
				}
			}
		},
		{
			key = "Milkman",
			coords = InitWorkMilkman,
			options = {
				{ 
					event = "milkman:Init",
					label = "Trabalhar",
					tunnel = "client"
				},{ 
					event = "preset:milkman",
					label = "Traje Pecuária",
					tunnel = "server"
				}
			}
		}
	}

	for _, job in pairs(TargetJobs) do
		exports["target"]:AddCircleZone(job.key, job.coords, 1.5, {
			name = job.key,
			heading = 3374176
		}, {
			Distance = 2.0,
			options = job.options
		})
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- STARTJOB
-----------------------------------------------------------------------------------------------------------------------------------------
function StartJob(jobKey)
    local job = Jobs[jobKey]

    if Active then
        exports["target"]:LabelText(job.name, "Trabalhar")
        TriggerEvent("Notify", "amarelo", "Trabalho finalizado.", 5000)
        Active = false
        ActiveJob = nil
        if DoesBlipExist(Blip) then
            RemoveBlip(Blip)
            Blip = nil
        end
    else
        Active = true
        ActiveJob = jobKey
        Selected = job.useSequential and 1 or math.random(#job.routes)

        local target = job.routes[Selected]
        Marker(target.x, target.y, target.z)

        exports["target"]:LabelText(job.name, "Finalizar")
        TriggerEvent("Notify", "verde", "Trabalho iniciado.", 5000)

        CreateThread(function()
            local Deliver = true

            while Active do
				local ped = PlayerPedId()
				local coords = GetEntityCoords(ped)

				local currentJob = Jobs[ActiveJob]
				if currentJob then
					local target = currentJob.routes[Selected]
					local distance = #(coords - target)

					if distance <= 15.0 then
						DrawText(target.x, target.y, target.z, "E N T R E G A R", distance <= 1.5)
						if distance <= 1.5 and IsControlJustPressed(0, 38) and Deliver then
							Deliver = false
							TriggerServerEvent(currentJob.event)

							SetTimeout(3000, function()
								Deliver = true
							end)
						end
					end
				end

				Wait(1)
			end

        end)
    end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- JOB:NEXTROUTE
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("job:NextRoute")
AddEventHandler("job:NextRoute", function()
    local job = Jobs[ActiveJob]

    Selected = Selected + 1
    if Selected > #job.routes then Selected = 1 end

    local NextTarget = job.routes[Selected]
    Marker(NextTarget.x, NextTarget.y, NextTarget.z)
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- LUMBERMAN:INIT
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("lumberman:Init")
AddEventHandler("lumberman:Init", function()
	if vSERVER.CheckWork(CheckWorkLumberman) then
    	StartJob("lumberman")
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- TRANSPORTER:INIT
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("transporter:Init")
AddEventHandler("transporter:Init", function()
	if vSERVER.CheckWork(CheckWorkTransporter) then
    	StartJob("transporter")
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- MILKMAN:INIT
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("milkman:Init")
AddEventHandler("milkman:Init", function()
	if vSERVER.CheckWork(CheckWorkMilkman) then
    	StartJob("milkman")
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- DRAWTEXT
-----------------------------------------------------------------------------------------------------------------------------------------
function DrawText(x, y, z, text)
    local onScreen, _x, _y = GetScreenCoordFromWorldCoord(x, y, z)

    if onScreen then
        SetTextFont(4)
        SetTextCentre(true)
        SetTextProportional(1)
        SetTextScale(0.35, 0.35)
        SetTextColour(255,255,255,150)

        SetTextEntry("STRING")
        AddTextComponentString(text)
        EndTextCommandDisplayText(_x,_y)

        local Width = string.len(text) / 160 * 0.45
        DrawRect(_x,_y + 0.0125,Width,0.03,15,15,15,175)
    end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- MARKER
-----------------------------------------------------------------------------------------------------------------------------------------
function Marker(x, y, z)
    if DoesBlipExist(Blip) then
        RemoveBlip(Blip)
        Blip = nil
    end

    Blip = AddBlipForCoord(x, y, z)
    SetBlipSprite(Blip, 1)
    SetBlipColour(Blip, 3)
    SetBlipScale(Blip, 0.5)
    SetBlipRoute(Blip, true)
    SetBlipAsShortRange(Blip, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("Entrega")
    EndTextCommandSetBlipName(Blip)
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- THREADOBJECTS
-----------------------------------------------------------------------------------------------------------------------------------------
CreateThread(function()
	while true do
		local Ped = PlayerPedId()
		local Coords = GetEntityCoords(Ped)

		for Number,v in pairs(Objects) do
			local Distance = #(Coords - v["Coords"])
			if Distance <= v["Show"] and GlobalState["Work"] >= v["Time"] then
				if not Displayed[Number] then
					if LoadModel(v["Model"]) then
						Displayed[Number] = CreateObjectNoOffset(v["Model"],v["Coords"]["x"],v["Coords"]["y"],v["Coords"]["z"] - v["Height"],false,false,false)
						SetEntityHeading(Displayed[Number],v["Heading"])
						FreezeEntityPosition(Displayed[Number],true)
						SetModelAsNoLongerNeeded(v["Model"])
						InputTargetPosition(Number,v)
					end
				end
			else
				if Displayed[Number] then
					exports["target"]:RemCircleZone("Farmer:"..Number)

					if DoesEntityExist(Displayed[Number]) then
						DeleteEntity(Displayed[Number])
						Displayed[Number] = nil
					end
				end
			end
		end

		Wait(1000)
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- FARMER:REMOVER
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("farmer:Remover")
AddEventHandler("farmer:Remover",function(Number,Timers)
	if Objects[Number] then
		Objects[Number]["Time"] = Timers

		if Displayed[Number] then
			exports["target"]:RemCircleZone("Farmer:"..Number)

			if DoesEntityExist(Displayed[Number]) then
				DeleteEntity(Displayed[Number])
				Displayed[Number] = nil
			end
		end
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- FARMER:TABLE
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("farmer:Table")
AddEventHandler("farmer:Table",function(Table)
	Objects = Table
end)