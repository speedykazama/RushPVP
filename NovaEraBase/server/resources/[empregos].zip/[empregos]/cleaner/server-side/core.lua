-----------------------------------------------------------------------------------------------------------------------------------------
-- VRP
-----------------------------------------------------------------------------------------------------------------------------------------
local Tunnel = module("vrp","lib/Tunnel")
local Proxy = module("vrp","lib/Proxy")
vRP = Proxy.getInterface("vRP")
-----------------------------------------------------------------------------------------------------------------------------------------
-- CONNECTION
-----------------------------------------------------------------------------------------------------------------------------------------
Creative = {}
Tunnel.bindInterface("cleaner", Creative)
vSERVER = Tunnel.getInterface("cleaner")
-----------------------------------------------------------------------------------------------------------------------------------------
-- VARIABLES
-----------------------------------------------------------------------------------------------------------------------------------------
local Delay = {}
-----------------------------------------------------------------------------------------------------------------------------------------
-- CHECKPROPERTY
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.CheckProperty(Number)
	local source = source
	if not Delay[Number] or Delay[Number] <= os.time() then
		Delay[Number] = os.time() + (TimeCleanerHouse * 60)
		return true
	else
		TriggerClientEvent("Notify", source, "azul", "Aguarde "..CompleteTimers(tonumber(Delay[Number]) - tonumber(os.time()))..".", 5000)
		return false
	end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- PAYMENTCLEANER
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.PaymentCleaner(ServicesDone)
	local source = source
	local Passport = vRP.Passport(source)
	if Passport then
		local Completed = true
		for k,v in pairs(ServicesDone) do
			if not v then
				Completed = false
				break
			end
		end

		if Completed then
			local Experience = vRP.GetExperience(Passport, ExperienceWorkCleaner)
			local Category = ClassCategory(Experience)
			local Valuation = PaymentDefaultCleaner + (CategoryIncrementsCleaner[Category] or 0)

        	vRP.PutExperience(Passport, ExperienceWorkCleaner, LevelExperienceWorkCleaner)
        	vRP.GenerateItem(Passport, ItemPaymentCleaner, Valuation, true)
		end
	end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- PRESET:CLEANER
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("preset:cleaner")
AddEventHandler("preset:cleaner", function(Number)
    local source = source
    local Passport = vRP.Passport(source)
    if Passport then
        local Model = vRP.ModelPlayer(source)

        if Model == "mp_m_freemode_01" or Model == "mp_f_freemode_01" then
            TriggerClientEvent("skinshop:Apply", source, PresetCleaner[Model])
			TriggerClientEvent('Notify', source, 'verde', 'Você vestiu o Traje de Faxineiro', 5000)
        end
    end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- CHECKWORK
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.CheckWork(Work)
	local source = source
	local Passport = vRP.Passport(source)
	if Passport then
		if vRP.GetWork(Passport) == Work then
			return true
		else
			TriggerClientEvent("Notify", source, "amarelo", "Você precisa ter a sua <b>Carteira de Trabalho</b> assinada no emprego de <b>"..ClassWork(Work).."</b> para conseguir trabalhar aqui.",  5000)
		end

		return false
	end
end