-----------------------------------------------------------------------------------------------------------------------------------------
-- VARIAVEIS
-----------------------------------------------------------------------------------------------------------------------------------------
local HomesTheft = {
	["Open"] = "",
	["Theft"] = "",
	["InternTheft"] = {},
	["CurrentTheft"] = {},
	["Called"] = false,
	["TheftCoords"] = {},
	["Police"] = GetGameTimer()
}
-----------------------------------------------------------------------------------------------------------------------------------------
-- LOCALPLAYER
-----------------------------------------------------------------------------------------------------------------------------------------
LocalPlayer["state"]["TheftName"] = 0
LocalPlayer["state"]["Theft"] = false
-----------------------------------------------------------------------------------------------------------------------------------------
-- PROPERTYS:UPDATECALLED
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("propertys:UpdateCalled")
AddEventHandler("propertys:UpdateCalled",function()
	HomesTheft["Called"] = true
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- GRIDCHUNK
-----------------------------------------------------------------------------------------------------------------------------------------
function gridChunk(x)
	return math.floor((x + 8192) / 128)
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- TOCHANNEL
-----------------------------------------------------------------------------------------------------------------------------------------
function toChannel(v)
	return (v["x"] << 8) | v["y"]
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- GETGRIDZONE
-----------------------------------------------------------------------------------------------------------------------------------------
function getGridzone(x,y)
	local gridChunk = vector2(gridChunk(x),gridChunk(y))
	return toChannel(gridChunk)
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- ENTRANCEHOMES
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.entranceHomes(TheftName,v,Interior,Theft)
	DoScreenFadeOut(0)

	HomesTheft["CurrentTheft"] = v
	HomesTheft["Open"] = TheftName
	LocalPlayer["state"]["TheftName"] = TheftName
	TriggerEvent("sounds:source","enterhouse",0.7)

	local ped = PlayerPedId()

	if Interior == "Beach" then
		SetEntityCoords(ped,298.05,-303.34,-23.99,1,0,0,0)
		table.insert(HomesTheft["InternTheft"],{ 298.05,-303.34,-23.99,"exit","Saída" })
	elseif Interior == "Franklin" then
		SetEntityCoords(ped,28.58,-24.35,-24.01,1,0,0,0)
		table.insert(HomesTheft["InternTheft"],{ 28.58,-24.35,-24.01,"exit","Saída" })
	elseif Interior == "Middle" then
		SetEntityCoords(ped,86.41,-91.47,-24.2,1,0,0,0)
		table.insert(HomesTheft["InternTheft"],{ 86.41,-91.47,-24.2,"exit","Saída" })
	elseif Interior == "Motel" then
		SetEntityCoords(ped,51.61,-39.05,-25.86,1,0,0,0)
		table.insert(HomesTheft["InternTheft"],{ 51.61,-39.05,-25.86,"exit","Saída" })
	elseif Interior == "Square" then
		SetEntityCoords(ped,68.64,67.3,-23.4,1,0,0,0)
		table.insert(HomesTheft["InternTheft"],{ 68.64,67.3,-23.4,"exit","Saída" })
	elseif Interior == "ThreeFloors" then
		SetEntityCoords(ped,118.4,-108.39,-23.57,1,0,0,0)
		table.insert(HomesTheft["InternTheft"],{ 118.4,-108.39,-23.57,"exit","Saída" })
	elseif Interior == "Trailer" then
		SetEntityCoords(ped,499.28,-501.96,-23.61,1,0,0,0)
		table.insert(HomesTheft["InternTheft"],{ 499.28,-501.96,-23.61,"exit","Saída" })
	elseif Interior == "TwoFloors" then
		SetEntityCoords(ped,166.78,-144.32,-17.79,1,0,0,0)
		table.insert(HomesTheft["InternTheft"],{ 166.78,-144.32,-17.79,"exit","Saída" })
	end

	FreezeEntityPosition(ped,true)
	Wait(1000)
	FreezeEntityPosition(ped,false)
	DoScreenFadeIn(1000)

	if Theft then
		HomesTheft["Theft"] = Interior
		LocalPlayer["state"]["Theft"] = true
		HomesTheft["Police"] = GetGameTimer() + 15000

		if math.random(100) >= 95 then
			HomesTheft["Police"] = GetGameTimer() + 15000
			HomesTheft["Called"] = true
			vSERVER.callPolice(HomesTheft["CurrentTheft"][1],HomesTheft["CurrentTheft"][2],HomesTheft["CurrentTheft"][3])
		end
	end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- PROPERYS:INVADEPOLICEVENT
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("propertys:invadePoliceEvent")
AddEventHandler("propertys:invadePoliceEvent",function()
    TriggerServerEvent("propertys:invadePoliceEvent")
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- THREADROBBERYS
-----------------------------------------------------------------------------------------------------------------------------------------
CreateThread(function()
	SetNuiFocus(false,false)

	while true do
		local innerTable = {}
		local timeDistance = 999
		if HomesTheft["Theft"] ~= "" and HomesTheft["Open"] ~= "" then
			local ped = PlayerPedId()
			if not IsPedInAnyVehicle(ped) then
				local speed = GetEntitySpeed(ped)
				local coords = GetEntityCoords(ped)

				if speed > 2 and GetGameTimer() >= HomesTheft["Police"] and not HomesTheft["Called"] then
					HomesTheft["Police"] = GetGameTimer() + 15000
					for k,v in pairs(HomesTheft["InternTheft"]) do
						vSERVER.callPolice(HomesTheft["CurrentTheft"][1],HomesTheft["CurrentTheft"][2],HomesTheft["CurrentTheft"][3])
					end
				end

				if TheftCoords[HomesTheft["Theft"]] then
					for k,v in pairs(TheftCoords[HomesTheft["Theft"]]) do
						if not HomesTheft["TheftCoords"][k] then
							local distance = #(coords - vector3(v[1],v[2],v[3]))

							if distance <= 1.25 then
								timeDistance = 2
								text3D(v[1],v[2],v[3],'~b~[E] ~w~PARA ROUBAR')

								if IsControlJustPressed(1,38) then
									LocalPlayer["state"]["Cancel"] = true
									vRP.playAnim(false,{"anim@amb@clubhouse@tutorial@bkr_tut_ig3@","machinic_loop_mechandplayer"},true)

									LocalPlayer["state"]["Commands"] = true
									vRP.playAnim(false,{"anim@amb@clubhouse@tutorial@bkr_tut_ig3@","machinic_loop_mechandplayer"},true)

									TriggerEvent("Progress","Vasculhando",10000)
									Citizen.Wait(10000)

									LocalPlayer["state"]["Commands"] = false
									vSERVER.paymentTheft("MOBILE")
									HomesTheft["TheftCoords"][k] = true

									LocalPlayer["state"]["Cancel"] = false
									vRP.Destroy()
								end
							end
						end
					end
				end
			end
		end

		TriggerEvent("hoverfy:Insert",innerTable)

		Wait(timeDistance)
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- THREADINTERN
-----------------------------------------------------------------------------------------------------------------------------------------
CreateThread(function()
	while true do
		local innerTable = {}
		local timeDistance = 999
		if HomesTheft["Open"] ~= "" then
			local ped = PlayerPedId()
			if not IsPedInAnyVehicle(ped) then
				local coords = GetEntityCoords(ped)

				for k,v in pairs(HomesTheft["InternTheft"]) do
					if coords[3] <= -1450 and v[4] == "exit" then
						SetEntityCoords(ped,v[1],v[2],v[3],1,0,0,0)
					end

					local distance = #(coords - vec3(v[1],v[2],v[3]))
					if distance <= 1.25 then
						timeDistance = 1.25
						table.insert(innerTable,{ v[1],v[2],v[3],1.25,"E",v[5],"Pressione para acessar" })

						if IsControlJustPressed(1,38) then
							if v[4] == "exit" then
								if distance <= 1 then
									DoScreenFadeOut(0)

									SetEntityCoords(ped,HomesTheft["CurrentTheft"][1],HomesTheft["CurrentTheft"][2],HomesTheft["CurrentTheft"][3] - 0.75,1,0,0,0)

									TriggerEvent("sounds:source","outhouse",0.5)
									vSERVER.removeNetwork(HomesTheft["Open"])
									LocalPlayer["state"]["Theft"] = false
									LocalPlayer["state"]["TheftName"] = 0
									HomesTheft["TheftCoords"] = {}
									HomesTheft["Called"] = false
									HomesTheft["InternTheft"] = {}
									HomesTheft["Theft"] = ""
									HomesTheft["Open"] = ""

									FreezeEntityPosition(ped,true)
									Wait(1000)
									FreezeEntityPosition(ped,false)
									DoScreenFadeIn(1000)
								end
							end
						end
					end
				end
			end
		end

		TriggerEvent("hoverfy:Insert",innerTable)

		Wait(timeDistance)
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- PROPERTYS:INVADEPOLICE
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("propertys:invadePolice")
AddEventHandler("propertys:invadePolice",function()
	LocalPlayer["state"]["Theft"] = true
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- TEXT3D
-----------------------------------------------------------------------------------------------------------------------------------------
function text3D(x,y,z,text)
	local onScreen,_x,_y = World3dToScreen2d(x,y,z)

	SetTextFont(4)
	SetTextScale(0.35,0.35)
	SetTextColour(255,255,255,150)
	SetTextEntry("STRING")
	SetTextCentre(1)
	AddTextComponentString(text)
	DrawText(_x,_y)
	local factor = (string.len(text))/370
	DrawRect(_x,_y+0.0125,0.01+factor,0.03,0,0,0,80)
end