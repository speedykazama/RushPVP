WeighVaultHotel = 50          -- Peso do baú do Hotel
WeighFridgeHotel = 50         -- Peso da geladeira do Hotel
PropertyTaxPercent = 10       -- Porcentagem da taxa da propriedade (ex: 10 = 10%)