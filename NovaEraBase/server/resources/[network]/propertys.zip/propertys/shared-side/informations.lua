Informations = {
	["Emerald"] = {
		["Price"] = 500000,
		["Vault"] = 125,
		["Fridge"] = 25
	},
	["Ruby"] = {
		["Price"] = 750000,
		["Vault"] = 175,
		["Fridge"] = 35
	},
	["Sapphire"] = {
		["Price"] = 1000000,
		["Vault"] = 250,
		["Fridge"] = 50
	},
	["Amethyst"] = {
		["Price"] = 1500000,
		["Vault"] = 375,
		["Fridge"] = 75
	},
	["Amber"] = {
		["Price"] = 2000000,
		["Vault"] = 500,
		["Fridge"] = 100
	}
}