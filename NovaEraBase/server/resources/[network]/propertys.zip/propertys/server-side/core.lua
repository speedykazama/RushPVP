-----------------------------------------------------------------------------------------------------------------------------------------
-- VRP
-----------------------------------------------------------------------------------------------------------------------------------------
local Tunnel = module("vrp","lib/Tunnel")
local Proxy = module("vrp","lib/Proxy")
vRP = Proxy.getInterface("vRP")
-----------------------------------------------------------------------------------------------------------------------------------------
-- CONNECTION
-----------------------------------------------------------------------------------------------------------------------------------------
Creative = {}
Tunnel.bindInterface("propertys",Creative)
vCLIENT = Tunnel.getInterface("propertys")
vKEYBOARD = Tunnel.getInterface("keyboard")
vSKINSHOP = Tunnel.getInterface("skinshop")
-----------------------------------------------------------------------------------------------------------------------------------------
-- VARIABLES
-----------------------------------------------------------------------------------------------------------------------------------------
local Lock = {}
local Inside = {}
local Actived = {}
local Markers = {}
-----------------------------------------------------------------------------------------------------------------------------------------
-- PROPERTYS
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.Propertys(Name)
	local source = source
	local Passport = vRP.Passport(source)

	if vRP.GetTax(source) > NewBankMinTaxs then
        TriggerClientEvent("Notify", source, "amarelo", "Você possui muitos <b>Impostos Atrasados</b>.", 5000)
        return false
    end

	if Passport then
		if Name == "Hotel" then
			if vRP.ConsultPropertys("propertys/Count", { Passport = Passport }) > 0 then
				TriggerClientEvent("Notify", source,"amarelo", "Você já possui casa em seu nome e não pode usar o Hotel.", 5000)
				return false
			else
				return Name
			end
		else
		local Consult = vRP.Query("propertys/Exist",{ name = Name })
		if Consult[1] then
			if parseInt(Consult[1]["Passport"]) == Passport or vRP.InventoryFull(Passport,"propertys-"..Consult[1]["Serial"]) or Lock[Name] then
				if os.time() > Consult[1]["Tax"] then
					if vRP.Request(source,"Hipoteca atrasada, deseja efetuar o pagamento?","Sim, concluir pagamento","Não, pago depois") then
						if vRP.PaymentFull(Passport,Informations[Consult[1]["Interior"]]["Price"] * 0.1) then
							vRP.Query("propertys/Tax",{ name = Name })
							TriggerClientEvent("Notify",source,"amarelo","Pagamento concluído.",5000)
						end
					end
				else
					Consult[1]["Tax"] = MinimalTimers(Consult[1]["Tax"] - os.time())
					return "Player",Consult[1]
				end
			end
		else
			return "Corretor",Informations
		end
	end
end

	return false
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- PROPERTYS:TOGGLE
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("propertys:Toggle")
AddEventHandler("propertys:Toggle",function(Name)
	local source = source
	local Passport = vRP.Passport(source)
	if Passport then
		if Inside[Passport] then
			Inside[Passport] = nil
			TriggerEvent("vRP:BucketServer",source,"Exit")
		else
			Inside[Passport] = Name
			TriggerEvent("vRP:BucketServer",source,"Enter",Route(Name))
		end
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- PROPERTYS:TOGGLE
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("hotel:Toggle")
AddEventHandler("hotel:Toggle",function(Name)
	local source = source
	local Passport = vRP.Passport(source)
	if Passport then
		if Inside[Passport] then
			Inside[Passport] = nil
			TriggerEvent("vRP:BucketServer",source,"Exit")
		else
			Inside[Passport] = Name
			TriggerEvent("vRP:BucketServer",source,"Enter",Passport)
		end
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- PROPERTYS:BUY
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("propertys:Buy")
AddEventHandler("propertys:Buy", function(Name)
    local source = source
    local Passport = vRP.Passport(source)

    if Passport then
        local MaxPropertys = MaxPropertysPadrao
        if vRP.HasGroup(Passport,"PremiumPrata") then
            MaxPropertys = MaxPropertys + MaxPropertysPremiumPrata
        elseif vRP.HasGroup(Passport,"PremiumOuro") then
            MaxPropertys = MaxPropertys + MaxPropertysPremiumOuro
        elseif vRP.HasGroup(Passport,"PremiumPlatina") then
            MaxPropertys = MaxPropertys + MaxPropertysPremiumPlatina
        end

        local PropertyCount = vRP.Query("propertys/Count", { Passport = Passport })[1].count or 0
        if PropertyCount >= MaxPropertys then
            TriggerClientEvent("Notify", source, "vermelho", "Você já atingiu o limite máximo de propriedades.", 5000)
            return
        end

        local Split = splitString(Name, "-")
        local Name = Split[1]
        local Interior = Split[2]
        local Consult = vRP.Query("propertys/Exist", { name = Name })

        if not Consult[1] then
            TriggerClientEvent("dynamic:closeSystem", source)

            local propertyPrice = Informations[Interior]["Price"]
            local purchaseText = "Deseja comprar a propriedade por $" .. propertyPrice .. "?"

            if vRP.Request(source, purchaseText) then
                if vRP.PaymentFull(Passport, propertyPrice) then
                    Markers[Name] = true
                    local Serial = PropertysSerials()
                    vRP.GiveItem(Passport, "propertys-" .. Serial, 3, true)
                    TriggerClientEvent("propertys:Markers", -1, Markers)

					local taxValue = math.floor(Informations[Interior]["Price"] * (PropertyTaxPercent / 100))

					if NewBankTaxs then
						exports["bank"]:AddTaxs(Passport,"Propriedades",taxValue,"Compra de propriedade.")
					end
					
                    vRP.Query("propertys/Buy", {
                        name = Name,
                        interior = Interior,
                        passport = Passport,
                        serial = Serial,
                        vault = Informations[Interior]["Vault"],
                        fridge = Informations[Interior]["Fridge"],
                        tax = os.time() + 2592000
                    })
                else
                    TriggerClientEvent("Notify", source, "vermelho", "<b>Dólares</b> insuficientes.", 5000)
                end
            end
        end
    end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- PROPERTYS:LOCK
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("propertys:Lock")
AddEventHandler("propertys:Lock",function(Name)
	local source = source
	local Passport = vRP.Passport(source)
	if Passport then
		local Consult = vRP.Query("propertys/Exist",{ name = Name })
		if Consult[1] then
			if parseInt(Consult[1]["Passport"]) == Passport or vRP.InventoryFull(Passport,"propertys-"..Consult[1]["Serial"]) then
				if Lock[Name] then
					Lock[Name] = nil
					TriggerClientEvent("Notify",source,"amarelo","Propriedade trancada.",5000)
				else
					Lock[Name] = true
					TriggerClientEvent("Notify",source,"amarelo","Propriedade destrancada.",5000)
				end
			end
		end
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- PROPERTYS:SELL
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("propertys:Sell")
AddEventHandler("propertys:Sell", function(Name)
    local source = source
    local Passport = vRP.Passport(source)
    
    if Passport then
        local Consult = vRP.Query("propertys/Exist", { name = Name })
        
        if Consult[1] then
            if parseInt(Consult[1]["Passport"]) == Passport then
                TriggerClientEvent("dynamic:closeSystem", source)

                local propertyPrice = Informations[Consult[1]["Interior"]]["Price"]
                local sellPrice = propertyPrice * 0.75

                local confirmationText = "Deseja vender a propriedade por $" .. sellPrice .. ""
                
                if vRP.Request(source, confirmationText) then
                    if Markers[Name] then
                        Markers[Name] = nil
                        TriggerClientEvent("propertys:Markers", -1, Markers)
                    end

                    vRP.RemSrvData("Vault:" .. Name)
                    vRP.RemSrvData("Fridge:" .. Name)

                    vRP.Query("propertys/Sell", { name = Name })
                    TriggerClientEvent("Notify", source, "amarelo", "Venda concluída.", 5000)
                    vRP.GiveBank(Passport, sellPrice)
                end
            end
        end
    end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- PROPERTYS:TRANSFER
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("propertys:Transfer")
AddEventHandler("propertys:Transfer", function(Name)
    local source = source
    local Passport = vRP.Passport(source)
    
    if Passport then
        local Consult = vRP.Query("propertys/Exist", { name = Name })
        if Consult[1] and Consult[1]["Passport"] == Passport then
            TriggerClientEvent("dynamic:closeSystem", source)
            
            local Keyboard = vKEYBOARD.keySingle(source, "Passaporte")

            if Keyboard and Keyboard[1] and vRP.Identity(Keyboard[1]) then
                local OtherPassport = Keyboard[1]
                local Identity = vRP.Identity(OtherPassport)
                local FullName = Identity.name.." "..Identity.name2

				local MaxPropertys = MaxPropertysPadrao
				if vRP.HasGroup(Passport,"PremiumPrata") then
					MaxPropertys = MaxPropertys + MaxPropertysPremiumPrata
				elseif vRP.HasGroup(Passport,"PremiumOuro") then
					MaxPropertys = MaxPropertys + MaxPropertysPremiumOuro
				elseif vRP.HasGroup(Passport,"PremiumPlatina") then
					MaxPropertys = MaxPropertys + MaxPropertysPremiumPlatina
				end

                local PropertyCount = vRP.Query("propertys/Count", { Passport = OtherPassport })[1].count or 0
                if PropertyCount >= MaxPropertys then
					TriggerClientEvent("Notify", source, "vermelho", FullName.." ("..OtherPassport..") atingiu o limite máximo de propriedades.", 5000)
                    return
                end

                if vRP.Request(source, "Deseja transferir a propriedade para <b>"..FullName.." ("..OtherPassport..")</b>?") then
                    vRP.Query("propertys/Transfer", { Name = Name, Passport = OtherPassport })
                    TriggerClientEvent("Notify", source, "verde", "Transferência concluída.", 5000)
                end
            end
        end
    end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- PROPERTYS:CREDENTIALS
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("propertys:Credentials")
AddEventHandler("propertys:Credentials",function(Name)
	local source = source
	local Passport = vRP.Passport(source)
	if Passport then
		local Consult = vRP.Query("propertys/Exist",{ name = Name })
		if Consult[1] then
			if parseInt(Consult[1]["Passport"]) == Passport then
				TriggerClientEvent("dynamic:closeSystem",source)

				if vRP.Request(source,"Você escolheu reconfigurar todos os cartões de segurança, lembrando que ao prosseguir todos os cartões vão deixar de funcionar, deseja prosseguir?","Sim, prosseguir","Não, outra hora") then
					local Serial = PropertysSerials()
					vRP.Query("propertys/Credentials",{ name = Name, serial = Serial })
					vRP.GiveItem(Passport,"propertys-"..Serial,Consult[1]["Keys"],true)
				end
			end
		end
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- CLOTHES
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.Clothes()
	local source = source
	local Passport = vRP.Passport(source)
	if Passport then
		local Clothes = {}
		local Consult = vRP.GetSrvData("Wardrobe:"..Passport)

		for Table,_ in pairs(Consult) do
			Clothes[#Clothes + 1] = { ["name"] = Table }
		end

		return Clothes
	end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- PROPERTYS:CLOTHES
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("propertys:Clothes")
AddEventHandler("propertys:Clothes",function(Mode)
	local source = source
	local Passport = vRP.Passport(source)
	if Passport then
		local Split = splitString(Mode,"-")
		local Consult = vRP.GetSrvData("Wardrobe:"..Passport,true)
		local Name = Split[2]

		if Split[1] == "save" then
			local Keyboard = vKEYBOARD.keySingle(source,"Nome")
			if Keyboard then
				local Name = Keyboard[1]
				local NameCheck = sanitizeString(Keyboard[1],"abcdefghijklmnopqrstuvwxyz0123456789",true)

				if not Consult[NameCheck] then
					Consult[NameCheck] = vSKINSHOP.Customization(source)
					vRP.SetSrvData("Wardrobe:"..Passport,Consult,true)
					TriggerClientEvent("propertys:ClothesReset",source)
					TriggerClientEvent("Notify",source,"verde","<b>"..Name.."</b> adicionado.",5000)
				else
					TriggerClientEvent("Notify",source,"amarelo","Nome escolhido já existe em seu armário.",5000)
				end
			end
		elseif Split[1] == "delete" then
			if Consult[Name] then
				Consult[Name] = nil
				vRP.SetSrvData("Wardrobe:"..Passport,Consult,true)
				TriggerClientEvent("propertys:ClothesReset",source)
				TriggerClientEvent("Notify",source,"verde","<b>"..Name.."</b> removido.",5000)
			else
				TriggerClientEvent("Notify",source,"amarelo","A vestimenta salva não se encontra mais em seu armário.",5000)
			end
		elseif Split[1] == "apply" then
			if Consult[Name] then
				TriggerClientEvent("skinshop:Apply",source,Consult[Name])
				TriggerClientEvent("Notify",source,"verde","<b>"..Name.."</b> aplicado.",5000)
			else
				TriggerClientEvent("Notify",source,"amarelo","A vestimenta salva não se encontra mais em seu armário.",5000)
			end
		end
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- PROPERTYSSERIALS
-----------------------------------------------------------------------------------------------------------------------------------------
function PropertysSerials()
	local Serial = vRP.GenerateString("LDLDLDLDLD")
	local Consult = vRP.Query("propertys/Serial",{ serial = Serial })
	if Consult[1] then
		PropertysSerials()
	end

	return Serial
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- OPENCHEST
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.OpenChest(Name, Mode)
    local source = source
    local Passport = vRP.Passport(source)
    if Passport then
        local Chest = {}
        local Inventory = {}
        local Inv = vRP.Inventory(Passport)

        if Name == "Hotel" then
            if Mode == "Vault" then
                Consult = vRP.GetSrvData("Vault:Hotel" .. Passport)
            elseif Mode == "Fridge" then
                Consult = vRP.GetSrvData("Fridge:Hotel" .. Passport)
            end
        else
            Consult = vRP.GetSrvData(Mode .. ":" .. Name)
        end

        for k, v in pairs(Inv) do
            v["amount"] = parseInt(v["amount"])
            v["name"] = itemName(v["item"])
            v["peso"] = itemWeight(v["item"])
            v["index"] = itemIndex(v["item"])
            v["max"] = itemMaxAmount(v["item"])
            v["economy"] = parseFormat(itemEconomy(v["item"]))
            v["desc"] = itemDescription(v["item"])
            v["key"] = v["item"]
            v["slot"] = k

            local Split = splitString(v["item"], "-")
            if Split[2] ~= nil then
                if itemDurability(v["item"]) then
                    v["durability"] = parseInt(os.time() - Split[2])
                    v["days"] = itemDurability(v["item"])
                else
                    v["durability"] = 0
                    v["days"] = 1
                end
            else
                v["durability"] = 0
                v["days"] = 1
            end

            if itemType(Split[1]) == "Armamento" and Split[3] then
                local DonoSerial = Split[3]
                local UserSerial = vRP.UserSerial(DonoSerial)
                if UserSerial then
                    local Identity = vRP.Identity(UserSerial["id"])
                    if Identity and Identity["serial"] then
                        v["desc"] = "<br><description>Serial da Arma: <green>" .. Identity["serial"] .. "</green>.</description>"
                    end
                else
                    v["desc"] = "<br><description>Serial da Arma: <green> Desconhecido </green>.</description>"
                end
            end

            Inventory[k] = v
        end

        for k, v in pairs(Consult) do
            v["amount"] = parseInt(v["amount"])
            v["name"] = itemName(v["item"])
            v["peso"] = itemWeight(v["item"])
            v["index"] = itemIndex(v["item"])
            v["max"] = itemMaxAmount(v["item"])
            v["economy"] = parseFormat(itemEconomy(v["item"]))
            v["desc"] = itemDescription(v["item"])
            v["key"] = v["item"]
            v["slot"] = k

            local Split = splitString(v["item"], "-")
            if Split[2] ~= nil then
                if itemDurability(v["item"]) then
                    v["durability"] = parseInt(os.time() - Split[2])
                    v["days"] = itemDurability(v["item"])
                else
                    v["durability"] = 0
                    v["days"] = 1
                end
            else
                v["durability"] = 0
                v["days"] = 1
            end

            if itemType(Split[1]) == "Armamento" and Split[3] then
                local DonoSerial = Split[3]
                local UserSerial = vRP.UserSerial(DonoSerial)
                if UserSerial then
                    local Identity = vRP.Identity(UserSerial["id"])
                    if Identity and Identity["serial"] then
                        v["desc"] = "<br><description>Serial da Arma: <green>" .. Identity["serial"] .. "</green>.</description>"
                    end
                else
                    v["desc"] = "<br><description>Serial da Arma: <green> Desconhecido </green>.</description>"
                end
            end

            Chest[k] = v
        end

        local Exist = {}
        if Name == "Hotel" then
            if Mode == "Vault" then
                Exist[1] = { ["Vault"] = WeighVaultHotel }
            elseif Mode == "Fridge" then
                Exist[1] = { ["Fridge"] = WeighFridgeHotel }
            end
        else
            Exist = vRP.Query("propertys/Exist", { name = Name })
        end

        if Exist[1] then
            return Inventory, Chest, vRP.InventoryWeight(Passport), vRP.GetWeight(Passport), vRP.ChestWeight(Consult), Exist[1][Mode]
        end
    end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- STORE
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.Store(Item,Slot,Amount,Target,Name,Mode)
	local source = source
	local Amount = parseInt(Amount)
	local Passport = vRP.Passport(source)
	if Passport then
		if Amount <= 0 then Amount = 1 end

		if itemBlock(Item) or (Mode == "Vault" and BlockChest(Item)) or (Mode == "Fridge" and not BlockChest(Item)) then
			TriggerClientEvent("propertys:Update",source)
			return
		end

		if Name == "Hotel" then
			if vRP.StoreChest(Passport,Mode..":Hotel"..Passport,Amount,WeighVaultHotel,Slot,Target) then
				TriggerClientEvent("propertys:Update",source)
				TriggerEvent("Discord","Bau-Hotel","**[Colocou um Item]**\n\n**Passaporte:** "..Passport.."\n**Colocou:** "..Amount.."x "..itemName(Item).."\n**Casa: HOTEL** \n**Data e Hora:** " .. os.date("%d/%m/%Y - %H:%M:%S"),16777215)
			else
				local Result = vRP.GetSrvData(Mode..":Hotel"..Passport)
				local Split = splitString(Name,"-")
				local Names = Split[1]
				vRP.Query("entitydata/SetData",{ dkey = Mode..":Hotel"..Passport, dvalue = json.encode(Result) })
				TriggerClientEvent("propertys:Weight",source,vRP.InventoryWeight(Passport),vRP.GetWeight(Passport),vRP.ChestWeight(Result),WeighVaultHotel)
				TriggerEvent("Discord","Bau-Hotel","**[Colocou um Item]**\n\n**Passaporte:** "..Passport.."\n**Colocou:** "..Amount.."x "..itemName(Item).."\n**Casa: HOTEL** \n**Data e Hora:** " .. os.date("%d/%m/%Y - %H:%M:%S"),16777215)
			end
		else
			local Consult = vRP.Query("propertys/Exist",{ name = Name })
			if Consult[1] then
				if Item == "diagram" then
					if vRP.TakeItem(Passport,Item,Amount,false,Slot) then
						vRP.Query("propertys/"..Mode,{ name = Name, weight = 10 * Amount })
						TriggerClientEvent("propertys:Update",source)
						TriggerEvent("Discord","Bau-Casas","**[Colocou um Item]**\n\n**Passaporte:** "..Passport.."\n**Colocou:** "..Amount.."x "..itemName(Item).."\n**Casa:** "..Name.."\n**Data e Hora:** " .. os.date("%d/%m/%Y - %H:%M:%S"),16777215)
					end
				else
					if vRP.StoreChest(Passport,Mode..":"..Name,Amount,Consult[1][Mode],Slot,Target) then
						TriggerClientEvent("propertys:Update",source)
						TriggerEvent("Discord","Bau-Casas","**[Colocou um Item]**\n\n**Passaporte:** "..Passport.."\n**Colocou:** "..Amount.."x "..itemName(Item).."\n**Casa:** "..Name.."\n**Data e Hora:** " .. os.date("%d/%m/%Y - %H:%M:%S"),16777215)
					else
						local Result = vRP.GetSrvData(Mode..":"..Name)
						TriggerClientEvent("propertys:Weight",source,vRP.InventoryWeight(Passport),vRP.GetWeight(Passport),vRP.ChestWeight(Result),Consult[1][Mode])
						TriggerEvent("Discord","Bau-Casas","**[Colocou um Item]**\n\n**Passaporte:** "..Passport.."\n**Colocou:** "..Amount.."x "..itemName(Item).."\n**Casa:** "..Name.."\n**Data e Hora:** " .. os.date("%d/%m/%Y - %H:%M:%S"),16777215)
					end
				end
			end
		end
	end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- TAKE
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.Take(Item,Slot,Amount,Target,Name,Mode)
	local source = source
	local Amount = parseInt(Amount)
	local Passport = vRP.Passport(source)
	if Passport then
		if Amount <= 0 then Amount = 1 end

		if Name == "Hotel" then
			if vRP.TakeChest(Passport,Mode..":Hotel"..Passport,Amount,Slot,Target) then
				TriggerClientEvent("propertys:Update",source)
				TriggerEvent("Discord","Bau-Hotel","**[Retirou um Item]**\n\n**Passaporte:** "..Passport.."\n**Retirou:** "..Amount.."x "..itemName(Item).."\n**Casa: HOTEL** \n**Data e Hora:** " .. os.date("%d/%m/%Y - %H:%M:%S"),16729391)
			else
				local Result = vRP.GetSrvData(Mode..":Hotel"..Passport)
				local Split = splitString(Name,"-")
				local Names = Split[1]
				vRP.Query("entitydata/SetData",{ dkey = Mode..":Hotel"..Passport, dvalue = json.encode(Result) })
				TriggerClientEvent("propertys:Weight",source,vRP.InventoryWeight(Passport),vRP.GetWeight(Passport),vRP.ChestWeight(Result),WeighVaultHotel)
				TriggerEvent("Discord","Bau-Hotel","**[Retirou um Item]**\n\n**Passaporte:** "..Passport.."\n**Retirou:** "..Amount.."x "..itemName(Item).."\n**Casa: HOTEL** \n**Data e Hora:** " .. os.date("%d/%m/%Y - %H:%M:%S"),16729391)
			end
		else
			if vRP.TakeChest(Passport,Mode..":"..Name,Amount,Slot,Target) then
				TriggerClientEvent("propertys:Update",source)
			else
				local Consult = vRP.Query("propertys/Exist",{ name = Name })
				if Consult[1] then
					local Result = vRP.GetSrvData(Mode..":"..Name)
					TriggerClientEvent("propertys:Weight",source,vRP.InventoryWeight(Passport),vRP.GetWeight(Passport),vRP.ChestWeight(Result),Consult[1][Mode])
					TriggerEvent("Discord","Bau-Casas","**[Retirou um Item]**\n\n**Passaporte:** "..Passport.."\n**Retirou:** "..Amount.."x "..itemName(Item).."\n**Casa:** "..Name.."\n**Data e Hora:** " .. os.date("%d/%m/%Y - %H:%M:%S"),16729391)
				end
			end
		end
	end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- UPDATE
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.Update(Slot,Target,Amount,Name,Mode)
	local source = source
	local Amount = parseInt(Amount)
	local Passport = vRP.Passport(source)
	if Passport then
		if Amount <= 0 then Amount = 1 end
		if Name == "Hotel" then 
			if vRP.UpdateChest(Passport,Mode..":Hotel"..Passport,Slot,Target,Amount) then
				TriggerClientEvent("propertys:Update",source)
			end
		else
			if vRP.UpdateChest(Passport,Mode..":"..Name,Slot,Target,Amount) then
				TriggerClientEvent("propertys:Update",source)
			end
		end
	end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- ROUTE
-----------------------------------------------------------------------------------------------------------------------------------------
function Route(Name)
	local Split = splitString(Name,"ropertys")

	return parseInt(100000 + Split[2])
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- CONNECT
-----------------------------------------------------------------------------------------------------------------------------------------
AddEventHandler("Connect",function(Passport,source)
	TriggerClientEvent("propertys:Table",source,Propertys,Interiors,Markers)
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- DISCONNECT
-----------------------------------------------------------------------------------------------------------------------------------------
AddEventHandler("Disconnect",function(Passport)
	if Inside[Passport] then
		vRP.InsidePropertys(Passport,Propertys[Inside[Passport]])
		Inside[Passport] = nil
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- THREADSTART
-----------------------------------------------------------------------------------------------------------------------------------------
CreateThread(function()
	Wait(1000)
	local Consult = vRP.Query("propertys/All")

	for Index,v in pairs(Consult) do
		Markers[v["Name"]] = true
	end

	TriggerClientEvent("propertys:Table",-1,Propertys,Interiors,Markers)
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- CHARACTERCHOSEN
-----------------------------------------------------------------------------------------------------------------------------------------
AddEventHandler("CharacterChosen",function(Passport,source)
	local Consult = vRP.Query("propertys/AllUser",{ Passport = Passport })
	if Consult[1] then
		local Tables = {}

		for _,v in pairs(Consult) do
			local Name = v["Name"]
			if Propertys[Name] then
				Tables[#Tables + 1] = { ["Coords"] = Propertys[Name] }
			end
		end

		TriggerClientEvent("spawn:Increment",source,Tables)
	end
end)