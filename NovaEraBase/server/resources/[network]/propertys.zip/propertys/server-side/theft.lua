-----------------------------------------------------------------------------------------------------------------------------------------
-- VARIABLES
-----------------------------------------------------------------------------------------------------------------------------------------
local actived = {}
local homeLock = {}
local homeEnter = {}
local homeBlips = {}
local Newspapers = {}
local routeHomes = {}
local theftTimers = {}
local homeInterior = {}
local myHomeList = {}
-----------------------------------------------------------------------------------------------------------------------------------------
-- NEARESTHOMES
-----------------------------------------------------------------------------------------------------------------------------------------
function nearestHomes(source)
	local ped = GetPlayerPed(source)
	local coords = GetEntityCoords(ped)

	for k,v in pairs(homes) do
		local distance = #(coords - vec3(v[1],v[2],v[3]))
		if distance <= 1.5 then
			return k
		end
	end

	return false
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- PROPERTYS:INVADESYSTEM
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("propertys:invadePoliceEvent")
AddEventHandler("propertys:invadePoliceEvent",function()
    local source = source
    local Passport = vRP.Passport(source)
    local Robbery = false

    local TheftName = nearestHomes(source)
    if not TheftName then
        TriggerClientEvent("Notify",source,"vermelho","Você não está em uma propriedade.",5000)
        return
    end

    for _,home in pairs(homeEnter) do
        if home == TheftName then
            Robbery = true
            break
        end
    end

    if not Robbery then
        TriggerClientEvent("Notify",source,"amarelo","Essa casa não está sendo roubada.",5000)
        return
    end

    exports["propertys"]:enterHomes(source,Passport,TheftName,false)
    TriggerClientEvent("propertys:invadePolice",source)
    TriggerClientEvent("Notify",source,"verde","Você invadiu a propriedade.",5000)
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- SETNETWORK
-----------------------------------------------------------------------------------------------------------------------------------------
function setNetwork(source,Passport,TheftName,status)
	homeEnter[Passport] = TheftName

	SetPlayerRoutingBucket(source,routeHomes[TheftName])
	TriggerClientEvent("update:Route",source,routeHomes[TheftName])

	vCLIENT.entranceHomes(source,TheftName,homes[TheftName],homeInterior[TheftName],status)
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- REMOVENETWORK
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.removeNetwork(TheftName)
	local source = source
	local Passport = vRP.Passport(source)
	if Passport then
		if homeEnter[Passport] then
			homeEnter[Passport] = nil
		end

		TriggerClientEvent("update:Route",source,0)
		SetPlayerRoutingBucket(source,0)
	end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- PAYMENTTHEFT
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.paymentTheft(mobile)
	local source = source
	local Passport = vRP.Passport(source)
	if Passport then
		local policeResult = vRP.NumPermission("Policia")
		local randItem = math.random(#mobileTheft[mobile])
		local value = math.random(mobileTheft[mobile][randItem]["min"],mobileTheft[mobile][randItem]["max"])

		if (vRP.InventoryWeight(Passport) + (itemWeight(mobileTheft[mobile][randItem]["item"]) * parseInt(value))) <= vRP.GetWeight(Passport) then
			if parseInt(#policeResult) <= 1 then
				if math.random(100) <= 50 then
					vRP.GenerateItem(Passport,mobileTheft[mobile][randItem]["item"],parseInt(value),true)
					TriggerClientEvent("player:applyGsr",source)
				else
					TriggerClientEvent("Notify",source,"amarelo","Compartimento vazio.",5000)
				end
			else
				if math.random(100) <= 95 then
					vRP.GenerateItem(Passport,mobileTheft[mobile][randItem]["item"],parseInt(value),true)
					TriggerClientEvent("player:applyGsr",source)
				else
					TriggerClientEvent("Notify",source,"amarelo","Compartimento vazio.",5000)
				end
			end
		else
			TriggerClientEvent("Notify",source,"vermelho","Mochila cheia.",5000)
		end

		vRP.UpgradeStress(Passport, math.random(2,5))

		if math.random(1000) >= 950 then
			TriggerEvent("Wanted",source,Passport,120)
			TriggerClientEvent("propertys:UpdateCalled",source)
			TriggerClientEvent("sounds:source",source,"alarm",1.0)

			local ped = GetPlayerPed(source)
			local coords = GetEntityCoords(ped)

			for k,v in pairs(policeResult) do
				async(function()
					TriggerClientEvent("NotifyPush",v,{ code = 90, title = "Roubo de Propriedade", x = coords["x"], y = coords["y"], z = coords["z"], criminal = "Alarme de segurança", time = "Recebido às "..os.date("%H:%M"), blipColor = 43 })
				end)
			end
		end
	end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- CALLPOLICE
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.callPolice(disX,disY,disZ)
	local source = source
	local Passport = vRP.Passport(source)
	if Passport then
		TriggerClientEvent("sounds:source",source,"alarm",1.0)

		local ped = GetPlayerPed(source)

		local policeResult = vRP.NumPermission("Policia")
		for k,v in pairs(policeResult) do
			async(function()
				TriggerClientEvent("NotifyPush",v,{ code = 90, title = "Roubo de Propriedade", x = disX, y = disY, z = disZ, criminal = "Alarme de segurança", time = "Recebido às "..os.date("%H:%M"), blipColor = 43 })
			end)
		end
	end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- HOMESTHEFT
-----------------------------------------------------------------------------------------------------------------------------------------
exports("homesTheft",function(source)
	local ped = GetPlayerPed(source)
	local coords = GetEntityCoords(ped)

	for TheftName,v in pairs(homes) do
		local distance = #(coords - vector3(v[1],v[2],v[3]))
		if distance <= 1.5 then
			if theftTimers[TheftName] then
				if os.time() >= theftTimers[TheftName] then
					theftTimers[TheftName] = os.time() + 18000
					return TheftName
				else
					local homeTimers = parseInt(theftTimers[TheftName] - os.time())
					TriggerClientEvent("Notify",source,"azul","Aguarde <b>"..parseFormat(homeTimers).." segundos</b>.",5000)
					return false
				end
			else
				theftTimers[TheftName] = os.time() + 18000
				return TheftName
			end
		end
	end

	return false
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- ENTERHOMES
-----------------------------------------------------------------------------------------------------------------------------------------
exports("enterHomes",function(source,Passport,TheftName,status)
	if homeInterior[TheftName] == nil then
		homeInterior[TheftName] = infoInterior[math.random(#infoInterior - 1)]["interior"]
	end

	setNetwork(source,Passport,TheftName,status)
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- RESETTHEFT
-----------------------------------------------------------------------------------------------------------------------------------------
exports("resetTheft",function(TheftName)
	theftTimers[TheftName] = nil
end)