-----------------------------------------------------------------------------------------------------------------------------------------
-- VRP
-----------------------------------------------------------------------------------------------------------------------------------------
local Tunnel = module("vrp","lib/Tunnel")
local Proxy = module("vrp","lib/Proxy")
vRPC = Tunnel.getInterface("vRP")
vRP = Proxy.getInterface("vRP")
-----------------------------------------------------------------------------------------------------------------------------------------
-- CONNECTION
-----------------------------------------------------------------------------------------------------------------------------------------
vSERVER = Tunnel.getInterface("crafting")
-----------------------------------------------------------------------------------------------------------------------------------------
-- VARIABLES
-----------------------------------------------------------------------------------------------------------------------------------------
local Timer = 0
local Select = ""
-----------------------------------------------------------------------------------------------------------------------------------------
-- CRAFTING
-----------------------------------------------------------------------------------------------------------------------------------------
local Crafting = {
	-- Framework
	["1"] = { vec3(713.66,-961.04,30.4),"Dress" },
	["2"] = { vec3(-382.72,261.91,86.36),"Food" },
	["3"] = { vec3(1991.28,3724.65,34.83),"Food" },
	["4"] = { vec3(82.45,-1553.26,29.59),"Lixeiro" },
	["5"] = { vec3(287.36,2843.6,44.7),"Lixeiro" },
	["6"] = { vec3(-413.68,6171.99,31.48),"Lixeiro" },
	["7"] = { vec3(466.3,-735.75,27.36),"Mining" },
	["8"] = { vec3(725.74,-1070.59,28.46),"Money" },
	["9"] = { vec3(1272.26,-1712.57,54.76),"Lester" },
	-- Favelas
	["10"] = { vec3(1278.03,70.49,101.05),"Maonegra" },
	["11"] = { vec3(-2232.02,-170.08,91.44),"Bairro13" },
	["12"] = { vec3(896.52,1988.22,84.77),"Setor13" },
	["13"] = { vec3(1365.82,-212.1,158.15),"Grota" },
	["14"] = { vec3(1853.66,-2244.88,171.75),"Chernobyl" },
	["15"] = { vec3(2318.0,2636.56,61.62),"Crips" },
	["16"] = { vec3(1899.1,2.14,188.89),"Distrito" },
	["17"] = { vec3(2058.69,6484.49,113.79),"Dz7" },
	["18"] = { vec3(2223.74,3957.28,40.37),"Labirinto" },
	["19"] = { vec3(1969.52,422.31,178.78),"P77" },
	["20"] = { vec3(-2400.4,2619.37,27.57),"Favela6" },
	["21"] = { vec3(1558.63,1465.03,114.49),"Milicia" },
	["22"] = { vec3(2244.65,3559.3,68.78),"Medellín" },
	["23"] = { vec3(2357.29,482.68,202.5),"Mare" },
	["24"] = { vec3(619.97,2565.71,73.36),"Crateva" }
}
-----------------------------------------------------------------------------------------------------------------------------------------
-- THREADSTART
-----------------------------------------------------------------------------------------------------------------------------------------
CreateThread(function()
    for Number, v in pairs(Crafting) do
        local craftingName = "Crafting:" .. Number
        local isLixeiroCrafting = (Number == "4" or Number == "5" or Number == "6")

        local options = {
            {
                event = "crafting:Open",
                label = "Abrir",
                tunnel = "shop"
            }
        }

        if isLixeiroCrafting then
            table.insert(options, {
                event = "works:Lixeiro",
                label = "Traje Lixeiro",
                tunnel = "server"
            })
        end

        exports["target"]:AddCircleZone(craftingName, v[1], 2.0, {
            name = craftingName,
            heading = 3374176
        }, {
            shop = Number,
            Distance = 1.0,
            options = options
        })
    end
end)

-----------------------------------------------------------------------------------------------------------------------------------------
-- CRAFTING:OPEN
-----------------------------------------------------------------------------------------------------------------------------------------
AddEventHandler("crafting:Open", function(Number)
	local v = Crafting[Number]
	if v then
		if vSERVER.Permission(v[2]) and vSERVER.Verify() then
			if v[2] ~= Select and GetGameTimer() < Timer then
				TriggerEvent("Notify", "amarelo", "Produção em andamento.", 5000)
			else
				Select = v[2]
				SetNuiFocus(true, true)
				SendNUIMessage({ action = "OpenCraft", data = vSERVER.Request(Select) })
				vRP.playAnim(false,{"amb@prop_human_parking_meter@female@idle_a","idle_a_female"},true)
			end
		end
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- CLOSE
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNUICallback("Close",function(Data,Callback)
	SetNuiFocus(false,false)
	vRP.Destroy()

	Callback("Ok")
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- OWNED
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNUICallback("Owned",function(Data,Callback)
	Callback(vSERVER.Owned(Data["id"],Data["key"]))
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- CRAFTING
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNUICallback("Crafting",function(Data,Callback)
	if GetGameTimer() >= Timer then
		Timer = GetGameTimer() + Data["time"] * 1000

		SetTimeout(Data["time"] * 1000,function()
			vSERVER.Crafting(Data["id"],Data["key"],Data["amount"])
		end)

		Callback(true)
	else
		TriggerEvent("Notify","amarelo","Produção em andamento.",5000)
		Callback(false)
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- CRAFTING:INVENTORY
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("crafting:Inventory")
AddEventHandler("crafting:Inventory",function()
	if "Inventory" ~= Select and GetGameTimer() < Timer then
		TriggerEvent("Notify","amarelo","Produção em andamento.",5000)
		return
	end

	Select = "Barragem"
	SetNuiFocus(true,true)
	SendNUIMessage({ action = "OpenCraft", data = vSERVER.Request("Barragem") })
end)

-----------------------------------------------------------------------------------------------------------------------------------------
-- CRAFTING:PHARMACY
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("crafting:Pharmacy")
AddEventHandler("crafting:Pharmacy", function()
	SetNuiFocus(true, true)
	SendNUIMessage({ action = "OpenCraft", data = vSERVER.Request("Barragem") })
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- CRAFTING:MINERMAN
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("crafting:Minerman")
AddEventHandler("crafting:Minerman", function()
	SetNuiFocus(true, true)
	SendNUIMessage({ action = "showNUI", name = "Mining" })
end)