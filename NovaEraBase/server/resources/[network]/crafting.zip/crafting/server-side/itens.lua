-----------------------------------------------------------------------------------------------------------------------------------------
-- LIST
-----------------------------------------------------------------------------------------------------------------------------------------
List = {
	-- Framework
	["Dress"] = {
		["List"] = {
			["backpack"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["fabric"] = 25
				}
			},
			["fabric"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 3,
				["require"] = {
					["animalpelt"] = 4,
					["rubber"] = 3
				}
			},
			["sewingkit"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 3,
				["require"] = {
					["rubber"] = 35,
					["plastic"] = 35
				}
			},
		}
	},
	["Lester"] = {
		["List"] = {
			["blocksignal"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["aluminum"] = 3,
					["tarp"] = 1,
					["plastic"] = 6
				}
			},
			["c4"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["aluminum"] = 6,
					["copper"] = 6,
					["plastic"] = 4,
					["glass"] = 4,
					["rubber"] = 5
				}
			},
			["dismantle"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 5,
				["require"] = {
					["dollarsroll"] = 1200
				}
			},
			["credential"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 5,
				["require"] = {
					["dollarsz"] = 250
				}
			},
			["lockpick"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 5,
				["require"] = {
					["copper"] = 5,
					["aluminum"] = 5,
					["plastic"] = 4
				}
			},
			["vpn"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 5,
				["require"] = {
					["dollarsroll"] = 500
				}
			},
			["dollars"] = {
				["amount"] = 1000,   --- AQUI E O QUE VAI VIM QUANDO LAVAR 2000
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 10,
				["require"] = {
					["dollarsroll"] = 2000    --- Aqui e quanto e o minimo de LAVAR
				}
			}
		}
	},
	["Pharmacy"] = {
		["List"] = {
			["gauze"] = {
				["amount"] = 1,
				["destroy"] = false,
				["time"] = 15,
				["require"] = {
					["cotton"] = 2,
					["alcohol"] = 1,
					["plaster"] = 1,
					["silk"] = 1
				}
			}
		}
	},
	["Inventory"] = {
		["List"] = {
			["gauze"] = {
				["amount"] = 1,
				["destroy"] = false,
				["time"] = 15,
				["require"] = {
					["cotton"] = 2,
					["alcohol"] = 1,
					["plaster"] = 1,
					["silk"] = 1
				}
			}
		}
	},
	["Food"] = {
		["List"] = {
			["hamburger2"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 10,
				["require"] = {
					["meat"] = 1,
					["bread"] = 2,
					["ketchup"] = 1
				}
			},
			["hamburger3"] = {
				["amount"] = 3,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 10,
				["require"] = {
					["meatB"] = 1,
					["bread"] = 2,
					["ketchup"] = 1
				}
			},
			["orangejuice"] = {
				["amount"] = 3,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 10,
				["require"] = {
					["water"] = 1,
					["orange"] = 9
				}
			},
			["tangejuice"] = {
				["amount"] = 3,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 10,
				["require"] = {
					["water"] = 1,
					["tange"] = 9
				}
			},
		}
	},
	["Lixeiro"] = {
		["List"] = {
			["aluminum"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 0,
				["require"] = {
					["recyclable"] = 6
				}
			},
			["rubber"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 0,
				["require"] = {
					["recyclable"] = 4
				}
			},
			["sheetmetal"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 0,
				["require"] = {
					["recyclable"] = 25
				}
			},
			["copper"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 0,
				["require"] = {
					["recyclable"] = 6
				}
			},
			["techtrash"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 0,
				["require"] = {
					["recyclable"] = 30
				}
			},
			["tarp"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 0,
				["require"] = {
					["recyclable"] = 35
				}
			},
			["roadsigns"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 0,
				["require"] = {
					["recyclable"] = 25
				}
			},
			["plastic"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 0,
				["require"] = {
					["recyclable"] = 4
				}
			},
			["glass"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 0,
				["require"] = {
					["recyclable"] = 4
				}
			},
			["fabric"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 0,
				["require"] = {
					["recyclable"] = 35
				}
			}
		}
	},
	["Mining"] = {
		["List"] = {
			["lead_pure"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 2,
				["require"] = {
					["lead_ore"] = 1
				}
			},
			["copper_pure"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 2,
				["require"] = {
					["copper_ore"] = 1
				}
			},
			["tin_pure"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 2,
				["require"] = {
					["tin_ore"] = 1
				}
			},
			["iron_pure"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 2,
				["require"] = {
					["iron_ore"] = 1
				}
			},
			["gold_pure"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 2,
				["require"] = {
					["gold_ore"] = 1
				}
			},
			["diamond_pure"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 2,
				["require"] = {
					["diamond_ore"] = 1
				}
			},
			["sulfur_pure"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 2,
				["require"] = {
					["sulfur_ore"] = 1
				}
			},
			["emerald_pure"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 2,
				["require"] = {
					["emerald_ore"] = 1
				}
			},
			["ruby_pure"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 2,
				["require"] = {
					["ruby_ore"] = 1
				}
			},
			["sapphire_pure"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 2,
				["require"] = {
					["sapphire_ore"] = 1
				}
			}
		}
	},
	["Money"] = {
		["List"] = {
			["dollars"] = {
				["amount"] = 1300,   --- AQUI E O QUE VAI VIM QUANDO LAVAR 2000
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 0,
				["require"] = {
					["dollarsroll"] = 2000    --- Aqui e quanto e o minimo de LAVAR
				}
			}
		}
	},
	-- Restaurants
	["Pearls"] = {
		["perm"] = "Pearls",
		["List"] = {
			["hamburger4"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 10,
				["require"] = {
					["meat"] = 1,
					["bread"] = 2,
					["ketchup"] = 1
				}
			},
			["hamburger5"] = {
				["amount"] = 3,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 10,
				["require"] = {
					["meatB"] = 1,
					["bread"] = 2,
					["ketchup"] = 1
				}
			},
			["hamburger3"] = {
				["amount"] = 3,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 10,
				["require"] = {
					["meatC"] = 1,
					["bread"] = 2,
					["ketchup"] = 1
				}
			},
			["hamburger2"] = {
				["amount"] = 3,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 10,
				["require"] = {
					["meatS"] = 1,
					["bread"] = 2,
					["ketchup"] = 1
				}
			},
			["grapejuice"] = {
				["amount"] = 3,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 10,
				["require"] = {
					["water"] = 1,
					["grape"] = 9
				}
			},
			["strawberryjuice"] = {
				["amount"] = 3,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 10,
				["require"] = {
					["water"] = 1,
					["strawberry"] = 9
				}
			},
			["bananajuice"] = {
				["amount"] = 3,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 10,
				["require"] = {
					["water"] = 1,
					["banana"] = 9
				}
			},
			["passionjuice"] = {
				["amount"] = 3,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 10,
				["require"] = {
					["water"] = 1,
					["passion"] = 9
				}
			}
		}
	},
	["Maonegra"] = {
		["perm"] = "Maonegra",
		["List"] = {
			["smgbody"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["aluminum"] = 75,
					["copper"] = 75,
					["plastic"] = 30,
					--["glass"] = 30,
					--["rubber"] = 25
				}
			},
			["pistolbody"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["aluminum"] = 75,
					["copper"] = 75,
					["plastic"] = 30,
					--["glass"] = 30,
					--["rubber"] = 25
				}
			},
			["riflebody"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["aluminum"] = 75,
					["copper"] = 75,
					["plastic"] = 30,
					--["glass"] = 30,
					--["rubber"] = 25
				}
			},
			["WEAPON_PISTOL"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["pistolbody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_MACHINEPISTOL"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["smgbody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_MICROSMG"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["smgbody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_REVOLVER"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["pistolbody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_PUMPSHOTGUN_MK2"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["smgbody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_SAWNOFFSHOTGUN"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["smgbody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_GUSENBERG"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["riflebody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_SNSPISTOL"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["pistolbody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_PISTOL50"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["pistolbody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_MINISMG"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["smgbody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_PISTOL_MK2"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["pistolbody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_SNSPISTOL_MK2"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["pistolbody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_VINTAGEPISTOL"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["pistolbody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_COMPACTRIFLE"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["riflebody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_ADVANCEDRIFLE"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["riflebody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_FNFAL"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["riflebody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_FNSCAR"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["riflebody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_BULLPUPRIFLE_MK2"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["riflebody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_SPECIALCARBINE"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["riflebody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_SPECIALCARBINE_MK2"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["riflebody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_ASSAULTRIFLE"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["riflebody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_ASSAULTRIFLE_MK2"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["riflebody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_ASSAULTSMG"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["smgbody"] = 1,
					["aluminum"] = 30
				}
			}
		}
	},
	["Bairro13"] = {
		["perm"] = "Bairro13",
		["List"] = {
			["smgbody"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["aluminum"] = 75,
					["copper"] = 75,
					["plastic"] = 30,
					["glass"] = 30,
					["rubber"] = 25
				}
			},
			["pistolbody"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["aluminum"] = 75,
					["copper"] = 75,
					["plastic"] = 30,
					["glass"] = 30,
					["rubber"] = 25
				}
			},
			["riflebody"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["aluminum"] = 75,
					["copper"] = 75,
					["plastic"] = 30,
					["glass"] = 30,
					["rubber"] = 25
				}
			},
			["WEAPON_PISTOL"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["pistolbody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_MACHINEPISTOL"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["smgbody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_MICROSMG"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["smgbody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_REVOLVER"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["pistolbody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_PUMPSHOTGUN_MK2"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["smgbody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_SAWNOFFSHOTGUN"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["smgbody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_GUSENBERG"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["riflebody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_SNSPISTOL"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["pistolbody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_PISTOL50"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["pistolbody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_MINISMG"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["smgbody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_PISTOL_MK2"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["pistolbody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_SNSPISTOL_MK2"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["pistolbody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_VINTAGEPISTOL"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["pistolbody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_COMPACTRIFLE"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["riflebody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_ADVANCEDRIFLE"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["riflebody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_FNFAL"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["riflebody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_FNSCAR"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["riflebody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_BULLPUPRIFLE_MK2"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["riflebody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_SPECIALCARBINE"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["riflebody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_SPECIALCARBINE_MK2"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["riflebody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_ASSAULTRIFLE"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["riflebody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_ASSAULTRIFLE_MK2"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["riflebody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_ASSAULTSMG"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["smgbody"] = 1,
					["aluminum"] = 30
				}
			}
		}
	},
	["Setor13"] = {
		["perm"] = "Setor13",
		["List"] = {
			["smgbody"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["aluminum"] = 75,
					["copper"] = 75,
					["plastic"] = 30,
					["glass"] = 30,
					["rubber"] = 25
				}
			},
			["pistolbody"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["aluminum"] = 75,
					["copper"] = 75,
					["plastic"] = 30,
					["glass"] = 30,
					["rubber"] = 25
				}
			},
			["riflebody"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["aluminum"] = 75,
					["copper"] = 75,
					["plastic"] = 30,
					["glass"] = 30,
					["rubber"] = 25
				}
			},
			["WEAPON_PISTOL"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["pistolbody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_MACHINEPISTOL"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["smgbody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_MICROSMG"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["smgbody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_REVOLVER"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["pistolbody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_PUMPSHOTGUN_MK2"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["smgbody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_SAWNOFFSHOTGUN"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["smgbody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_GUSENBERG"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["riflebody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_SNSPISTOL"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["pistolbody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_PISTOL50"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["pistolbody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_MINISMG"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["smgbody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_PISTOL_MK2"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["pistolbody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_SNSPISTOL_MK2"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["pistolbody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_VINTAGEPISTOL"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["pistolbody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_COMPACTRIFLE"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["riflebody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_ADVANCEDRIFLE"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["riflebody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_FNFAL"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["riflebody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_FNSCAR"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["riflebody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_BULLPUPRIFLE_MK2"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["riflebody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_SPECIALCARBINE"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["riflebody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_SPECIALCARBINE_MK2"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["riflebody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_ASSAULTRIFLE"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["riflebody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_ASSAULTRIFLE_MK2"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["riflebody"] = 1,
					["aluminum"] = 30
				}
			},
			["WEAPON_ASSAULTSMG"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["smgbody"] = 1,
					["aluminum"] = 30
				}
			}
		}
	},
	["Grota"] = {
		["perm"] = "Grota",
		["List"] = {
			["WEAPON_PISTOL_AMMO"] = {
				["amount"] = 10,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 0,
				["require"] = {
					["lead_pure"] = 2,
					["copper_pure"] = 2,
					["gunpowder"] = 1
				}
			},
			["WEAPON_SMG_AMMO"] = {
				["amount"] = 10,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 0,
				["require"] = {
					["lead_pure"] = 2,
					["copper_pure"] = 2,
					["gunpowder"] = 2
				}
			},
			["WEAPON_RIFLE_AMMO"] = {
				["amount"] = 10,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 0,
				["require"] = {
					["lead_pure"] = 2,
					["copper_pure"] = 2,
					["gunpowder"] = 3
				}
			},
			["WEAPON_SHOTGUN_AMMO"] = {
				["amount"] = 10,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 0,
				["require"] = {
					["lead_pure"] = 3,
					["copper_pure"] = 3,
					["gunpowder"] = 5
				}
			}
		}
	},
	["Chernobyl"] = {
		["perm"] = "Chernobyl",
		["List"] = {
			["WEAPON_PISTOL_AMMO"] = {
				["amount"] = 10,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 0,
				["require"] = {
					["lead_pure"] = 2,
					["copper_pure"] = 2,
					["gunpowder"] = 1
				}
			},
			["WEAPON_SMG_AMMO"] = {
				["amount"] = 10,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 0,
				["require"] = {
					["lead_pure"] = 2,
					["copper_pure"] = 2,
					["gunpowder"] = 2
				}
			},
			["WEAPON_RIFLE_AMMO"] = {
				["amount"] = 10,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 0,
				["require"] = {
					["lead_pure"] = 2,
					["copper_pure"] = 2,
					["gunpowder"] = 3
				}
			},
			["WEAPON_SHOTGUN_AMMO"] = {
				["amount"] = 10,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 0,
				["require"] = {
					["lead_pure"] = 3,
					["copper_pure"] = 3,
					["gunpowder"] = 5
				}
			}
		}
	},
	["Crips"] = {
		["perm"] = "Crips",
		["List"] = {
			["WEAPON_PISTOL_AMMO"] = {
				["amount"] = 10,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 0,
				["require"] = {
					["lead_pure"] = 2,
					["copper_pure"] = 2,
					["gunpowder"] = 1
				}
			},
			["WEAPON_SMG_AMMO"] = {
				["amount"] = 10,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 0,
				["require"] = {
					["lead_pure"] = 2,
					["copper_pure"] = 2,
					["gunpowder"] = 2
				}
			},
			["WEAPON_RIFLE_AMMO"] = {
				["amount"] = 10,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 0,
				["require"] = {
					["lead_pure"] = 2,
					["copper_pure"] = 2,
					["gunpowder"] = 3
				}
			},
			["WEAPON_SHOTGUN_AMMO"] = {
				["amount"] = 10,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 0,
				["require"] = {
					["lead_pure"] = 3,
					["copper_pure"] = 3,
					["gunpowder"] = 5
				}
			}
		}
	},
	["Distrito"] = {
		["perm"] = "Distrito",
		["List"] = {
			["cocaine"] = {
				["amount"] = 3,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 10,
				["require"] = {
					["cokebud"] = 3,
					["ziplock"] = 1
				}
			},
			["crack"] = {
				["amount"] = 3,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 10,
				["require"] = {
					["acetone"] = 3,
					["bottle"] = 1
				}
			},
			["heroin"] = {
				["amount"] = 3,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 2,
				["require"] = {
					["solvent"] = 1,
					["vinegar"] = 1
				}
			},
			["joint"] = {
				["amount"] = 3,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 10,
				["require"] = {
					["weedbud"] = 3,
					["silk"] = 1
				}
			},
			["lean"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["codeine"] = 3,
					["alcohol"] = 2
				}
			},
			["metadone"] = {
				["amount"] = 2,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 3,
				["require"] = {
					["pill"] = 2,
					["alcohol"] = 1
				}
			},
			["meth"] = {
				["amount"] = 3,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 10,
				["require"] = {
					["amphetamine"] = 3,
					["ziplock"] = 1
				}
			},
			["oxy"] = {
				["amount"] = 2,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 3,
				["require"] = {
					["pill"] = 2,
					["jar"] = 1
				}
			},		
			["lancaperfume"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 2,
				["require"] = {
					["alcohol"] = 1,
					["fragrance"] = 1
				}
			}
		}
	},	
	["Dz7"] = {
		["perm"] = "Dz7",
		["List"] = {
			["cocaine"] = {
				["amount"] = 3,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 10,
				["require"] = {
					["cokebud"] = 3,
					["ziplock"] = 1
				}
			},
			["crack"] = {
				["amount"] = 3,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 10,
				["require"] = {
					["acetone"] = 3,
					["bottle"] = 1
				}
			},
			["heroin"] = {
				["amount"] = 3,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 2,
				["require"] = {
					["solvent"] = 1,
					["vinegar"] = 1
				}
			},
			["joint"] = {
				["amount"] = 3,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 10,
				["require"] = {
					["weedbud"] = 3,
					["silk"] = 1
				}
			},
			["lean"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["codeine"] = 3,
					["alcohol"] = 2
				}
			},
			["metadone"] = {
				["amount"] = 2,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 3,
				["require"] = {
					["pill"] = 2,
					["alcohol"] = 1
				}
			},
			["meth"] = {
				["amount"] = 3,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 10,
				["require"] = {
					["amphetamine"] = 3,
					["ziplock"] = 1
				}
			},
			["oxy"] = {
				["amount"] = 2,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 3,
				["require"] = {
					["pill"] = 2,
					["jar"] = 1
				}
			},		
			["lancaperfume"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 2,
				["require"] = {
					["alcohol"] = 1,
					["fragrance"] = 1
				}
			}
		}
	},
	["Labirinto"] = {
		["perm"] = "Labirinto",
		["List"] = {
			["cocaine"] = {
				["amount"] = 3,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 10,
				["require"] = {
					["cokebud"] = 3,
					["ziplock"] = 1
				}
			},
			["crack"] = {
				["amount"] = 3,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 10,
				["require"] = {
					["acetone"] = 3,
					["bottle"] = 1
				}
			},
			["heroin"] = {
				["amount"] = 3,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 2,
				["require"] = {
					["solvent"] = 1,
					["vinegar"] = 1
				}
			},
			["joint"] = {
				["amount"] = 3,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 10,
				["require"] = {
					["weedbud"] = 3,
					["silk"] = 1
				}
			},
			["lean"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 15,
				["require"] = {
					["codeine"] = 3,
					["alcohol"] = 2
				}
			},
			["metadone"] = {
				["amount"] = 2,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 3,
				["require"] = {
					["pill"] = 2,
					["alcohol"] = 1
				}
			},
			["meth"] = {
				["amount"] = 3,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 10,
				["require"] = {
					["amphetamine"] = 3,
					["ziplock"] = 1
				}
			},
			["oxy"] = {
				["amount"] = 2,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 3,
				["require"] = {
					["pill"] = 2,
					["jar"] = 1
				}
			},		
			["lancaperfume"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 2,
				["require"] = {
					["alcohol"] = 1,
					["fragrance"] = 1
				}
			}
		}
	},
	["P77"] = {
		["perm"] = "P77",
		["List"] = {
			["macarico"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 30,
				["require"] = {
					["aluminum"] = 10,
					["sheetmetal"] = 5
				}
			}
		}
	},
	["Favela6"] = {
		["perm"] = "Favela6",
		["List"] = {
			["macarico"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 30,
				["require"] = {
					["aluminum"] = 10,
					["sheetmetal"] = 5
				}
			}
		}
	},
	["Milicia"] = {
		["perm"] = "Milicia",
		["List"] = {
			["c4"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 2,
				["require"] = {
					["plastic"] = 8,
					["techtrash"] = 4,
					["explosives"] = 1
				}
			},
			["handcuff"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 2,
				["require"] = {
					["aluminum"] = 15,
					["iron_pure"] = 6
				}
			},
			["credential"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 10,
				["require"] = {
					["dollarsroll"] = 500
				}
			},
			["vest"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 2,
				["require"] = {
					["fabric"] = 3,
					["sheetmetal"] = 3
				}
			},
			["hood"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 2,
				["require"] = {
					["fabric"] = 6,
					["tarp"] = 3
				}
			},
			["attachsFlashlight"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 2,
				["require"] = {
					["tin_pure"] = 4,
					["glass"] = 4,
					["plastic"] = 4
				}
			},
			["attachsCrosshair"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 2,
				["require"] = {
					["tin_pure"] = 4,
					["glass"] = 4,
					["plastic"] = 4
				}
			},
			["attachsSilencer"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 2,
				["require"] = {
					["tin_pure"] = 4,
					["glass"] = 4,
					["plastic"] = 4
				}
			},
			["attachsMagazine"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 2,
				["require"] = {
					["tin_pure"] = 4,
					["glass"] = 4,
					["plastic"] = 4
				}
			},
			["attachsGrip"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 2,
				["require"] = {
					["tin_pure"] = 4,
					["glass"] = 4,
					["plastic"] = 4
				}
			}
		}
	},
	["Medellín"] = {
		["perm"] = "Medellín",
		["List"] = {
			["c4"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 2,
				["require"] = {
					["plastic"] = 8,
					["techtrash"] = 4,
					["explosives"] = 1
				}
			},
			["handcuff"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 2,
				["require"] = {
					["aluminum"] = 15,
					["iron_pure"] = 6
				}
			},
			["credential"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 10,
				["require"] = {
					["dollarsroll"] = 500
				}
			},
			["vest"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 2,
				["require"] = {
					["fabric"] = 3,
					["sheetmetal"] = 3
				}
			},
			["hood"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 2,
				["require"] = {
					["fabric"] = 6,
					["tarp"] = 3
				}
			},
			["attachsFlashlight"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 2,
				["require"] = {
					["tin_pure"] = 4,
					["glass"] = 4,
					["plastic"] = 4
				}
			},
			["attachsCrosshair"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 2,
				["require"] = {
					["tin_pure"] = 4,
					["glass"] = 4,
					["plastic"] = 4
				}
			},
			["attachsSilencer"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 2,
				["require"] = {
					["tin_pure"] = 4,
					["glass"] = 4,
					["plastic"] = 4
				}
			},
			["attachsMagazine"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 2,
				["require"] = {
					["tin_pure"] = 4,
					["glass"] = 4,
					["plastic"] = 4
				}
			},
			["attachsGrip"] = {
				["amount"] = 1,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 2,
				["require"] = {
					["tin_pure"] = 4,
					["glass"] = 4,
					["plastic"] = 4
				}
			}
		}
	},
	["Mare"] = {
		["perm"] = "Mare",
		["List"] = {
			["dollars"] = {
				["amount"] = 1000,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 2,
				["require"] = {
					["dollarsroll"] = 2000,
					["veja"] = 10
				}
			}
		}
	},
	["Crateva"] = {
		["perm"] = "Crateva",
		["List"] = {
			["dollars"] = {
				["amount"] = 1000,
				["destroy"] = false,
				["craftable"] = true,
				["time"] = 2,
				["require"] = {
					["dollarsroll"] = 2000,
					["veja"] = 10
				}
			}
		}
	}
}