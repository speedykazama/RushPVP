local isFarming = false
local currentOrg = nil
local totalItemsCollected = 0 -- Contador local

-----------------------------------------------------------------------------------------------------------------------------------------
-- FUNÇÃO VISUAL: BARRA MODERNA VERMELHA
-----------------------------------------------------------------------------------------------------------------------------------------
function DrawModernBar(percent, totalItems)
    -- Configurações de Posição e Tamanho
    local x = 0.5
    local y = 0.94 -- Posição (Fundo do ecrã)
    local width = 0.22 -- Largura da barra
    local height = 0.012 -- Altura (Mais fina para ser moderna)
    
    -- 1. Fundo da Barra (Container Preto Translúcido)
    -- Desenhamos um retângulo ligeiramente maior para fazer de "borda"
    DrawRect(x, y, width + 0.004, height + 0.008, 10, 10, 10, 200)

    -- 2. Fundo do Progresso (Cinzento Escuro/Vermelho muito escuro)
    DrawRect(x, y, width, height, 40, 0, 0, 150)

    -- 3. Barra de Progresso (VERMELHO VIBRANTE)
    local progressWidth = width * percent
    -- Cálculo matemático para a barra crescer da esquerda para a direita
    local positionX = x - (width / 2) + (progressWidth / 2)
    
    -- Cor: R, G, B, Alpha (255, 20, 20 é um vermelho forte)
    DrawRect(positionX, y, progressWidth, height, 220, 20, 20, 255)

    -- 4. Texto: Percentagem (Em cima da barra)
    SetTextFont(4)
    SetTextScale(0.32, 0.32)
    SetTextColour(255, 255, 255, 255)
    SetTextOutline()
    SetTextCentre(true)
    SetTextEntry("STRING")
    AddTextComponentString("PROGRESSO: " .. math.floor(percent * 100) .. "%")
    DrawText(x, y - 0.035) -- Um pouco acima da barra

    -- 5. Texto: Itens Recolhidos (Abaixo da barra)
    SetTextFont(4)
    SetTextScale(0.28, 0.28)
    SetTextColour(200, 200, 200, 255) -- Cinzento claro
    SetTextOutline()
    SetTextCentre(true)
    SetTextEntry("STRING")
    -- O "~r~" mete o número a vermelho para combinar
    AddTextComponentString("Itens na Mochila: ~r~" .. totalItems)
    DrawText(x, y + 0.015) 
end

-----------------------------------------------------------------------------------------------------------------------------------------
-- THREAD PRINCIPAL (DETEÇÃO E TECLAS)
-----------------------------------------------------------------------------------------------------------------------------------------
CreateThread(function()
    while true do
        local ped = PlayerPedId()
        local coords = GetEntityCoords(ped)
        local sleep = 1000

        for org, v in pairs(Config.Farms) do
            local distance = #(coords - v.coords)
            
            if distance < 3.0 then
                sleep = 0
                
                -- Texto 3D flutuante
                if not isFarming then
                    DrawText3D(v.coords, "~r~[E] ~w~INICIAR FARM")
                else
                    DrawText3D(v.coords, "~r~[E] ~w~PARAR FARM")
                end

                if IsControlJustPressed(0, 38) then -- Tecla E
                    if not isFarming then
                        TriggerServerEvent("farm:tryStart", org)
                    else
                        TriggerEvent("farm:cancel")
                        TriggerServerEvent("farm:cancel")
                        TriggerEvent("Notify", "aviso", "Cancelaste o farm.")
                    end
                end
            end
        end
        Wait(sleep)
    end
end)

-- Cancelamento global F6
CreateThread(function()
    while true do
        Wait(0)
        if isFarming and IsControlJustPressed(0, 167) then 
            TriggerEvent("farm:cancel")
            TriggerServerEvent("farm:cancel")
            TriggerEvent("Notify", "aviso", "Farm cancelado via F6.")
        end
    end
end)

-- Atualiza o contador de itens (Vem do Servidor)
RegisterNetEvent("farm:updateStats")
AddEventHandler("farm:updateStats", function(amount)
    totalItemsCollected = amount
end)

-- Início do farm
RegisterNetEvent("farm:start")
AddEventHandler("farm:start", function(org, initialItems)
    isFarming = true
    currentOrg = org
    totalItemsCollected = initialItems or 0

    local ped = PlayerPedId()
    ClearPedTasks(ped)

    RequestAnimDict("mini@repair")
    while not HasAnimDictLoaded("mini@repair") do Wait(10) end
    TaskPlayAnim(ped, "mini@repair", "fixing_a_ped", 8.0, -8.0, -1, 1, 0, false, false, false)

    TriggerEvent("Notify", "sucesso", "Farm iniciado: " .. org)

    -- LOOP VISUAL E LÓGICO
    CreateThread(function()
        local timeTotal = Config.startTime * 60 * 1000 -- Tempo total em ms
        local timeLeft = 0 -- Tempo decorrido

        while isFarming do
            Wait(0) -- Loop rápido para animação suave

            -- Calcula progresso baseado no FPS
            timeLeft = timeLeft + (GetFrameTime() * 1000) 
            local percent = timeLeft / timeTotal

            if percent > 1.0 then percent = 1.0 end
            
            -- Desenha a Barra Vermelha Moderna
            DrawModernBar(percent, totalItemsCollected)

            -- Verifica se o tempo acabou (para entregar)
            if timeLeft >= timeTotal then
                timeLeft = 0 -- Reseta a barra visual
                TriggerServerEvent("farm:finish") -- Pede recompensa (o server decide se dá ou não)
                
                -- Mantém a animação
                if not IsEntityPlayingAnim(PlayerPedId(), "mini@repair", "fixing_a_ped", 3) then
                    TaskPlayAnim(PlayerPedId(), "mini@repair", "fixing_a_ped", 8.0, -8.0, -1, 1, 0, false, false, false)
                end
            end

            local coords = GetEntityCoords(PlayerPedId())
            if #(coords - Config.Farms[org].coords) > 5.0 then
                TriggerEvent("farm:cancel")
                TriggerServerEvent("farm:cancel")
                TriggerEvent("Notify", "aviso", "Saíste da área de farm.")
                return
            end
        end
    end)
end)

-- Cancelamento
RegisterNetEvent("farm:cancel")
AddEventHandler("farm:cancel", function()
    isFarming = false
    totalItemsCollected = 0
    ClearPedTasks(PlayerPedId())
end)

-- Função Texto 3D Simples e Limpa
function DrawText3D(coords, text)
    local onScreen, _x, _y = World3dToScreen2d(coords.x, coords.y, coords.z)
    if onScreen then
        SetTextScale(0.35, 0.35)
        SetTextFont(4)
        SetTextProportional(1)
        SetTextColour(255, 255, 255, 215)
        SetTextEntry("STRING")
        SetTextCentre(1)
        AddTextComponentString(text)
        DrawText(_x, _y)
    end
end