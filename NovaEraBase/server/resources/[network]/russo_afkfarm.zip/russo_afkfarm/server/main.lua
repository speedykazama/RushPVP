-- Webhook de SEGURANÇA (Caso esqueças de meter na config, manda para aqui)
local GlobalWebhook = "https://discord.com/api/webhooks/1454889563054149704/251wvyFjs3vDDZDap-K1dO01UkIuohtGgk_HnB9XdQ8rkId9b4Q49EAvhnv7IcIOuHss" 

local Tunnel = module("vrp","lib/Tunnel")
local Proxy = module("vrp","lib/Proxy")
vRP = Proxy.getInterface("vRP")

local activeFarms = {}

function SendWebhookMessage(url, title, message, color)
    local finalURL = (url ~= nil and url ~= "") and url or GlobalWebhook
    if finalURL == "" or finalURL == "COLOCA_UM_WEBHOOK_GERAL_AQUI" then return end
    
    local embed = {
        {
            ["color"] = color,
            ["title"] = "**" .. title .. "**",
            ["description"] = message,
            ["footer"] = {
                ["text"] = "Farm Log • " .. os.date("%d/%m/%Y %H:%M:%S"),
            },
        }
    }
    
    PerformHttpRequest(finalURL, function(err, text, headers) end, 'POST', json.encode({username = "Farm System", embeds = embed}), { ['Content-Type'] = 'application/json' })
end

-----------------------------------------------------------------------------------------------------------------------------------------
-- 1. VERIFICAÇÃO DE PESO
-----------------------------------------------------------------------------------------------------------------------------------------
function CheckWeight(Passport, org)
    local config = Config.Farms[org]
    if not config or not config.itens then return false end

    local pesoAdicional = 0.0

    for item, amount in pairs(config.itens) do
        local w = vRP.ItemWeight(item) or 0
        pesoAdicional = pesoAdicional + (w * amount)
    end

    if (vRP.InventoryWeight(Passport) + pesoAdicional) <= vRP.GetWeight(Passport) then
        return true
    else
        return false
    end
end

-----------------------------------------------------------------------------------------------------------------------------------------
-- 2. VERIFICAR PERMISSÃO E ABRIR MENU
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("farm:checkPermsAndOpen")
AddEventHandler("farm:checkPermsAndOpen", function(org)
    local src = source
    local Passport = vRP.Passport(src)
    if not Passport then return end

    local farmConfig = Config.Farms[org]
    if not farmConfig then return end

    local groupToCheck = farmConfig.perm
    if not groupToCheck or groupToCheck == "" then groupToCheck = org end

    local hasPerm = false
    if vRP.HasGroup(Passport, groupToCheck) then hasPerm = true
    elseif vRP.HasPermission(Passport, groupToCheck) then hasPerm = true end

    if hasPerm then
        TriggerClientEvent("farm:openMenuAllowed", src, org)
    else
        TriggerClientEvent("Notify", src, "negado", "Não pertences à organização: " .. groupToCheck, 5000)
    end
end)

-----------------------------------------------------------------------------------------------------------------------------------------
-- 3. INICIAR FARM (LOGS SEPARADAS)
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("farm:tryStart")
AddEventHandler("farm:tryStart", function(org)
    local src = source
    local Passport = vRP.Passport(src)
    if not Passport then return end

    -- Carrega config para pegar o webhook
    local farmConfig = Config.Farms[org]

    -- Verifica Peso
    if not CheckWeight(Passport, org) then
        TriggerClientEvent("Notify", src, "vermelho", "Mochila cheia.", 5000)
        return
    end

    local tempoMs = Config.startTime * 60 * 1000

    activeFarms[Passport] = {
        org = org,
        startTime = os.time(),
        nextReward = GetGameTimer() + tempoMs,
        totalCollected = 0
    }

    TriggerClientEvent("farm:start", src, org, Config.startTime)
    
    -- LOG DINÂMICA: Usa o webhook da org, se não tiver usa nil (e a função usa o Global)
    SendWebhookMessage(farmConfig.webhook, "Farm Iniciado", "O jogador **" .. Passport .. "** iniciou farm na: **" .. org .. "**", 3447003)
end)

-----------------------------------------------------------------------------------------------------------------------------------------
-- 4. FINALIZAR E DAR ITENS (LOGS SEPARADAS)
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("farm:finish")
AddEventHandler("farm:finish", function()
    local src = source
    local Passport = vRP.Passport(src)
    if not Passport then return end

    local farmData = activeFarms[Passport]
    if not farmData then return end

    -- Anti-Dupe
    local currentTime = GetGameTimer()
    if currentTime < farmData.nextReward then return end

    activeFarms[Passport].nextReward = currentTime + (Config.startTime * 60 * 1000)

    local org = farmData.org
    local config = Config.Farms[org] -- Carrega config para pegar o webhook
    
    -- Verifica Peso
    if not CheckWeight(Passport, org) then
        activeFarms[Passport] = nil
        TriggerClientEvent("farm:cancel", src)
        TriggerClientEvent("Notify", src, "vermelho", "Mochila cheia.", 5000)
        
        SendWebhookMessage(config.webhook, "Farm Parou (Peso)", "O jogador **" .. Passport .. "** parou (Mochila Cheia).", 15105570)
        return
    end

    -- Dá Itens
    local itensLog = ""
    local totalAmount = 0

    for item, amount in pairs(config.itens) do
        vRP.GenerateItem(Passport, item, amount, true)
        itensLog = itensLog .. amount .. "x " .. item .. ", "
        totalAmount = totalAmount + amount
    end

    activeFarms[Passport].totalCollected = activeFarms[Passport].totalCollected + totalAmount
    TriggerClientEvent("farm:updateStats", src, activeFarms[Passport].totalCollected)

    TriggerClientEvent("Notify", src, "sucesso", "Recebeste materiais.", 5000)
    
    -- LOG DINÂMICA
    SendWebhookMessage(config.webhook, "Farm Recompensa", "O jogador **" .. Passport .. "** recebeu: " .. itensLog .. "\nOrg: **" .. org .. "**", 3066993)
end)

-----------------------------------------------------------------------------------------------------------------------------------------
-- 5. CANCELAR (LOGS SEPARADAS)
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("farm:cancel")
AddEventHandler("farm:cancel", function(reason)
    local src = source
    local Passport = vRP.Passport(src)

    if activeFarms[Passport] then
        local org = activeFarms[Passport].org
        local total = activeFarms[Passport].totalCollected
        
        -- Preciso ir buscar o webhook à config usando o nome da org
        local webhook = nil
        if Config.Farms[org] then webhook = Config.Farms[org].webhook end

        activeFarms[Passport] = nil
        TriggerClientEvent("farm:cancel", src)
        
        if vRP.upgradeHunger then vRP.upgradeHunger(Passport, 20) end
        if vRP.upgradeThirst then vRP.upgradeThirst(Passport, 20) end
        
        -- LOG DINÂMICA
        SendWebhookMessage(webhook, "Farm Cancelado", "O jogador **" .. Passport .. "** parou de farmar na **" .. org .. "**.\nItens totais: " .. total, 15158332)
    end
end)

AddEventHandler("playerDropped", function()
    local src = source
    local Passport = vRP.Passport(src)
    if activeFarms[Passport] then
        local org = activeFarms[Passport].org
        local webhook = nil
        if Config.Farms[org] then webhook = Config.Farms[org].webhook end

        SendWebhookMessage(webhook, "Farm Desconectou", "O jogador **" .. Passport .. "** saiu do servidor a farmar.", 10038562)
        activeFarms[Passport] = nil
    end
end)