local Tools = module("vrp", "lib/Tools")
local idgens = Tools.newIDGenerator()

local activeFarms = {}

RegisterServerEvent("farm:tryStart")
AddEventHandler("farm:tryStart", function(org)
    local src = source
    local user_id = vRP.getUserId(src)

    if not user_id or not Config.Farms[org] then return end

    -- Removido: verificação de grupo
    -- Qualquer jogador pode iniciar o farm

    if activeFarms[user_id] then
        TriggerClientEvent("farm:cancel", src)
        return
    end

    activeFarms[user_id] = {
        org = org,
        coords = Config.Farms[org].coords
    }

    TriggerClientEvent("farm:start", src, org, Config.startTime)
end)

RegisterServerEvent("farm:finish")
AddEventHandler("farm:finish", function()
    local src = source
    local user_id = vRP.getUserId(src)

    if not user_id then return end

    local farmData = activeFarms[user_id]
    if not farmData then
        print("[FARM DEBUG] Nenhum dado de farm encontrado para o jogador: " .. tostring(user_id))
        return
    end

    local org = farmData.org
    local config = Config.Farms[org]

    if not config or not config.itens then
        print("[FARM DEBUG] Configuração ou itens não encontrados para org: " .. tostring(org))
        return
    end

    print("[FARM DEBUG] Entregando itens para: " .. user_id .. " na org: " .. org)
    for item, qtd in pairs(config.itens) do
        print("[FARM DEBUG] Item: " .. item .. " x" .. tostring(qtd))
        vRP.giveInventoryItem(user_id, item, qtd, true)
    end

    TriggerClientEvent("Notify", src, "sucesso", "Farm finalizada com sucesso!")
end)

RegisterServerEvent("farm:cancel")
AddEventHandler("farm:cancel", function()
    local src = source
    local user_id = vRP.getUserId(src)
    if user_id then
        activeFarms[user_id] = nil
        TriggerClientEvent("farm:cancel", src)
        TriggerClientEvent("status:updateHunger", src, 100)
        TriggerClientEvent("status:updateThirst", src, 100)
    end
end)
