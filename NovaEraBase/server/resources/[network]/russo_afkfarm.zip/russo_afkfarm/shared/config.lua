Config = {
    startTime = 0.1, -- em minuto(s) tempo inicial

    Farms = {

        ['Maonegra'] = {
            coords = vec3(-222.35,-997.7,1482.26),
            webhook = "https://discord.com/api/webhooks/1454874436154167377/mHtjK5W7a4NzMHiLsFvUJ85sXQUkQJ-79qJI6SQSxHV8SR95JKa5cPrLEZ74NTI-eUUK",
            itens = {
                ['syringe'] = 1
            }
        }

        --['MECANICA'] = {
            --coords = vec3(-633.03,-2388.0,13.93),
            --webhook = "https://discord.com/api/webhooks/LINK_DA_MAONEGRA",
            --itens = {
                --['plastico'] = 10,
                --['metal'] = 10,
                --['c-cobre'] = 10
            --}
        --}

    }
}
