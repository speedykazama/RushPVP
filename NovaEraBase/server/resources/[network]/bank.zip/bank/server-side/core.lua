-----------------------------------------------------------------------------------------------------------------------------------------
-- VRP
-----------------------------------------------------------------------------------------------------------------------------------------
local Tunnel = module("vrp","lib/Tunnel")
local Proxy = module("vrp","lib/Proxy")
vRP = Proxy.getInterface("vRP")
-----------------------------------------------------------------------------------------------------------------------------------------
-- CONNECTION
-----------------------------------------------------------------------------------------------------------------------------------------
Creative = {}
Tunnel.bindInterface("bank",Creative)
vKEYBOARD = Tunnel.getInterface("keyboard")
-----------------------------------------------------------------------------------------------------------------------------------------
-- VARIABLES
-----------------------------------------------------------------------------------------------------------------------------------------
local Active = {}
local yield = 0
-----------------------------------------------------------------------------------------------------------------------------------------
-- THREAD
-----------------------------------------------------------------------------------------------------------------------------------------
CreateThread(function()
    local Next = GetGameTimer()
    while true do
        if os.time() >= Next then
            Next = os.time() + 3600
            vRP.Query("investments/Actives")
        end
        Wait(10 * 1000)
    end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- HOME
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.Home()
	local source = source
	local Passport = vRP.Passport(source)
	if Passport then
		local Passport = vRP.Passport(source)
		local Consult = vRP.Query("investments/Check", {Passport = Passport})

		if Consult[1] then
			yield = Consult[1].Monthly
		end

		local cardnumber = "7822 1352 4522 " .. 1000 + Passport
		local balance = vRP.Identity(Passport).bank
		local transactions = Transactions(Passport)
		local cardlimit = vRP.Identity(Passport).cardlimit
		local spending = vRP.Identity(Passport).spending

		return {
			Passport = Passport,
			yield = yield,
			cardnumber = cardnumber,
			balance = balance,
			transactions = transactions,
			cardlimit = cardlimit,
			spending = spending
		}
	end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- TRANSACTIONS
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.TransactionHistory()
    local source = source
    local Passport = vRP.Passport(source)
    if Passport then
        return Transactions(Passport, 50)
    end
    return false
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- BANKDEPOSIT
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.Deposit(Amount)
    local source = source
    local Passport = vRP.Passport(source)
    if Passport and nil == Active[Passport] and parseInt(Amount) > 0 then
        Active[Passport] = true
        if vRP.ConsultItem(Passport, "dollars", Amount) and vRP.TakeItem(Passport, "dollars", Amount) then
            vRP.GiveBank(Passport, Amount)
            TriggerEvent("Discord","BankDeposito","**[Depósito de dinheiro no Banco]**\n\n**ID:** "..Passport.."\n**Depositou:** $"..parseInt(Amount).." \n**Data e Hora:** " .. os.date("%d/%m/%Y - %H:%M:%S"),16777215)
        end
        Active[Passport] = nil
        return {
            transactions = Transactions(Passport),
            balance = vRP.Identity(Passport).bank
        }
    end
    return false
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- BANWITHDRAW
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.Withdraw(Amount)
    local source = source
    local Passport = vRP.Passport(source)
    if Passport and nil == Active[Passport] and parseInt(Amount) > 0 then
        Active[Passport] = true
            vRP.WithdrawCash(Passport, Amount)
            TriggerEvent("Discord","BankSaque","**[Saque de dinheiro no Banco]**\n\n**ID:** "..Passport.."\n**Sacou:** $"..parseInt(Amount).." \n**Data e Hora:** " .. os.date("%d/%m/%Y - %H:%M:%S"),16777215)
            Active[Passport] = nil
        return {
            transactions = Transactions(Passport),
            balance = vRP.Identity(Passport).bank
        }
    end
    return false
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- TRANSFERENCE
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.Transfer(OtherPassport, Amount)
    local source = source
    local Passport = vRP.Passport(source)
    if Passport and nil == Active[Passport] and parseInt(Amount) > 0 then
        Active[Passport] = true
        if vRP.Identity(OtherPassport) and vRP.PaymentBank(Passport, Amount) then
            vRP.GiveBank(OtherPassport, Amount)
        end
        Active[Passport] = nil
        return {
            transactions = Transactions(Passport),
            balance = vRP.Identity(Passport).bank
        }
    end
    return false
end
----------------------------------------------------------------------------------------------------------------------------------------
-- TRANSACTION
-----------------------------------------------------------------------------------------------------------------------------------------
function Transactions(Passport, Limit)
	local Passport = Passport
	local transactions = {}
	if not Limit then
		Limit = 4
	end
	local result = vRP.Query('transactions/List',{ Passport = Passport, Limit = Limit })
	if result[1] then
		for i, transaction in pairs(result) do
		    local type = transaction.Type
			local date = transaction.Date
			local value = transaction.Value
			local balance = transaction.Balance
			transactions[#transactions + 1] = {
				type = type,
				date = date,
				value = value,
				balance = balance
			}
		end
	end
	return transactions
end
----------------------------------------------------------------------------------------------------------------------------------------
-- FINES
-----------------------------------------------------------------------------------------------------------------------------------------
function Fines(Passport)
	local Passport = Passport
	local fines = {}
	local result = vRP.Query('fines/List',{ Passport = Passport })
	if result[1] then
		for i, row in pairs(result) do
			if row.Value > 0 then
				fines[i] = {
					id = row.id,
					name = row.Name,
					value = row.Value,
					date = row.Date,
					hour = row.Hour,
					message = row.Message
				}
			else
				vRP.Query("fines/Remove",{ Passport = row.Passport ,id = row.id})
			end
		end
	end
	return fines
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- FINELIST
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.FineList()
    local source = source
    local Passport = vRP.Passport(source)
    if Passport then
        return Fines(Passport)
    end
    return false
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- TRANSFERENCE
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.FinePayment(id)
    local source = source
    local Passport = vRP.Passport(source)
    if Passport and nil == Active[Passport] then
        Active[Passport] = true
        local Consult = vRP.Query("fines/Check", { id = id, Passport = Passport })
        if Consult[1] then
            if vRP.PaymentBank(Passport, Consult[1].Value) then
                vRP.Query("fines/Remove", { id = id, Passport = Passport })
                vRP.RemoveFine(Passport, Consult[1].Value)
                Active[Passport] = nil
                return true
            else
                TriggerClientEvent("Notify", source, "vermelho", "<b>Dólares</b> insuficientes.", 5000)
            end
        end
        Active[Passport] = nil
    end
    return false
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- TRANSFERENCE
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.FinePaymentAll()
    local source = source
    local Passport = vRP.Passport(source)
    if Passport and nil == Active[Passport] then
        Active[Passport] = true
        local Consult = vRP.Query("fines/List", { Passport = Passport })
        for _, k in pairs(Consult) do
            if vRP.PaymentBank(Passport, k.Value) then
                vRP.Query("fines/Remove", { id = k.id, Passport = Passport })
                vRP.RemoveFine(Passport, k.Value)
                Active[Passport] = nil
            end
        end
        Active[Passport] = nil
        return true
    end
    return Fines(Passport)
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- TRANSFERENCE
-----------------------------------------------------------------------------------------------------------------------------------------
function Taxs(Passport)
	local Passport = Passport
	local taxs = {}
	local result = vRP.Query('taxs/List',{ Passport = Passport })
	if result[1] then
		for i, tax in pairs(result) do
			taxs[i] = {
				id = tax.id,
				name = tax.Name,
				value = tax.Value,
				date = tax.Date,
				hour = tax.Hour,
				message = tax.Message
			}
		end
	end
	return taxs
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- TAXLIST
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.TaxList()
    local source = source
    local Passport = vRP.Passport(source)
    if Passport then
        return Taxs(Passport)
    end
    return false
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- TAXPAYMENT
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.TaxPayment(id)
    local source = source
    local Passport = vRP.Passport(source)
    if Passport and nil == Active[Passport] then
        Active[Passport] = true
        local Consult = vRP.Query("taxs/Check", { id = id, Passport = Passport })
        if Consult[1] and vRP.PaymentBank(Passport, Consult[1].Value) then
            vRP.RemoveTax(Passport, Consult[1].Value)
            vRP.Query("taxs/Remove", { id = id, Passport = Passport })
            Active[Passport] = nil
            return true
        end
        Active[Passport] = nil
    end
    return false
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVOICES
-----------------------------------------------------------------------------------------------------------------------------------------
function Invoices(Passport)
	local Passport = Passport
	local invoices = {}

	local result = vRP.Query('invoices/List',{ Passport = Passport })
	if result[1] then
		for i, invoice in pairs(result) do
			if not invoices[invoice.Type] then
				invoices[invoice.Type] = {}
			end
			local id = invoice.id
			local reason = invoice.Reason
			local holder = invoice.Holder
			invoices[invoice.Type][#invoices[invoice.Type] + 1] = {id = id, reason = reason, holder = holder, value = invoice.Value}
		end
	end
	return invoices
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVOICELIST
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.InvoiceList()
	local source = source
	local Passport = vRP.Passport(source)
	if Passport then
		return Invoices(Passport)
	end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVOICEPAYMENT
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.InvoicePayment(id)
    local source = source
    local Passport = vRP.Passport(source)

    Active[Passport] = true

    local result = vRP.Query("invoices/Check",{ Passport = Passport, id = id })
    if not result[1] then
        Active[Passport] = nil
        return false
    end

    local Amount = parseInt(result[1].Value)
    local Identity = vRP.Identity(Passport)

    if result[1].Reason == "Cartão de Crédito" then
        if vRP.PaymentBank(Passport, Amount) then
            vRP.Query("invoices/Remove",{ Passport = Passport, id = id })

            vRP.DowngradeSpending(Passport, Amount)
            vRP.UpgradeCardlimit(Passport, Identity.cardlimit + Amount)

            Active[Passport] = nil
            return true
        end
    else
        if vRP.PaymentBank(Passport, Amount) then
            vRP.Query("invoices/Remove",{ Passport = Passport, id = id })
            vRP.GiveBank(result[1].Received, Amount)

            Active[Passport] = nil
            return true
        end
    end

    Active[Passport] = nil
    return false
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- MAKEVOICE
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.MakeInvoice(OtherPassport, value, reason)
    local source = source
    local Passport = vRP.Passport(source)
    local Target = OtherPassport

    if Passport and not Active[Passport] and parseInt(value) > 0 then
        Active[Passport] = true

        local ClosestPed = vRP.Source(Target)
        if ClosestPed then
            if vRP.Request(ClosestPed,"<b>" .. vRP.Identity(Passport).name .. " " .. vRP.Identity(Passport).name2 .."</b> lhe enviou uma fatura de <b>R$" .. parseFormat(value) .."</b>, deseja aceita-la?","Sim, aceito", "Não, obrigado") then

                local Reason = reason
                local Holder = vRP.Identity(Passport).name .. " " .. vRP.Identity(Passport).name2
                local Value = parseInt(value)

                vRP.Query('invoices/Add', {Passport = Target,Received = Passport,Type = "received",Reason = Reason,Holder = Holder,Value = Value})

                vRP.Query('invoices/Add', {Passport = Passport,Received = Target,Type = "sent",Reason = Reason,Holder = "Você",Value = Value})

                Active[Passport] = nil
                return Invoices(Passport)
            end
        end

        Active[Passport] = nil
    end

    return false
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVESTMENTS
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.Investments()
    local source = source
    local Passport = vRP.Passport(source)
    if Passport then
        local Consult = vRP.Query("investments/Check", { Passport = Passport })
        if Consult[1] then
            return {
                total = Consult[1].Monthly + Consult[1].Liquid,
                brute = Consult[1].Monthly,
                liquid = Consult[1].Liquid,
                deposit = Consult[1].Deposit
            }
        end
        return {
            deposit = 0,
            liquid = 0,
            brute = 0,
            total = 0
        }
    end
    return true
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVEST
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.Invest(Amount)
    local source = source
    local Passport = vRP.Passport(source)
    if Passport and not Active[Passport] and parseInt(Amount) > 0 then
        Active[Passport] = true
        if vRP.PaymentBank(Passport, Amount) then
            if vRP.Query("investments/Check", { Passport = Passport })[1] then
                vRP.Query("investments/Invest", { Value = Amount, Passport = Passport })
            else
                vRP.Query("investments/Add", { Deposit = Amount, Passport = Passport })
            end
            Active[Passport] = nil
            return true
        end
        Active[Passport] = nil
    end
    return false
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- INVESTRESCUE
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.InvestRescue()
    local source = source
    local Passport = vRP.Passport(source)
    if Passport and not Active[Passport] then
        Active[Passport] = true
        local Consult = vRP.Query("investments/Check", { Passport = Passport })
        if Consult[1] then
            vRP.Query("investments/Remove", { Passport = Passport })
            vRP.GiveBank(Passport, Consult[1].Deposit + Consult[1].Liquid)
        end
        Active[Passport] = nil
    end
    return false
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- BANK:CREDITCARD
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("Bank:CreditCard")
AddEventHandler("Bank:CreditCard", function()
    local source = source
    local Passport = vRP.Passport(source)
    if Passport then
		local Identity = vRP.Identity(Passport)
		if Identity["cardlimit"] == 0 and Identity["spending"] == 0 then
			if vRP.Request(source,"Você tem interesse em solicitar um Cartão de Crédito?") then
				vRP.UpgradeCardlimit(Passport,2000)
				vRP.GiveItem(Passport,"creditcard-" .. Passport,1,true)
			end
		else
			if vRP.Request(source,"Você gostaria de solicitar uma segunda via do seu Cartão de Crédito? Isso terá um custo de <b>R$"..parseFormat(500).."</b>.") then
				if vRP.PaymentFull(Passport, 500, "Banco") then
					vRP.GiveItem(Passport,"creditcard-" .. Passport,1,true)
				end
			end
		end
        return
    end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- BANK:DEBITCARD
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("Bank:DebitCard")
AddEventHandler("Bank:DebitCard", function()
    local source = source
    local Passport = vRP.Passport(source)
	if Passport then
		local Identity = vRP.Identity(Passport)
		if Identity["cardpassword"] == 0 then
			if vRP.Request(source,"Você tem interesse em solicitar um Cartão de Débito?") then
				local Keyboard = vKEYBOARD.keyWord(source,"Senha: (4 Dígitos)")
				if Keyboard then
					if vRP.SetCardPassword(Passport, Keyboard[1]) then
						vRP.GiveItem(Passport,"debitcard-" .. Passport,1,true)
					end
				end
			end
		else
			if vRP.Request(source,"Você gostaria de alterar a senha do seu Cartão de Débito?") then
				local Keyboard = vKEYBOARD.keyWord(source,"Senha: (4 Dígitos)")
				if Keyboard then
					if vRP.SetCardPassword(Passport, Keyboard[1]) then
						TriggerClientEvent("Notify",source,"verde"," Sua senha foi alterada com sucesso!",5000) 
					end
				end
			else
				if vRP.Request(source,"Você gostaria de solicitar uma segunda via do seu Cartão de Débito? Isso terá um custo de <b>R$"..parseFormat(500).."</b>.") then
					if vRP.PaymentFull(Passport, 500, "Banco") then
						vRP.GiveItem(Passport,"debitcard-" .. Passport,1,true)
					end
				end
			end
		end
        return
    end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- BANK:UPGRADELIMIT
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("Bank:UpgradeLimit")
AddEventHandler("Bank:UpgradeLimit", function()
    local source = source
    local Passport = vRP.Passport(source)
    local Identity = vRP.Identity(Passport)
    local currentLimit = Identity["cardlimit"] or 0

    local Keyboard = vKEYBOARD.keySingle(source,"Quanto deseja aumentar de limite?")
    
    if not Keyboard or not Keyboard[1] then
        TriggerClientEvent("Notify", source, "vermelho", "Operação cancelada.", 5000)
        return
    end

    local amount = parseInt(Keyboard[1])
    if amount <= 0 then
        TriggerClientEvent("Notify", source, "vermelho", "Valor inválido.", 5000)
        return
    end

    local price = math.floor(amount * 0.5)

    if vRP.Request(source,"Deseja aumentar o limite do seu cartão em <b>R$"..parseFormat(amount).."</b>?<br><br>Custo: <b>R$"..parseFormat(price).."</b>") then
        if vRP.PaymentBank(Passport, price, "Banco") then
            vRP.UpgradeCardlimit(Passport, currentLimit + amount)
            TriggerClientEvent("Notify",source,"verde","Limite do cartão aumentado para <b>R$"..parseFormat(currentLimit + amount).."</b>.",5000)
        else
            TriggerClientEvent("Notify", source, "vermelho", "Saldo insuficiente.", 5000)
        end
    end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- ADDTRANSACTIONS
-----------------------------------------------------------------------------------------------------------------------------------------
exports("AddTransactions", function(Passport, Type, Value)
    local Identity = vRP.Identity(Passport)
    if Identity and Identity.bank then
        vRP.Query("transactions/Add", {
            Balance = Identity.bank,
            Value = Value,
            Date = os.date("%d/%m/%Y"),
            Type = Type,
            Passport = Passport
        })
    end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- ADDTAXS
-----------------------------------------------------------------------------------------------------------------------------------------
exports("AddTaxs", function(Passport, Name, Value, Message)
    if vRP.Identity(Passport) then
        vRP.Query("taxs/Add", {
            Message = Message,
            Value = Value,
            Hour = os.date("%H:%M"),
            Date = os.date("%d/%m/%Y"),
            Name = Name,
            Passport = Passport
        })
    end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- ADDTAXS
-----------------------------------------------------------------------------------------------------------------------------------------
exports("AddFines", function(Passport, OtherPassport, Value, Message)
    if vRP.Identity(Passport) then
        vRP.Query("fines/Add", {
            Message = Message,
            Value = Value,
            Hour = os.date("%H:%M"),
            Date = os.date("%d/%m/%Y"),
            Name = vRP.FullName(OtherPassport),
            Passport = OtherPassport
        })
    end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- DISCONNECT
-----------------------------------------------------------------------------------------------------------------------------------------
AddEventHandler("Disconnect", function(Passport)
	if Active[Passport] then
	  Active[Passport] = nil
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- EXPORTS
-----------------------------------------------------------------------------------------------------------------------------------------
exports("Taxs", Taxs)
exports("Fines", Fines)
exports("Invoices", Invoices)
exports("Transactions", Transactions)