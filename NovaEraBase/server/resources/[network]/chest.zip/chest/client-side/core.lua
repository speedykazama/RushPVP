-----------------------------------------------------------------------------------------------------------------------------------------
-- VRP
-----------------------------------------------------------------------------------------------------------------------------------------
local Tunnel = module("vrp","lib/Tunnel")
local Proxy = module("vrp","lib/Proxy")
vRP = Proxy.getInterface("vRP")
-----------------------------------------------------------------------------------------------------------------------------------------
-- CONNECTION
-----------------------------------------------------------------------------------------------------------------------------------------
vSERVER = Tunnel.getInterface("chest")
-----------------------------------------------------------------------------------------------------------------------------------------
-- CHESTS
-----------------------------------------------------------------------------------------------------------------------------------------
local Chests = {
	-- Emergency
	{ ["Name"] = "Paramedic", ["Coords"] = vec3(1135.32,-1540.49,35.38), ["Mode"] = "2" },
	{ ["Name"] = "Bombeiro", ["Coords"] = vec3(-1152.31,-1713.17,8.58), ["Mode"] = "2" },
	-- Mechanic
	{ ["Name"] = "Mechanic", ["Coords"] = vec3(886.24,-2097.4,34.88), ["Mode"] = "5" },
	{ ["Name"] = "Mechanic2", ["Coords"] = vec3(2737.85,3503.71,55.25), ["Mode"] = "5" },
	-- Police
	{ ["Name"] = "PMERJ", ["Coords"] = vec3(1301.98,-764.22,65.66), ["Mode"] = "1" },
	{ ["Name"] = "PCERJ", ["Coords"] = vec3(-304.64,-1043.74,27.21), ["Mode"] = "1" },
	{ ["Name"] = "PRF", ["Coords"] = vec3(2607.09,5363.49,46.71), ["Mode"] = "1" },
	{ ["Name"] = "BOPE", ["Coords"] = vec3(2520.14,-325.6,101.89), ["Mode"] = "1" },
	{ ["Name"] = "RECOM", ["Coords"] = vec3(-1724.5,-750.32,12.17), ["Mode"] = "1" },
	{ ["Name"] = "BPCHQ", ["Coords"] = vec3(-813.73,-2672.34,14.2), ["Mode"] = "1" },
	{ ["Name"] = "EX", ["Coords"] = vec3(3928.22,-5030.62,6.64), ["Mode"] = "1" },
	-- Favelas
	{ ["Name"] = "Maonegra", ["Coords"] = vec3(1279.48,72.39,98.12), ["Mode"] = "5" },
	{ ["Name"] = "Bairro13", ["Coords"] = vec3(-2231.02,-168.36,91.44), ["Mode"] = "5" },
	{ ["Name"] = "Setor13", ["Coords"] = vec3(897.9,1987.9,84.77), ["Mode"] = "5" },
	{ ["Name"] = "Grota", ["Coords"] = vec3(1361.94,-214.28,158.15), ["Mode"] = "5" },
	{ ["Name"] = "Chernobyl", ["Coords"] = vec3(1854.57,-2249.38,171.75), ["Mode"] = "5" },
	{ ["Name"] = "Crips", ["Coords"] = vec3(2314.3,2634.81,61.62), ["Mode"] = "5" },
	{ ["Name"] = "Distrito", ["Coords"] = vec3(1903.14,2.44,188.89), ["Mode"] = "5" },
	{ ["Name"] = "Dz7", ["Coords"] = vec3(2055.25,6484.54,113.79), ["Mode"] = "5" },
	{ ["Name"] = "Labirinto", ["Coords"] = vec3(2219.93,3957.41,40.37), ["Mode"] = "5" },
	{ ["Name"] = "P77", ["Coords"] = vec3(1969.89,424.66,178.78), ["Mode"] = "5" },
	{ ["Name"] = "Favela6", ["Coords"] = vec3(-2401.13,2627.4,27.57), ["Mode"] = "5" },
	{ ["Name"] = "Milicia", ["Coords"] = vec3(1555.61,1466.56,114.49), ["Mode"] = "5" },
	{ ["Name"] = "Medellín", ["Coords"] = vec3(2237.29,3561.25,68.78), ["Mode"] = "5" },
	{ ["Name"] = "Mare", ["Coords"] = vec3(2354.38,481.5,202.5), ["Mode"] = "5" },
	{ ["Name"] = "Crateva", ["Coords"] = vec3(620.08,2562.57,73.36), ["Mode"] = "5" }
}
-----------------------------------------------------------------------------------------------------------------------------------------
-- LABELS
-----------------------------------------------------------------------------------------------------------------------------------------
local Labels = {
	["1"] = {
		{
			event = "chest:Open",
			label = "Compartimento Geral",
			tunnel = "shop",
			service = "Normal"
		},{
			event = "chest:Open",
			label = "Compartimento Pessoal",
			tunnel = "shop",
			service = "Personal"
		},{
			event = "chest:Open",
			label = "Compartimento Evidências",
			tunnel = "shop",
			service = "Evidences"
		},{
			event = "chest:Upgrade",
			label = "Aumentar",
			tunnel = "server"
		}
	},
	["2"] = {
		{
			event = "chest:Open",
			label = "Abrir",
			tunnel = "shop",
			service = "Normal"
		},{
			event = "chest:Upgrade",
			label = "Aumentar",
			tunnel = "server"
		}
	},
	["3"] = {
		{
			event = "chest:Open",
			label = "Abrir",
			tunnel = "shop",
			service = "Normal"
		},{
			event = "chest:Upgrade",
			label = "Aumentar",
			tunnel = "server"
		},{
			event = "chest:Open",
			label = "Bau Lider",
			tunnel = "shop",
			service = "Manager"
		}
	},
	["4"] = {
		{
			event = "chest:Open",
			label = "Bandeja",
			tunnel = "shop",
			service = "Tray"
		},
		{
			event = "restaurante:Charge",
			label = "Cobrança",
			tunnel = "server"
		}
	},
	["5"] = {
		{
			event = "chest:Open",
			label = "Abrir",
			tunnel = "shop",
			service = "Normal"
		},
		{
			event = "chest:Upgrade",
			label = "Aumentar",
			tunnel = "server"
		},
		 {
		 	event = "chest:Open",
		 	label = "Baú Gerência",
		 	tunnel = "shop",
		 	service = "Gerente"
		 },
		{
			event = "chest:Open",
			label = "Baú Líder",
			tunnel = "shop",
			service = "Manager"
		}
	}
}
-----------------------------------------------------------------------------------------------------------------------------------------
-- THREADINIT
-----------------------------------------------------------------------------------------------------------------------------------------
CreateThread(function()
	for Name,v in pairs(Chests) do
		exports["target"]:AddCircleZone("Chest:"..Name,v["Coords"],0.75,{
			name = "Chest:"..Name,
			heading = 3374176
		},{
			Distance = 1.5,
			shop = v["Name"],
			options = Labels[v["Mode"]]
		})
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- CHEST:OPEN
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("chest:Open",function(Name,Init)
    if vSERVER.Permissions(Name,Init) then
        SetNuiFocus(true,true)
        SendNUIMessage({ Action = "Open" })
        TriggerEvent("sounds:source","chest",0.35)
        vRP.playAnim(false,{"amb@prop_human_parking_meter@female@idle_a","idle_a_female"},true)
    end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- CHESTCLOSE
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNUICallback("Close",function(Data,Callback)
	SendNUIMessage({ Action = "Close" })
	SetNuiFocus(false,false)
	vRP.Destroy()

	Callback("Ok")
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- TAKE
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNUICallback("Take",function(Data,Callback)
	vSERVER.Take(Data["item"],Data["slot"],Data["amount"],Data["target"])

	Callback("Ok")
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- STORE
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNUICallback("Store",function(Data,Callback)
	vSERVER.Store(Data["item"],Data["slot"],Data["amount"],Data["target"])

	Callback("Ok")
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- UPDATE
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNUICallback("Update",function(Data,Callback)
	vSERVER.Update(Data["slot"],Data["target"],Data["amount"])

	Callback("Ok")
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- CHEST
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNUICallback("Chest",function(Data,Callback)
	local Inventory,Chest,invPeso,invMaxpeso,chestPeso,chestMaxpeso = vSERVER.Chest()
	if Inventory then
		Callback({ Inventory = Inventory, Chest = Chest, invPeso = invPeso, invMaxpeso = invMaxpeso, chestPeso = chestPeso, chestMaxpeso = chestMaxpeso })
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- CHEST:UPDATE
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("chest:Update")
AddEventHandler("chest:Update",function(Action,invPeso,invMaxpeso,chestPeso,chestMaxpeso)
	SendNUIMessage({ Action = Action, invPeso = invPeso, invMaxpeso = invMaxpeso, chestPeso = chestPeso, chestMaxpeso = chestMaxpeso })
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- CHEST:CLOSE
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("chest:Close")
AddEventHandler("chest:Close",function(Action)
    SendNUIMessage({ Action = "Close" })
    SetNuiFocus(false,false)
    vRP.Destroy()
end)