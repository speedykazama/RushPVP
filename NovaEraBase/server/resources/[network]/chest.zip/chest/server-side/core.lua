-----------------------------------------------------------------------------------------------------------------------------------------
-- VRP
-----------------------------------------------------------------------------------------------------------------------------------------
local Tunnel = module("vrp","lib/Tunnel")
local Proxy = module("vrp","lib/Proxy")
vRPC = Tunnel.getInterface("vRP")
vRP = Proxy.getInterface("vRP")
-----------------------------------------------------------------------------------------------------------------------------------------
-- CONNECTION
-----------------------------------------------------------------------------------------------------------------------------------------
Creative = {}
Tunnel.bindInterface("chest",Creative)
vKEYBOARD = Tunnel.getInterface("keyboard")
-----------------------------------------------------------------------------------------------------------------------------------------
-- VARIABLES
-----------------------------------------------------------------------------------------------------------------------------------------
local Open = {}
local Cooldown = {}
-----------------------------------------------------------------------------------------------------------------------------------------
-- VERIFY
-----------------------------------------------------------------------------------------------------------------------------------------
--[[function Creative.Verify()
	local source = source
	local Passport = vRP.Passport(source)
	if Passport then
		if vRP.GetFine(Passport) > 0 then
			TriggerClientEvent("Notify",source,"amarelo","Você possui multas pendentes.",10000)
			return false
		end

		if exports["hud"]:Wanted(Passport,source) and exports["hud"]:Reposed(Passport) then
			return false
		end
	end

	return true
end]]--
-----------------------------------------------------------------------------------------------------------------------------------------
-- PERMISSIONS
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.Permissions(Name,Mode)
	local source = source
	local Passport = vRP.Passport(source)
	if Passport and not exports["hud"]:Wanted(Passport) then
		if Mode == "Personal" then
			Open[Passport] = { ["Name"] = Passport, ["Weight"] = 50, ["Logs"] = false, ["Save"] = true }
			return true
		elseif Mode == "Evidences" then
			local Keyboard = vKEYBOARD.keySingle(source,"Passaporte:")
			if Keyboard then
				Open[Passport] = { ["Name"] = "Evidences:"..Keyboard[1], ["Weight"] = 50, ["Logs"] = false, ["Save"] = true }
				return true
			end
        elseif Mode == 'Backpack' then
            local index = SplitOne(Name)
            local weight = SplitTwo(Name)
            local weight = tonumber(weight) or 50

            Open[Passport] = {
                ["Name"] = index .. ':' .. Passport,
                ["Weight"] = weight,
                ["Logs"] = false,
                ["Save"] = true,
                ["Slots"] = 50
            }

            return true
		elseif Mode == "Custom" or Mode == "Trash" then
			if SplitOne(Name,":") == "Helicrash" and Cooldown[Name] and Cooldown[Name] > os.time() then
                TriggerClientEvent("Notify",source,"vermelho","O compartimento está quente e você se queimou!.",10000)
                vRPC.DowngradeHealth(source,50)

                return false
            end

			if Mode == "Trash" then
				Name = "Trash:"..Name
			end

			Open[Passport] = {
				["Name"] = Name,
				["Weight"] = 50,
				["Logs"] = false,
				["Save"] = false,
				["Slots"] = 20
			}

			return true
		elseif Mode == "Manager" then
			if vRP.HasGroup(Passport,Name,1) then
				Open[Passport] = { ["Name"] = "Manager:" .. Name, ["Weight"] = 1000, ["Logs"] = true, ["Save"] = true }
				return true
			else
				TriggerClientEvent("Notify", source, "vermelho", "Sem Permissão", 5000)
			end
		elseif Mode == "Gerente" then
			if vRP.HasGroup(Passport,Name,2) then
				Open[Passport] = { ["Name"] = "Gerente:" .. Name, ["Weight"] = 750, ["Logs"] = true, ["Save"] = true }
				return true
			else
				TriggerClientEvent("Notify", source, "vermelho", "Sem Permissão", 5000)
			end				
		elseif Mode == "Tray" then
			Open[Passport] = { ["Name"] = Name, ["Weight"] = 15, ["Logs"] = false, ["Save"] = true }
			return true
		else
			local Consult = vRP.Query("chests/GetChests", { name = Name })
			if Consult[1] then
				if vRP.HasGroup(Passport, Consult[1]["perm"]) then
					Open[Passport] = { ["Name"] = Name, ["Weight"] = Consult[1]["weight"], ["Logs"] = Consult[1]["logs"], ["Save"] = true }
					return true
				else
					local permName = Consult[1]["perm"]
					TriggerClientEvent("Notify", source, "vermelho", "Sem Permissão: " .. permName, 5000)
				end
			else
				TriggerClientEvent("Notify", source, "vermelho", "Chest não encontrado no Banco de Dados.", 5000)
			end
		end
	end

	return false
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- CHEST
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.Chest()
	local source = source
	local Passport = vRP.Passport(source)
	if Passport and Open[Passport] then
		local Inventory = {}
		local Inv = vRP.Inventory(Passport)
		for Index,v in pairs(Inv) do
			v["amount"] = parseInt(v["amount"])
			v["name"] = itemName(v["item"])
			v["peso"] = itemWeight(v["item"])
			v["index"] = itemIndex(v["item"])
			v["max"] = itemMaxAmount(v["item"])
			v["desc"] = itemDescription(v["item"])
			v["economy"] = parseFormat(itemEconomy(v["item"]))
			v["key"] = v["item"]
			v["slot"] = Index

			local Split = splitString(v["item"],"-")
			if Split[2] ~= nil then
				if itemDurability(v["item"]) then
					v["durability"] = parseInt(os.time() - Split[2])
					v["days"] = itemDurability(v["item"])
				else
					v["durability"] = 0
					v["days"] = 1
				end
			else
				v["durability"] = 0
				v["days"] = 1
			end

			v["desc"] = itemDescription(v["item"]) or ""

			if Split[1] == "driverlicense" and Split[3] then
				local licenseData = json.decode(Split[3])
				if licenseData then
					v["desc"] = v["desc"]..
					"<br><legenda>Nome: <r>"..licenseData["name"].."</r> <br>Emissão: <r>"..os.date("%d/%m/%Y", licenseData["issued"]).."</r>"..
					"<br>Validade: <r>"..os.date("%d/%m/%Y", licenseData["expiration"]).."</r>"..
					"<br>Categoria: <r>"..string.gsub(json.encode(licenseData["categories"]), '[^%a,]', '').."</r></legenda>"
				end
			end
			
			if Split[1] == "dmvdocs" and Split[2] and Split[3] and Split[4] and Split[5] then
				local identity = vRP.Identity(parseInt(Split[2]))
				if identity then
					v["desc"] = v["desc"]..
					"<br><legenda>Nome: <r>"..identity["name"].." "..identity["name2"].."</r>"..
					"<br>Prática: <r>"..string.gsub(Split[5], '[^%a,]', '').."</r>"..
					"<br>Teórica: <r>"..string.gsub(Split[4], '[^%a,]', '').."</r>"..
					"<br>Categoria: <r>"..string.gsub(Split[3], '[^%a,]', '').."</r></legenda>"
				end
			end
			
			if itemType(Split[1]) == "Armamento" and Split[3] then
				local DonoSerial = Split[3]
				local UserSerial = vRP.UserSerial(DonoSerial)
				if UserSerial then
					local Identity = vRP.Identity(UserSerial["id"])
					if Identity and Identity["serial"] then
						v["desc"] = "<br><description>Serial da Arma: <green>"..Identity["serial"].."</green>.</description>"
					end
				else
					-- Se não encontrar as informações do jogador com base no serial
					v["desc"] = "<br><description>Serial da Arma: <green> Desconhecido </green>.</description>"
				end
			end

			--[[if itemType(Split[1]) == "Armamento" and Split[3] then
				v["desc"] = "<br><description>Nome de registro: <green>"..vRP.FullName(Split[3]).."</green>.</description>"
			end]]--

			Inventory[Index] = v
		end

		local Chest = {}
		local Result = vRP.GetSrvData("Chest:"..Open[Passport]["Name"],Open[Passport]["Save"])
		for Index,v in pairs(Result) do
			v["amount"] = parseInt(v["amount"])
			v["name"] = itemName(v["item"])
			v["peso"] = itemWeight(v["item"])
			v["index"] = itemIndex(v["item"])
			v["max"] = itemMaxAmount(v["item"])
			v["economy"] = parseFormat(itemEconomy(v["item"]))
			v["desc"] = itemDescription(v["item"])
			v["key"] = v["item"]
			v["slot"] = Index

			local Split = splitString(v["item"],"-")
			if Split[2] ~= nil then
				if itemDurability(v["item"]) then
					v["durability"] = parseInt(os.time() - Split[2])
					v["days"] = itemDurability(v["item"])
				else
					v["durability"] = 0
					v["days"] = 1
				end
			else
				v["durability"] = 0
				v["days"] = 1
			end

			v["desc"] = itemDescription(v["item"]) or ""

			if Split[1] == "driverlicense" and Split[3] then
				local licenseData = json.decode(Split[3])
				if licenseData then
					v["desc"] = v["desc"]..
					"<br><legenda>Nome: <r>"..licenseData["name"].."</r> <br>Emissão: <r>"..os.date("%d/%m/%Y", licenseData["issued"]).."</r>"..
					"<br>Validade: <r>"..os.date("%d/%m/%Y", licenseData["expiration"]).."</r>"..
					"<br>Categoria: <r>"..string.gsub(json.encode(licenseData["categories"]), '[^%a,]', '').."</r></legenda>"
				end
			end
			
			if Split[1] == "dmvdocs" and Split[2] and Split[3] and Split[4] and Split[5] then
				local identity = vRP.Identity(parseInt(Split[2]))
				if identity then
					v["desc"] = v["desc"]..
					"<br><legenda>Nome: <r>"..identity["name"].." "..identity["name2"].."</r>"..
					"<br>Prática: <r>"..string.gsub(Split[5], '[^%a,]', '').."</r>"..
					"<br>Teórica: <r>"..string.gsub(Split[4], '[^%a,]', '').."</r>"..
					"<br>Categoria: <r>"..string.gsub(Split[3], '[^%a,]', '').."</r></legenda>"
				end
			end

			if itemType(Split[1]) == "Armamento" and Split[3] then
				local DonoSerial = Split[3]
				local UserSerial = vRP.UserSerial(DonoSerial)
				if UserSerial then
					local Identity = vRP.Identity(UserSerial["id"])
					if Identity and Identity["serial"] then
						v["desc"] = "<br><description>Serial da Arma: <green>"..Identity["serial"].."</green>.</description>"
					end
				else
					-- Se não encontrar as informações do jogador com base no serial
					v["desc"] = "<br><description>Serial da Arma: <green> Desconhecido </green>.</description>"
				end
			end

			Chest[Index] = v
		end

		return Inventory,Chest,vRP.InventoryWeight(Passport),vRP.GetWeight(Passport),vRP.ChestWeight(Result),Open[Passport]["Weight"]
	end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- OPENITENS
-----------------------------------------------------------------------------------------------------------------------------------------
local OpenItens = {
	["mechanicpass"] = {
		["Open"] = "Mechanic",
		["Table"] = {
			{ ["Item"] = "advtoolbox", ["Amount"] = 1 },
			{ ["Item"] = "toolbox", ["Amount"] = 2 },
			{ ["Item"] = "tyres", ["Amount"] = 4 },
			{ ["Item"] = "dollars", ["Amount"] = 200 }
		}
	},
	["uwucoffeepass"] = {
		["Open"] = "UwuCoffee",
		["Table"] = {
			{ ["Item"] = "nigirizushi", ["Amount"] = 3 },
			{ ["Item"] = "sushi", ["Amount"] = 3 },
			{ ["Item"] = "dollars", ["Amount"] = 200 }
		}
	},
	["pizzathispass"] = {
		["Open"] = "PizzaThis",
		["Table"] = {
			{ ["Item"] = "nigirizushi", ["Amount"] = 3 },
			{ ["Item"] = "sushi", ["Amount"] = 3 },
			{ ["Item"] = "dollars", ["Amount"] = 200 }
		}
	},
	["burgershotpass"] = {
		["Open"] = "BurgerShot",
		["Table"] = {
			{ ["Item"] = "hamburger2", ["Amount"] = 1 },
			{ ["Item"] = "cookedmeat", ["Amount"] = 2 },
			{ ["Item"] = "cookedfishfillet", ["Amount"] = 1 },
			{ ["Item"] = "dollars", ["Amount"] = 200 }
		}
	},
	["paramedicpass"] = {
		["Open"] = "Paramedic",
		["Table"] = {
			{ ["Item"] = "gauze", ["Amount"] = 3 },
			{ ["Item"] = "medkit", ["Amount"] = 1 },
			{ ["Item"] = "analgesic", ["Amount"] = 4 },
			{ ["Item"] = "dollars", ["Amount"] = 200 }
		}
	}
}
-----------------------------------------------------------------------------------------------------------------------------------------
-- STORE
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.Store(Item,Slot,Amount,Target)
	local source = source
	local Amount = parseInt(Amount)
	local Passport = vRP.Passport(source)
	if Passport and Open[Passport] then
		if Amount <= 0 then Amount = 1 end

		if itemBlock(Item) then
			TriggerClientEvent("chest:Update",source,"Refresh")

			return true
		end

		if OpenItens[Item] and OpenItens[Item]["Open"] == Open[Passport]["Name"] then
			if vRP.TakeItem(Passport,Item,1) then
				for _,v in pairs(OpenItens[Item]["Table"]) do
					vRP.GenerateItem(Passport,v["Item"],v["Amount"])
				end
			end

			TriggerClientEvent("chest:Update",source,"Refresh")

			return true
		end

		if vRP.StoreChest(Passport,"Chest:"..Open[Passport]["Name"],Amount,Open[Passport]["Weight"],Slot,Target) then
			TriggerClientEvent("chest:Update",source,"Refresh")
		else
			local Result = vRP.GetSrvData("Chest:"..Open[Passport]["Name"],Open[Passport]["Save"])
			TriggerClientEvent("chest:Update",source,"Update",vRP.InventoryWeight(Passport),vRP.GetWeight(Passport),vRP.ChestWeight(Result),Open[Passport]["Weight"])

            if Open[Passport]["Logs"] then 
                TriggerEvent("Discord", "Chest-" .. Open[Passport]["Name"], "**[Guardou Item]**\n\n**Passaporte:** " .. Passport .. "\n**Nome:** " .. Open[Passport]["Name"] .. "\n**Item:** " .. itemName(Item) .. "\n**Quantidade:** " .. Amount .. "\n**Data e Hora:** " .. os.date("%d/%m/%Y - %H:%M:%S"), 16777215) 
            end		
		end
	end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- TAKE
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.Take(Item,Slot,Amount,Target)
	local source = source
	local Amount = parseInt(Amount)
	local Passport = vRP.Passport(source)
	if Passport and Open[Passport] then
		if Amount <= 0 then Amount = 1 end

		if vRP.TakeChest(Passport,"Chest:"..Open[Passport]["Name"],Amount,Slot,Target) then
			TriggerClientEvent("chest:Update",source,"Refresh")
		else
			local Result = vRP.GetSrvData("Chest:"..Open[Passport]["Name"],Open[Passport]["Save"])
			TriggerClientEvent("chest:Update",source,"Update",vRP.InventoryWeight(Passport),vRP.GetWeight(Passport),vRP.ChestWeight(Result),Open[Passport]["Weight"])

			if string.sub(Open[Passport]["Name"],1,9) == "Helicrash" and json.encode(Result) == "[]" then    
                TriggerClientEvent("chest:Close",source)
                exports["helicrash"]:Box()
            end

            if Open[Passport]["Logs"] then 
                TriggerEvent("Discord", "Chest-" .. Open[Passport]["Name"], "**[Retirou Item]**\n\n**Passaporte:** " .. Passport .. "\n**Nome:** " .. Open[Passport]["Name"] .. "\n**Item:** " .. itemName(Item) .. "\n**Quantidade:** " .. Amount .. "\n**Data e Hora:** " .. os.date("%d/%m/%Y - %H:%M:%S"), 16777215) 
            end	
		end
	end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- UPDATE
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.Update(Slot,Target,Amount)
	local source = source
	local Amount = parseInt(Amount)
	local Passport = vRP.Passport(source)
	if Passport and Open[Passport] then
		if Amount <= 0 then Amount = 1 end

		if vRP.UpdateChest(Passport,"stackChest:"..Open[Passport]["Name"],Slot,Target,Amount) then
			TriggerClientEvent("chest:Update",source,"Refresh")
		end
	end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- CHEST:UPGRADE
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("chest:Upgrade")
AddEventHandler("chest:Upgrade",function(Name)
	local source = source
	local Passport = vRP.Passport(source)
	if Passport then
		if vRP.HasService(Passport,Name) then
			if vRP.Request(source,"Aumentar <b>10Kg</b> por <b>$5.000</b> dólares?","Sim, efetuar pagamento","Não, decido depois") then
				if vRP.PaymentFull(Passport,5000) then
					vRP.Query("chests/UpdateChests",{ name = Name })
					TriggerClientEvent("Notify",source,"verde","Compra concluída.",3000)
				else
					TriggerClientEvent("Notify",source,"vermelho","<b>Dólares</b> insuficientes.",5000)
				end
			end
		end
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- CHEST:COOLDOWN
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("chest:Cooldown")
AddEventHandler("chest:Cooldown",function(Name)
    Cooldown[Name] = os.time() + math.random(120,180)
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- DISCONNECT
-----------------------------------------------------------------------------------------------------------------------------------------
AddEventHandler("Disconnect",function(Passport)
	if Open[Passport] then
		Open[Passport] = nil
	end
end)