-----------------------------------------------------------------------------------------------------------------------------------------
-- VRP
-----------------------------------------------------------------------------------------------------------------------------------------
local Tunnel = module("vrp","lib/Tunnel")
local Proxy = module("vrp","lib/Proxy")
vRPC = Tunnel.getInterface("vRP")
vRP = Proxy.getInterface("vRP")
-----------------------------------------------------------------------------------------------------------------------------------------
-- CONNECTION
-----------------------------------------------------------------------------------------------------------------------------------------
Creative = {}
vCLIENT = Tunnel.getInterface("luckywheel")
Tunnel.bindInterface("luckywheel",Creative)
-----------------------------------------------------------------------------------------------------------------------------------------
-- VARIABLES
-----------------------------------------------------------------------------------------------------------------------------------------
local Bonus = {}
local Actived = {}
local Payments = {}
local Active = os.time()
-----------------------------------------------------------------------------------------------------------------------------------------
-- CHECK
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.Check()
	local source = source
	local Passport = vRP.Passport(source)
	if Passport then
		if os.time() > Active then
			if Bonus[tostring(Passport)] then
				Active = os.time() + 20
				Bonus[tostring(Passport)] = nil
				return true
			end

			if vRP.TakeItem(Passport,"luckywheelpass",1,true) then
				Active = os.time() + 20
				return true
			end

			--if vRP.PaymentBank(Passport,5000) then
			if vRP.TakeItem(Passport,"chips",5000,true) then
				Active = os.time() + 20
				return true
			else
				--TriggerClientEvent("Notify",source,"vermelho","<b>Dólares</b> insuficientes.",5000)
				TriggerClientEvent("Notify",source,"vermelho","<b>Fichas</b> insuficientes.",5000)
			end
		else
			local Cooldown = Active - os.time()
			TriggerClientEvent("Notify",source,"azul","Aguarde <b>"..Cooldown.."</b> segundos.",5000)
		end
	end

	return false
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- ROLLING
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.Rolling()
	local source = source
	local Passport = vRP.Passport(source)
	if Passport and not Payments[Passport] and os.time() < Active then
		local Result = math.random(325)

		if Result <= 10 or Result >= 218 then
			Payments[Passport] = 1
		elseif Result >= 11 and Result <= 50 then
			Payments[Passport] = 2
		elseif Result >= 51 and Result <= 55 then
			Payments[Passport] = 3
		elseif Result >= 56 and Result <= 62 then
			Payments[Passport] = 4
		elseif Result >= 63 and Result <= 75 then
			Payments[Passport] = 5
		elseif Result >= 76 and Result <= 120 then
			Payments[Passport] = 6
		elseif Result >= 121 and Result <= 125 then
			Payments[Passport] = 7
		elseif Result >= 126 and Result <= 130 then
			Payments[Passport] = 8
		elseif Result >= 131 and Result <= 150 then
			Payments[Passport] = 9
		elseif Result >= 151 and Result <= 160 then
			Payments[Passport] = 10
		elseif Result >= 161 and Result <= 165 then
			Payments[Passport] = 11
		elseif Result >= 166 and Result <= 167 then
			Payments[Passport] = 12
		elseif Result >= 167 and Result <= 180 then
			Payments[Passport] = 13
		elseif Result >= 181 and Result <= 186 then
			Payments[Passport] = 14
		elseif Result >= 187 and Result <= 189 then
			Payments[Passport] = 15
		elseif Result >= 190 and Result <= 192 then
			Payments[Passport] = 16
		elseif Result >= 193 and Result <= 210 then
			Payments[Passport] = 17
		elseif Result >= 211 and Result <= 215 then
			Payments[Passport] = 18
		elseif Result == 216 then
			Payments[Passport] = 19
		elseif Result == 217 then
			Payments[Passport] = 20
		end

		vCLIENT.Active(source)

		local Players = vRPC.Players(source)
		for _,v in pairs(Players) do
			async(function()
				vCLIENT.Start(v,Payments[Passport])
			end)
		end
	end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- ITENS
-----------------------------------------------------------------------------------------------------------------------------------------
Mystery = {
	{ ["Item"] = "gemstone", ["Quan"] = 5 },
	{ ["Item"] = "gemstone", ["Quan"] = 10 },
	{ ["Item"] = "gemstone", ["Quan"] = 15 },
	{ ["Item"] = "gemstone", ["Quan"] = 20 }
}
Carval = {
	{ ["Item"] = "vehiclevip1", ["Quan"] = 1 },
	{ ["Item"] = "vehiclevip2", ["Quan"] = 1 },
	{ ["Item"] = "vehiclevip3", ["Quan"] = 1 }
}
Clothing = {
	{ ["Item"] = "mask", ["Quan"] = 1 },
	{ ["Item"] = "hat", ["Quan"] = 1 },
	{ ["Item"] = "glasses", ["Quan"] = 1 },
	{ ["Item"] = "gloves", ["Quan"] = 1 }
}
-----------------------------------------------------------------------------------------------------------------------------------------
-- PAYMENT
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.Payment()
	local source = source
	local Passport = vRP.Passport(source)
	local Selected = math.random(#Mystery)
	local carval = math.random(#Carval)
	local clothing = math.random(#Clothing)
	if Passport and not Actived[Passport] and Payments[Passport] then
		Actived[Passport] = true

		if Payments[Passport] == 2 then
			vRP.GiveBank(Passport,2500)
			TriggerEvent("Discord", "Cassino", "**[Roleta]**\n\n**Passaporte:** " .. Passport .. "\n**Recebeu:** 2.500$ " .. "\n**Data e Hora:** " .. os.date("%d/%m/%Y - %H:%M:%S"), 16777215)
		elseif Payments[Passport] == 1 or Payments[Passport] == 9 or Payments[Passport] == 13 or Payments[Passport] == 17 then
			vRP.GenerateItem(Passport, Clothing[clothing]["Item"],Clothing[clothing]["Quan"], true)
			TriggerEvent("Discord", "Cassino", "**[Roleta]**\n\n**Passaporte:** " .. Passport .. "\n**Recebeu:** "..Clothing[clothing]["Quan"].." "..Clothing[clothing]["Item"].." " .. "\n**Data e Hora:** " .. os.date("%d/%m/%Y - %H:%M:%S"), 16777215)
		elseif Payments[Passport] == 3 or Payments[Passport] == 11 then
			vRP.GiveBank(Passport,20000)
			TriggerEvent("Discord", "Cassino", "**[Roleta]**\n\n**Passaporte:** " .. Passport .. "\n**Recebeu:** 20.000$ " .. "\n**Data e Hora:** " .. os.date("%d/%m/%Y - %H:%M:%S"), 16777215)
		elseif Payments[Passport] == 4 or Payments[Passport] == 14 then
			vRP.GiveBank(Passport,10000)
			TriggerEvent("Discord", "Cassino", "**[Roleta]**\n\n**Passaporte:** " .. Passport .. "\n**Recebeu:** 10.000$ " .. "\n**Data e Hora:** " .. os.date("%d/%m/%Y - %H:%M:%S"), 16777215)
		elseif Payments[Passport] == 5 then
			Bonus[tostring(Passport)] = true
			TriggerClientEvent("Notify", source, "verde", "Parabens você ganhou um giro Gratis", 5000)
			TriggerEvent("Discord", "Cassino", "**[Roleta]**\n\n**Passaporte:** " .. Passport .. "\n**Recebeu:** Giro Gratis " .. "\n**Data e Hora:** " .. os.date("%d/%m/%Y - %H:%M:%S"), 16777215)
		elseif Payments[Passport] == 6 then
			vRP.GiveBank(Passport,5000)
			TriggerEvent("Discord", "Cassino", "**[Roleta]**\n\n**Passaporte:** " .. Passport .. "\n**Recebeu:** 5.000$ " .. "\n**Data e Hora:** " .. os.date("%d/%m/%Y - %H:%M:%S"), 16777215)
		elseif Payments[Passport] == 7 then
			vRP.GiveBank(Passport,30000)
			TriggerEvent("Discord", "Cassino", "**[Roleta]**\n\n**Passaporte:** " .. Passport .. "\n**Recebeu:** 30.000$ " .. "\n**Data e Hora:** " .. os.date("%d/%m/%Y - %H:%M:%S"), 16777215)
		elseif Payments[Passport] == 8 or Payments[Passport] == 18 then
			vRP.GiveBank(Passport,15000)
			TriggerEvent("Discord", "Cassino", "**[Roleta]**\n\n**Passaporte:** " .. Passport .. "\n**Recebeu:** 15.000$ " .. "\n**Data e Hora:** " .. os.date("%d/%m/%Y - %H:%M:%S"), 16777215)
		elseif Payments[Passport] == 10 then
			vRP.GiveBank(Passport,7500)
			TriggerEvent("Discord", "Cassino", "**[Roleta]**\n\n**Passaporte:** " .. Passport .. "\n**Recebeu:** 7.500$ " .. "\n**Data e Hora:** " .. os.date("%d/%m/%Y - %H:%M:%S"), 16777215)
		elseif Payments[Passport] == 12 then
			vRP.GenerateItem(Passport, Mystery[Selected]["Item"],Mystery[Selected]["Quan"], true)
			TriggerEvent("Discord", "Cassino", "**[Roleta]**\n\n**Passaporte:** " .. Passport .. "\n**Recebeu:** "..Mystery[Selected]["Quan"].." "..Mystery[Selected]["Item"].." " .. "\n**Data e Hora:** " .. os.date("%d/%m/%Y - %H:%M:%S"), 16777215)
		elseif Payments[Passport] == 15 then
			vRP.GiveBank(Passport,40000)
			TriggerEvent("Discord", "Cassino", "**[Roleta]**\n\n**Passaporte:** " .. Passport .. "\n**Recebeu:** 40.000$ " .. "\n**Data e Hora:** " .. os.date("%d/%m/%Y - %H:%M:%S"), 16777215)
		elseif Payments[Passport] == 16 then
			vRP.GiveBank(Passport,17500)
			TriggerEvent("Discord", "Cassino", "**[Roleta]**\n\n**Passaporte:** " .. Passport .. "\n**Recebeu:** 17.500$ " .. "\n**Data e Hora:** " .. os.date("%d/%m/%Y - %H:%M:%S"), 16777215)
		elseif Payments[Passport] == 19 then
			vRP.GenerateItem(Passport, Carval[carval]["Item"],Carval[carval]["Quan"], true)
			TriggerEvent("Discord", "Cassino", "**[Roleta]**\n\n**Passaporte:** " .. Passport .. "\n**Recebeu:** "..Carval[carval]["Quan"].." "..Carval[carval]["Item"].." " .. "\n**Data e Hora:** " .. os.date("%d/%m/%Y - %H:%M:%S"), 16777215)
		elseif Payments[Passport] == 20 then
			vRP.GiveBank(Passport,5000)
			TriggerEvent("Discord", "Cassino", "**[Roleta]**\n\n**Passaporte:** " .. Passport .. "\n**Recebeu:** 5.000$ " .. "\n**Data e Hora:** " .. os.date("%d/%m/%Y - %H:%M:%S"), 16777215)
		end

		Payments[Passport] = nil
		Actived[Passport] = nil
	end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- DISCONNECT
-----------------------------------------------------------------------------------------------------------------------------------------
AddEventHandler("Disconnect",function(Passport)
	if Payments[Passport] then
		Payments[Passport] = nil
	end

	if Actived[Passport] then
		Actived[Passport] = nil
	end
end)