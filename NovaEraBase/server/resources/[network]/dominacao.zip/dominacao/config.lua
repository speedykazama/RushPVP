Config = {}

-- [[ LOGS DISCORD ]] --
Config.Webhook = "https://discord.com/api/webhooks/1451231567040090303/kl-AeO_JZZqox20lXZz2C2NTSvmhfzrXBQL8LFt02FKt9ddaCyU0G8EfffSpECCHTm55"
Config.WebhookKill = "https://discord.com/api/webhooks/1453415397075320832/j-YxxseFKF51WIG7Vslqq6YxyBmPxy_yhscEeT-HOtDT8w_jSe4V9RQrhNOvBPxZPifv"


-- Configurações Gerais
Config.LootBox = {
    model = "prop_mil_crate_01", 
    timeToLoot = 300,
    openTime = 5000,
    maxDistance = 2.5,
    anim = { dict = "amb@medic@standing@kneel@idle_a", name = "idle_a" } 
}

Config.Zones = {
    [1] = {
        name = "Trevor",
        coords = vec3(1731.57,3309.75,41.21),
        radius = 100.0,
        time = 720,
        permissions = { "Admin", "Maonegra", "Bairro13", "Setor13", "Grota", "Chernobyl", "Crips", "Dz7", "Labirinto", "P77", "Milicia", "Medellin", "Mare", "Crateva", "Distrito" }, 
        cooldown = 3600,
        lootTable = {
            { item = "WEAPON_PISTOL_MK2", min = 1, max = 1, chance = 10 },
            { item = "WEAPON_COMPACTRIFLE", min = 1, max = 1, chance = 10 },
            { item = "WEAPON_PISTOL_AMMO", min = 35, max = 75, chance = 50 },
            { item = "WEAPON_RIFLE_AMMO", min = 25, max = 65, chance = 40 },
            { item = "dollarsroll", min = 35000, max = 105000, chance = 100 }
        }
    },
    [2] = {
        name = "Observatorio",
        coords = vec3(713.64, 580.28, 129.05),
        radius = 100.0,
        time = 10,
        permissions = { "Admin", "Maonegra", "Bairro13", "Setor13", "Grota", "Chernobyl", "Crips", "Dz7", "Labirinto", "P77", "Milicia", "Medellin", "Mare", "Crateva", "Distrito" }, 
        cooldown = 3600,
        lootTable = {
            { item = "WEAPON_PISTOL_MK2", min = 1, max = 1, chance = 10 },
            { item = "WEAPON_COMPACTRIFLE", min = 1, max = 1, chance = 10 },
            { item = "WEAPON_PISTOL_AMMO", min = 35, max = 75, chance = 50 },
            { item = "WEAPON_RIFLE_AMMO", min = 25, max = 65, chance = 40 },
            { item = "dollarsroll", min = 35000, max = 105000, chance = 100 }
        }
    },
    [3] = {
        name = "Niobio",
        coords = vec3(3592.41,3714.3,29.69),
        radius = 100.0,
        time = 720,
        permissions = { "Admin", "Maonegra", "Bairro13", "Setor13", "Grota", "Chernobyl", "Crips", "Dz7", "Labirinto", "P77", "Milicia", "Medellin", "Mare", "Crateva", "Distrito" }, 
        cooldown = 3600,
        lootTable = {
            { item = "WEAPON_PISTOL_MK2", min = 1, max = 1, chance = 10 },
            { item = "WEAPON_COMPACTRIFLE", min = 1, max = 1, chance = 10 },
            { item = "WEAPON_PISTOL_AMMO", min = 35, max = 75, chance = 50 },
            { item = "WEAPON_RIFLE_AMMO", min = 25, max = 65, chance = 40 },
            { item = "dollarsroll", min = 35000, max = 105000, chance = 100 }
        }
    },
    [4] = {
        name = "Industria",
        coords = vec3(2747.83,1519.44,24.5),
        radius = 100.0,
        time = 720,
        permissions = { "Admin", "Maonegra", "Bairro13", "Setor13", "Grota", "Chernobyl", "Crips", "Dz7", "Labirinto", "P77", "Milicia", "Medellin", "Mare", "Crateva", "Distrito" }, 
        cooldown = 3600,
        lootTable = {
            { item = "WEAPON_PISTOL_MK2", min = 1, max = 1, chance = 10 },
            { item = "WEAPON_COMPACTRIFLE", min = 1, max = 1, chance = 10 },
            { item = "WEAPON_PISTOL_AMMO", min = 35, max = 75, chance = 50 },
            { item = "WEAPON_RIFLE_AMMO", min = 25, max = 65, chance = 40 },
            { item = "dollarsroll", min = 35000, max = 105000, chance = 100 }
        }
    },
    [5] = {
        name = "Porto",
        coords = vec3(1056.66,-3130.6,5.9),
        radius = 100.0,
        time = 720,
        permissions = { "Admin", "Maonegra", "Bairro13", "Setor13", "Grota", "Chernobyl", "Crips", "Dz7", "Labirinto", "P77", "Milicia", "Medellin", "Mare", "Crateva", "Distrito" }, 
        cooldown = 3600,
        lootTable = {
            { item = "WEAPON_PISTOL_MK2", min = 1, max = 1, chance = 10 },
            { item = "WEAPON_COMPACTRIFLE", min = 1, max = 1, chance = 10 },
            { item = "WEAPON_PISTOL_AMMO", min = 35, max = 75, chance = 50 },
            { item = "WEAPON_RIFLE_AMMO", min = 25, max = 65, chance = 40 },
            { item = "dollarsroll", min = 35000, max = 105000, chance = 100 }
        }
    },
    [6] = {
        name = "Maze Bank",
        coords = vec3(-235.21,-2001.16,24.68),
        radius = 100.0,
        time = 720,
        permissions = { "Admin", "Maonegra", "Bairro13", "Setor13", "Grota", "Chernobyl", "Crips", "Dz7", "Labirinto", "P77", "Milicia", "Medellin", "Mare", "Crateva", "Distrito" }, 
        cooldown = 3600,
        lootTable = {
            { item = "WEAPON_PISTOL_MK2", min = 1, max = 1, chance = 10 },
            { item = "WEAPON_COMPACTRIFLE", min = 1, max = 1, chance = 10 },
            { item = "WEAPON_PISTOL_AMMO", min = 35, max = 75, chance = 50 },
            { item = "WEAPON_RIFLE_AMMO", min = 25, max = 65, chance = 40 },
            { item = "dollarsroll", min = 35000, max = 105000, chance = 100 }
        }
    }
}