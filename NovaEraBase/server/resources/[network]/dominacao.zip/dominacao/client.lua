local Tunnel = module("vrp","lib/Tunnel")
local Proxy = module("vrp","lib/Proxy")
vRP = Proxy.getInterface("vRP")

-----------------------------------------------------------------------------------------------------------------------------------------
-- VARIÁVEIS
-----------------------------------------------------------------------------------------------------------------------------------------
local ActiveZoneId = nil
local AmIDominator = false 
local Blips = {} 
local LootProps = {} 
local Cooldowns = {}
local ZoneBarriers = {} 

-----------------------------------------------------------------------------------------------------------------------------------------
-- CONFIGURAÇÃO DE NOMES DE ARMAS
-----------------------------------------------------------------------------------------------------------------------------------------
local WeaponNames = {
    [tostring(GetHashKey("WEAPON_PISTOL_MK2"))] = "FIVE SEVEN",
    [tostring(GetHashKey("WEAPON_COMBATPISTOL"))] = "GLOCK",
    [tostring(GetHashKey("WEAPON_ASSAULTRIFLE"))] = "AK-47",
    [tostring(GetHashKey("WEAPON_CARBINERIFLE"))] = "M4A1",
    [tostring(GetHashKey("WEAPON_SPECIALCARBINE"))] = "G36",
    [tostring(GetHashKey("WEAPON_SMG"))] = "MP5",
    [tostring(GetHashKey("WEAPON_COMPACTRIFLE"))] = "AKS-74U",
    [tostring(GetHashKey("WEAPON_UNARMED"))] = "SOCO",
    [tostring(GetHashKey("WEAPON_RAMMED_BY_CAR"))] = "ATROPELADO",
    [tostring(GetHashKey("WEAPON_RUN_OVER_BY_CAR"))] = "ATROPELADO",
}

function GetWeaponName(hash)
    return WeaponNames[tostring(hash)] or "ARMA DESCONHECIDA"
end

-----------------------------------------------------------------------------------------------------------------------------------------
-- FUNÇÃO AUXILIAR: NO-CLIP
-----------------------------------------------------------------------------------------------------------------------------------------
function IsPlayerInNoClip(ped)
    if not IsEntityVisible(ped) then return true end
    if not GetEntityCollisonDisabled(ped) then
        if GetEntityHeightAboveGround(ped) > 5.0 and not IsPedFalling(ped) and not IsPedInParachuteFreeFall(ped) and not IsPedInAnyVehicle(ped, false) then
             -- return true 
        end
    else
        return true
    end
    return false
end

-----------------------------------------------------------------------------------------------------------------------------------------
-- DETECTOR DE KILLFEED + ZONA AMARELA
-----------------------------------------------------------------------------------------------------------------------------------------
local LastKillTime = 0 

AddEventHandler('gameEventTriggered', function(event, data)
    if event == "CEventNetworkEntityDamage" then
        local victim, attacker, victimDied, weaponHash = data[1], data[2], data[4], data[7]
        
        -- Verifica se Vítima e Atacante são Players
        if not IsEntityAPed(victim) or not IsPedAPlayer(victim) then return end
        if not IsEntityAPed(attacker) or not IsPedAPlayer(attacker) then return end
        
        if IsEntityDead(victim) then
            if GetGameTimer() - LastKillTime < 1000 then return end

            local insideZoneId = nil
            local killType = "NENHUMA"
            
            -- Verifica Zonas (Configuração fixa)
            for id, zone in pairs(Config.Zones) do
                local raioAmarelo = zone.radius + 100.0 -- 100 Metros extra de vigilância
                local dist = #(GetEntityCoords(victim) - zone.coords)
                
                -- Lógica de Prioridade
                if dist <= zone.radius then
                    insideZoneId = id
                    killType = "VERMELHA" -- Dentro da dominação
                    break
                elseif dist <= raioAmarelo then
                    insideZoneId = id
                    killType = "AMARELA" -- Na borda externa
                    break
                end
            end

            if insideZoneId then
                if attacker == PlayerPedId() then
                    LastKillTime = GetGameTimer()
                    
                    local attackerName = GetPlayerName(PlayerId())
                    local weaponName = GetWeaponName(weaponHash)
                    local pCoords = GetEntityCoords(PlayerPedId()) -- Coordenadas do Atirador
                    
                    local victimIndex = NetworkGetPlayerIndexFromPed(victim)
                    local victimName = GetPlayerName(victimIndex)
                    local victimSource = GetPlayerServerId(victimIndex)
                    
                    TriggerServerEvent("dominacao:KillFeed", attackerName, victimName, victimSource, weaponName, insideZoneId, pCoords, killType)
                end
            end
        end
    end
end)

RegisterNetEvent("dominacao:ShowKillFeed")
AddEventHandler("dominacao:ShowKillFeed", function(killer, killerId, victim, victimId, weapon, zoneId)
    -- Verifica se quem recebe a mensagem está perto da zona (apenas visualização)
    local zoneCfg = Config.Zones[zoneId]
    local ped = PlayerPedId()
    
    if zoneCfg then
        local dist = #(GetEntityCoords(ped) - zoneCfg.coords)
        -- Mostra se estiver perto da zona vermelha
        if dist <= (zoneCfg.radius + 200.0) then
            SendNUIMessage({
                action = "newKill",
                killer = killer,
                killerId = killerId,
                victim = victim,
                victimId = victimId,
                weapon = weapon
            })
        end
    end
end)

-----------------------------------------------------------------------------------------------------------------------------------------
-- THREAD PRINCIPAL (VISUAL PERMANENTE + INTERAÇÃO)
-----------------------------------------------------------------------------------------------------------------------------------------
Citizen.CreateThread(function()
    Citizen.Wait(1000)
    TriggerServerEvent("dominacao:RequestCooldowns")
    
    if not Config or not Config.Zones then return end

    -- 1. INICIALIZAÇÃO VISUAL PERMANENTE DAS ZONAS
    for id, zone in pairs(Config.Zones) do
        -- A) Criar Blip do Ícone (Estático)
        -- local blip = AddBlipForCoord(zone.coords)
        -- SetBlipSprite(blip, 303)
        -- SetBlipColour(blip, 0)
        -- SetBlipScale(blip, 0.8)
        -- SetBlipAsShortRange(blip, true)
        -- BeginTextCommandSetBlipName("STRING")
        -- AddTextComponentString("Dominação: "..zone.name)
        -- EndTextCommandSetBlipName(blip)
        
        -- -- B) Criar Blip do Raio (Círculo no Mapa) - PERMANENTE
        -- local radiusBlip = AddBlipForRadius(zone.coords, zone.radius)
        -- SetBlipColour(radiusBlip, 1) -- Cor Vermelha
        -- SetBlipAlpha(radiusBlip, 80)
        
        -- Guardar referências
        Blips[id] = { handle = blip, radiusHandle = radiusBlip }

        -- C) Iniciar Thread da Barreira Visual (Marker) - PERMANENTE
        Citizen.CreateThread(function()
            local raioAmarelo = zone.radius + 100.0 -- Zona Amarela é maior
            while true do
                local idle = 2000 
                local ped = PlayerPedId()
                local pCoords = GetEntityCoords(ped)
                
                -- Só desenha se estiveres perto (Otimização)
                if #(pCoords - zone.coords) < (raioAmarelo + 200.0) then
                    idle = 0
                    
                    -- ZONA VERMELHA (INTERNA)
                    DrawMarker(1, zone.coords.x, zone.coords.y, zone.coords.z - 30.0, 
                        0, 0, 0, 0, 0, 0, 
                        zone.radius * 2.0, zone.radius * 2.0, 100.0, 
                        255, 0, 0, 75, -- Vermelho
                        false, false, 2, false, false, false, false)

                    -- ZONA AMARELA (EXTERNA)
                    DrawMarker(1, zone.coords.x, zone.coords.y, zone.coords.z - 30.0, 
                        0, 0, 0, 0, 0, 0, 
                        raioAmarelo * 2.0, raioAmarelo * 2.0, 50.0, 
                        255, 255, 0, 30, -- Amarelo Transparente
                        false, false, 2, false, false, false, false)
                end
                Citizen.Wait(idle)
            end
        end)
    end

    -- 2. LOOP DE INTERAÇÃO (Para iniciar dominação)
    while true do
        local idle = 1000
        local ped = PlayerPedId()
        local pCoords = GetEntityCoords(ped)
        local serverTime = GetCloudTimeAsInt()

        if not ActiveZoneId then
            for id, zone in pairs(Config.Zones) do
                if not LootProps[id] then
                    local dist = #(pCoords - zone.coords)
                    if dist < 20.0 then
                        idle = 5
                        local isInCooldown = false
                        local cooldownTimeLeft = 0
                        if Cooldowns[id] and Cooldowns[id] > serverTime then
                            isInCooldown = true
                            cooldownTimeLeft = Cooldowns[id] - serverTime
                        end

                        DrawMarker(27, zone.coords.x, zone.coords.y, zone.coords.z - 0.95, 0,0,0, 0,0,0, 2.0,2.0,1.0, 255,0,0,150, false,false,2,false)
                        
                        if dist < 2.0 then
                            if isInCooldown then
                                local min = math.floor(cooldownTimeLeft / 60)
                                local sec = cooldownTimeLeft % 60
                                DrawText3D(zone.coords.x, zone.coords.y, zone.coords.z, "~r~Indisponível: " .. string.format("%02d:%02d", min, sec))
                            else
                                DrawText3D(zone.coords.x, zone.coords.y, zone.coords.z, "Pressiona [~r~ E ~w~] para DOMINAR ~y~"..zone.name)
                                if IsControlJustPressed(0, 38) then
                                    if GetEntityHealth(ped) > 101 then
                                        if IsPlayerInNoClip(ped) then
                                            TriggerEvent("Notify", "negado", "Impossível dominar assim!")
                                        else
                                            TriggerServerEvent("dominacao:TryStart", id)
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        else
            if AmIDominator then
                idle = 5
                if IsControlJustPressed(0, 168) then
                    TriggerServerEvent("dominacao:TryCancel", ActiveZoneId)
                end
            end
        end
        
        -- LOOP LOOT BOX
        for id, propData in pairs(LootProps) do
            if DoesEntityExist(propData.obj) then
                local lootCoords = GetEntityCoords(propData.obj)
                local dist = #(pCoords - lootCoords)
                if dist < 5.0 then
                    idle = 5
                    DrawText3D(lootCoords.x, lootCoords.y, lootCoords.z + 0.5, "Pressiona [~g~ E ~w~] para ABRIR LOOT")
                    if dist < 2.0 and IsControlJustPressed(0, 38) then
                        if GetEntityHealth(ped) > 101 then
                            if IsPlayerInNoClip(ped) then
                                TriggerEvent("Notify", "negado", "Sai do No-Clip para apanhar!")
                            else
                                local looting = true
                                local duration = Config.LootBox.openTime
                                local maxDist = Config.LootBox.maxDistance
                                local timePassed = 0
                                FreezeEntityPosition(ped, true)
                                vRP.playAnim(false, {Config.LootBox.anim.dict, Config.LootBox.anim.name}, true)
                                SendNUIMessage({ action = "startLoot", duration = duration })
                                while looting and timePassed < duration do
                                    Citizen.Wait(10)
                                    timePassed = timePassed + 10
                                    local currentCoords = GetEntityCoords(ped)
                                    if GetEntityHealth(ped) <= 101 then looting = false; TriggerEvent("Notify", "vermelho", "Morreste!") end
                                    if IsPlayerInNoClip(ped) then looting = false; TriggerEvent("Notify", "negado", "Cancelado.") end
                                    if IsControlJustPressed(0, 177) then looting = false; TriggerEvent("Notify", "aviso", "Cancelado.") end
                                    if #(currentCoords - lootCoords) > maxDist then looting = false; TriggerEvent("Notify", "negado", "Longe demais!") end
                                    DisableControlAction(0, 177, true)
                                end
                                SendNUIMessage({ action = "stopLoot" })
                                FreezeEntityPosition(ped, false)
                                vRP._stopAnim(false)
                                if looting and timePassed >= duration then
                                    TriggerServerEvent("dominacao:TryLootBox", id)
                                end
                            end
                        end
                    end
                end
            end
        end
        Citizen.Wait(idle)
    end
end)

-----------------------------------------------------------------------------------------------------------------------------------------
-- LÓGICA DE QUEM ESTÁ A DOMINAR (LOCAL)
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("dominacao:StartClientLogic")
AddEventHandler("dominacao:StartClientLogic", function(id, time)
    ActiveZoneId = id
    local zone = Config.Zones[id]
    local timeLeft = time

    Citizen.CreateThread(function()
        while ActiveZoneId == id and timeLeft > 0 do
            Citizen.Wait(1000)
            timeLeft = timeLeft - 1
            local ped = PlayerPedId()
            
            if GetEntityHealth(ped) <= 101 then 
                local killerSrc = nil
                local killerEntity = GetPedSourceOfDeath(ped)
                if killerEntity and IsEntityAPed(killerEntity) and IsPedAPlayer(killerEntity) then
                    killerSrc = GetPlayerServerId(NetworkGetPlayerIndexFromPed(killerEntity))
                end
                TriggerServerEvent("dominacao:Cancel", id, "Morreu", killerSrc) 
                ActiveZoneId = nil; AmIDominator = false; return 
            end
            
            if IsPlayerInNoClip(ped) then 
                TriggerServerEvent("dominacao:Cancel", id, "No-Clip detetado.", nil) 
                ActiveZoneId = nil; AmIDominator = false; return 
            end
            
            if #(GetEntityCoords(ped) - zone.coords) > zone.radius then 
                TriggerServerEvent("dominacao:Cancel", id, "Saíste da zona", nil) 
                ActiveZoneId = nil; AmIDominator = false; return 
            end
        end
    end)
end)

RegisterNetEvent("dominacao:ClientCancel")
AddEventHandler("dominacao:ClientCancel", function()
    ActiveZoneId = nil
    AmIDominator = false
end)

RegisterNetEvent("dominacao:UpdateCooldowns")
AddEventHandler("dominacao:UpdateCooldowns", function(newCooldowns)
    Cooldowns = newCooldowns
end)

-----------------------------------------------------------------------------------------------------------------------------------------
-- SPAWN DA CAIXA + LOG VISUAL + ANTI-STUCK
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("dominacao:SpawnLootProp")
AddEventHandler("dominacao:SpawnLootProp", function(id, coords)
    if LootProps[id] then 
        if DoesEntityExist(LootProps[id].obj) then DeleteEntity(LootProps[id].obj) end
        if LootProps[id].blip then RemoveBlip(LootProps[id].blip) end
    end

    local ped = PlayerPedId()
    if #(GetEntityCoords(ped) - coords) < 2.5 then
        SetEntityCoords(ped, coords.x, coords.y, coords.z + 2.0)
    end

    local model = GetHashKey(Config.LootBox.model)
    RequestModel(model)
    while not HasModelLoaded(model) do Citizen.Wait(10) end
    local obj = CreateObject(model, coords.x, coords.y, coords.z - 1.0, false, false, false)
    PlaceObjectOnGroundProperly(obj)
    FreezeEntityPosition(obj, true)
    
    local blip = AddBlipForEntity(obj)
    SetBlipSprite(blip, 587); SetBlipColour(blip, 2); SetBlipScale(blip, 0.8)
    BeginTextCommandSetBlipName("STRING"); AddTextComponentString("Loot Disponível"); EndTextCommandSetBlipName(blip)
    LootProps[id] = { obj = obj, blip = blip }
end)

RegisterNetEvent("dominacao:RemoveLootProp")
AddEventHandler("dominacao:RemoveLootProp", function(id)
    if LootProps[id] then
        if DoesEntityExist(LootProps[id].obj) then DeleteEntity(LootProps[id].obj) end
        if LootProps[id].blip then RemoveBlip(LootProps[id].blip) end
        LootProps[id] = nil
    end
end)

-----------------------------------------------------------------------------------------------------------------------------------------
-- SINCRONIZAÇÃO DE ESTADO (ÍCONE MAPA)
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("dominacao:SyncBlip")
AddEventHandler("dominacao:SyncBlip", function(id, ativo)
    if not Blips[id] then return end
    if ativo then
        SetBlipColour(Blips[id].handle, 1) -- Vermelho (Ativo)
    else
        SetBlipColour(Blips[id].handle, 0) -- Branco (Inativo)
    end
end)

-----------------------------------------------------------------------------------------------------------------------------------------
-- ATUALIZAÇÃO UI (NUI)
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("dominacao:UpdateUI")
AddEventHandler("dominacao:UpdateUI", function(status, data)
    if status and data then
        if data.isOwner then AmIDominator = true end
        SendNUIMessage({ 
            action = "show", zoneName = data.zoneName, group = data.group, 
            count = data.count, time = data.time, maxTime = data.maxTime, 
            timeString = data.timeString, isOwner = data.isOwner
        })
    else
        SendNUIMessage({ action = "hide" })
        AmIDominator = false
    end
end)

function DrawText3D(x,y,z,text)
    SetDrawOrigin(x, y, z, 0)
    SetTextFont(4); SetTextProportional(0); SetTextScale(0.35,0.35)
    SetTextColour(255,255,255,255); SetTextDropshadow(0, 0, 0, 0, 255)
    SetTextEdge(2, 0, 0, 0, 150); SetTextDropShadow(); SetTextOutline()
    SetTextEntry("STRING"); SetTextCentre(1); AddTextComponentString(text)
    DrawText(0.0, 0.0); ClearDrawOrigin()
end

-----------------------------------------------------------------------------------------------------------------------------------------
-- SINCRONIZAÇÃO BLIPS + BARREIRA VERMELHA + QUANDO A DOMINAÇÃO INICIA
-----------------------------------------------------------------------------------------------------------------------------------------
--[[RegisterNetEvent("dominacao:SyncBlip")
AddEventHandler("dominacao:SyncBlip", function(id, ativo)
    local zone = Config.Zones[id]
    if not zone then return end
    
    if ativo then
        -- 1. Blip Piscante
        SetBlipColour(Blips[id].handle, 1) 
        if not Blips[id].radiusHandle then
            local radiusBlip = AddBlipForRadius(zone.coords, zone.radius)
            SetBlipColour(radiusBlip, 1); SetBlipAlpha(radiusBlip, 100)
            Blips[id].radiusHandle = radiusBlip
            
            Citizen.CreateThread(function()
                local transparency = 100; local dir = "up"
                while Blips[id].radiusHandle and DoesBlipExist(Blips[id].radiusHandle) do
                    Citizen.Wait(40)
                    if dir == "up" then transparency = transparency + 2 if transparency >= 180 then dir = "down" end
                    else transparency = transparency - 2 if transparency <= 40 then dir = "up" end end
                    SetBlipAlpha(Blips[id].radiusHandle, transparency)
                end
            end)
        end

        -- 2. Barreira Vermelha Forte
        ZoneBarriers[id] = true
        Citizen.CreateThread(function()
            while ZoneBarriers[id] do
                local idle = 1000
                local ped = PlayerPedId()
                local pCoords = GetEntityCoords(ped)
                
                if #(pCoords - zone.coords) < (zone.radius + 200.0) then
                    idle = 0
                    -- AUMENTO DA ALTURA (z-index e Z scale) para parecer uma barreira real
                    DrawMarker(1, zone.coords.x, zone.coords.y, zone.coords.z - 30.0, 
                        0, 0, 0, 0, 0, 0, 
                        zone.radius * 2.0, zone.radius * 2.0, 100.0, -- Altura aumentada para 100.0
                        255, 0, 0, 100, -- Alpha ajustado para não cegar mas ser visivel
                        false, false, 2, false, false, false, false)
                end
                Citizen.Wait(idle)
            end
        end)
    else
        ZoneBarriers[id] = false
        SetBlipColour(Blips[id].handle, 0)
        if Blips[id].radiusHandle then RemoveBlip(Blips[id].radiusHandle); Blips[id].radiusHandle = nil end
    end
end) ]]


