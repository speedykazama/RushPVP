local Tunnel = module("vrp","lib/Tunnel")
local Proxy = module("vrp","lib/Proxy")
vRP = Proxy.getInterface("vRP")

-----------------------------------------------------------------------------------------------------------------------------------------
-- ESTADOS
-----------------------------------------------------------------------------------------------------------------------------------------
local ZoneState = {}
local LootState = {}
local ZoneCooldowns = {} 

-----------------------------------------------------------------------------------------------------------------------------------------
-- FUNÇÃO DE LOGS (DISCORD)
-----------------------------------------------------------------------------------------------------------------------------------------
function SendWebhook(title, message, color, customUrl)
    local url = customUrl or Config.Webhook
    if url == "" or url == nil or string.find(url, "COLOCA_O") then return end
    
    local embed = {
        {
            ["color"] = color,
            ["title"] = "**"..title.."**",
            ["description"] = message,
            ["footer"] = { ["text"] = "Sistema de Dominação • " .. os.date("%d/%m/%Y %H:%M:%S") },
        }
    }
    PerformHttpRequest(url, function(err, text, headers) end, 'POST', json.encode({username = "Dominação Logs", embeds = embed}), { ['Content-Type'] = 'application/json' })
end

function GetPlayerGroupFromList(Passport, permList)
    if not permList then return nil end
    if type(permList) == "string" then
        if vRP.HasGroup(Passport, permList) then return permList end
    elseif type(permList) == "table" then
        for _, group in pairs(permList) do
            if vRP.HasGroup(Passport, group) then return group end
        end
    end
    return nil
end

-----------------------------------------------------------------------------------------------------------------------------------------
-- EVENTOS
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("dominacao:RequestCooldowns")
AddEventHandler("dominacao:RequestCooldowns", function()
    local source = source
    TriggerClientEvent("dominacao:UpdateCooldowns", source, ZoneCooldowns)
end)

RegisterNetEvent("dominacao:TryStart")
AddEventHandler("dominacao:TryStart", function(zoneId)
    local source = source
    local Passport = vRP.Passport(source)
    local ZoneConfig = Config.Zones[zoneId]

    if not ZoneConfig then return end

    if ZoneCooldowns[zoneId] and os.time() < ZoneCooldowns[zoneId] then
        TriggerClientEvent("Notify", source, "negado", "Zona em recuperação.", 5000)
        return
    end

    if (ZoneState[zoneId] and ZoneState[zoneId].active) or (LootState[zoneId] and LootState[zoneId].active) then
        TriggerClientEvent("Notify", source, "vermelho", "Zona ocupada!", 5000)
        return
    end

    local perms = ZoneConfig.permissions or ZoneConfig.permission
    local myGroup = GetPlayerGroupFromList(Passport, perms)

    if not myGroup then
        TriggerClientEvent("Notify", source, "negado", "Sem permissão.", 5000)
        return
    end

    -- SUCESSO
    ZoneState[zoneId] = { active = true, dominator = source, time = ZoneConfig.time, currentGroup = myGroup }
    
    TriggerClientEvent("Notify", -1, "amarelo", "Dominação iniciada em: <b>"..ZoneConfig.name.."</b> pelos <b>"..myGroup.."</b>!", 10000)
    TriggerClientEvent("dominacao:SyncBlip", -1, zoneId, true) 
    TriggerClientEvent("dominacao:StartClientLogic", source, zoneId, ZoneConfig.time)
    
    SendWebhook("DOMINAÇÃO INICIADA", 
        "**Zona:** " .. ZoneConfig.name .. "\n**Jogador:** " .. Passport .. "\n**Facção:** " .. myGroup, 
        3066993)

    StartZoneThread(zoneId)
end)

RegisterNetEvent("dominacao:Cancel")
AddEventHandler("dominacao:Cancel", function(zoneId, motivo, killerSrc)
    local source = source
    if ZoneState[zoneId] and ZoneState[zoneId].dominator == source then
        CancelZone(zoneId, source, motivo, killerSrc)
    end
end)

RegisterNetEvent("dominacao:TryLootBox")
AddEventHandler("dominacao:TryLootBox", function(zoneId)
    local source = source
    local Passport = vRP.Passport(source)

    if LootState[zoneId] and LootState[zoneId].active then
        local cfg = Config.Zones[zoneId]
        
        local perms = cfg.permissions or cfg.permission
        if perms and not GetPlayerGroupFromList(Passport, perms) then
             TriggerClientEvent("Notify", source, "negado", "Sem chave!", 5000)
             return
        end

        local itemsReceived = 0
        local itemsLog = ""

        for _, loot in pairs(cfg.lootTable) do
            local chance = math.random(1, 100)
            if chance <= loot.chance then
                local amount = math.random(loot.min, loot.max)
                
                if vRP.GenerateItem then vRP.GenerateItem(Passport, loot.item, amount, true)
                elseif vRP.giveInventoryItem then vRP.giveInventoryItem(Passport, loot.item, amount, true)
                elseif vRP.GiveItem then vRP.GiveItem(Passport, loot.item, amount, true) end
                
                itemsReceived = itemsReceived + 1
                itemsLog = itemsLog .. amount .. "x " .. loot.item .. "\n"
            end
        end

        if itemsReceived > 0 then
            TriggerClientEvent("inventory:Update", source, "Backpack")
            TriggerClientEvent("Notify", source, "sucesso", "Loot recolhido!")
            TriggerClientEvent("Notify", -1, "verde", "O Loot da zona <b>"..cfg.name.."</b> foi recolhido.") 
            
            SendWebhook("BAÚ RECOLHIDO", 
                "**Zona:** " .. cfg.name .. "\n**Jogador:** " .. Passport .. "\n**Itens:**\n" .. itemsLog, 
                15105570)
        else
            TriggerClientEvent("Notify", source, "aviso", "A caixa estava vazia.")
            SendWebhook("BAÚ RECOLHIDO (VAZIO)", 
                "**Zona:** " .. cfg.name .. "\n**Jogador:** " .. Passport .. "\nAzar, caixa vazia.", 
                15105570)
        end

        RemoveLootBox(zoneId)
    else
        TriggerClientEvent("Notify", source, "negado", "Caixa inexistente.")
    end
end)

-----------------------------------------------------------------------------------------------------------------------------------------
-- KILLFEED (IDS REAIS + SEPARAÇÃO DE ZONAS)
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("dominacao:KillFeed")
AddEventHandler("dominacao:KillFeed", function(killerName, victimName, victimSource, weapon, zoneId, killerCoords, killType)
    local source = source
    
    -- IDs Reais
    local killerPassport = vRP.Passport(source) or source
    local victimPassport = "Desconhecido"
    if victimSource then
        local pVictim = vRP.Passport(victimSource)
        victimPassport = pVictim or victimSource
    end
 
    -- APENAS MOSTRA NO ECRÃ (UI) SE FOR NA ZONA VERMELHA ZONA AMARELA NÃO MOSTRA NO ECRÃ
    if killType == "VERMELHA" then
        TriggerClientEvent("dominacao:ShowKillFeed", -1, killerName, killerPassport, victimName, victimPassport, weapon, zoneId)
    end

    -- LOG NO DISCORD (DIFERENCIADO)
    local zoneName = "Desconhecida"
    if Config.Zones[zoneId] then zoneName = Config.Zones[zoneId].name end
    
    local coordsText = "N/A"
    local commandTP = "N/A"
    if killerCoords then
        coordsText = string.format("x: %.2f, y: %.2f, z: %.2f", killerCoords.x, killerCoords.y, killerCoords.z)
        commandTP = string.format("tpcds %.2f, %.2f, %.2f", killerCoords.x, killerCoords.y, killerCoords.z)
    end

    local titulo = "KILL - ZONA VERMELHA"
    local cor = 10181046 -- Vermelho
    local descExtra = ""

    if killType == "AMARELA" then
        titulo = "KILL - ZONA AMARELA (VIGILÂNCIA)"
        cor = 16776960 -- Amarelo
        descExtra = "\n\n⚠ **ATENÇÃO:** Morte na zona externa (Buffer).\nUse o comando para verificar se foi fora de RP."
    end

    local logContent = "**Zona:** " .. zoneName .. "\n" ..
                       "**Tipo:** " .. killType .. "\n" ..
                       "**Assassino:** " .. killerName .. " (ID: " .. killerPassport .. ")\n" ..
                       "**Vítima:** " .. victimName .. " (ID: " .. victimPassport .. ")\n" ..
                       "**Arma:** " .. weapon .. "\n" ..
                       "**Local (Coords):** `" .. coordsText .. "`\n" ..
                       "**Comando TP:** `" .. commandTP .. "`" .. 
                       descExtra

    SendWebhook(titulo, logContent, cor, Config.WebhookKill)
end)

-----------------------------------------------------------------------------------------------------------------------------------------
-- LÓGICA INTERNA
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("dominacao:TryCancel")
AddEventHandler("dominacao:TryCancel", function(zoneId)
    local source = source
    if ZoneState[zoneId] and ZoneState[zoneId].active and ZoneState[zoneId].dominator == source then
        CancelZone(zoneId, source, "Cancelado manualmente pelo líder", nil)
    end
end)

function StartZoneThread(id)
    Citizen.CreateThread(function()
        local cfg = Config.Zones[id]
        while ZoneState[id] and ZoneState[id].active and ZoneState[id].time > 0 do
            Citizen.Wait(1000)
            if ZoneState[id] then
                ZoneState[id].time = ZoneState[id].time - 1
                local dominator = ZoneState[id].dominator
                if dominator then
                    local currentGroup = ZoneState[id].currentGroup
                    local aliados = CountAlliesInZone(dominator, cfg, currentGroup)
                    local timeString = string.format("%02d:%02d", math.floor(ZoneState[id].time / 60), ZoneState[id].time % 60)
                    
                    TriggerClientEvent("dominacao:UpdateUI", dominator, true, { 
                        zoneName = cfg.name, group = currentGroup, count = aliados, 
                        time = ZoneState[id].time, maxTime = cfg.time, timeString = timeString, isOwner = true 
                    })
                end
                if ZoneState[id].time <= 0 then SpawnLootBox(id, dominator) end
            else break end
        end
    end)
end

function SpawnLootBox(id, lastDominator)
    if ZoneState[id] then
        if lastDominator then 
            TriggerClientEvent("dominacao:ClientCancel", lastDominator)
            TriggerClientEvent("dominacao:UpdateUI", lastDominator, false) 
            TriggerClientEvent("Notify", lastDominator, "sucesso", "Sucesso! A caixa apareceu.", 8000)
            
            local passport = vRP.Passport(lastDominator) or "Desconhecido"
            SendWebhook("DOMINAÇÃO FINALIZADA", "**Zona:** " .. Config.Zones[id].name .. "\n**Vencedor:** " .. passport .. "\nA caixa spawnou.", 3066993)
        end
        ZoneState[id] = nil
        TriggerClientEvent("dominacao:SyncBlip", -1, id, false)
    end
    
    local cfg = Config.Zones[id]
    if cfg.cooldown and cfg.cooldown > 0 then
        ZoneCooldowns[id] = os.time() + cfg.cooldown
        TriggerClientEvent("dominacao:UpdateCooldowns", -1, ZoneCooldowns)
    end

    LootState[id] = { active = true, time = Config.LootBox.timeToLoot }
    TriggerClientEvent("dominacao:SpawnLootProp", -1, id, Config.Zones[id].coords)

    Citizen.CreateThread(function()
        while LootState[id] and LootState[id].active and LootState[id].time > 0 do
            Citizen.Wait(1000)
            if LootState[id] then LootState[id].time = LootState[id].time - 1 end
        end
        if LootState[id] and LootState[id].active then 
            RemoveLootBox(id)
            SendWebhook("LOOT EXPIRADO", "**Zona:** " .. cfg.name .. "\nNinguém apanhou a caixa a tempo.", 15158332)
        end
    end)
end

function RemoveLootBox(id)
    if LootState[id] then LootState[id] = nil; TriggerClientEvent("dominacao:RemoveLootProp", -1, id) end
end

function CancelZone(id, source, motivo, killerSrc)
    local zoneName = Config.Zones[id].name
    local passport = vRP.Passport(source) or "Desconhecido"
    
    if ZoneState[id] then ZoneState[id] = nil end
    
    TriggerClientEvent("Notify", -1, "vermelho", "A dominação em <b>"..zoneName.."</b> foi cancelada.")
    TriggerClientEvent("dominacao:SyncBlip", -1, id, false)
    
    local msgLog = "**Zona:** " .. zoneName .. "\n**Dominador:** " .. passport .. "\n**Motivo:** " .. motivo
    if killerSrc then
        local killerPassport = vRP.Passport(killerSrc)
        msgLog = msgLog .. "\n**Assassino:** " .. (killerPassport or killerSrc)
    end

    SendWebhook("DOMINAÇÃO CANCELADA", msgLog, 15158332)

    if source then 
        TriggerClientEvent("Notify", source, "aviso", "Cancelado: "..motivo)
        TriggerClientEvent("dominacao:ClientCancel", source) 
        TriggerClientEvent("dominacao:UpdateUI", source, false) 
    end
end

function CountAlliesInZone(srcDominator, cfg, activeGroup)
    local count = 0
    local users = vRP.Players()
    for id, src in pairs(users) do
        local ped = GetPlayerPed(parseInt(src))
        local coords = GetEntityCoords(ped)
        if #(coords - cfg.coords) <= cfg.radius then
            local pPassport = vRP.Passport(parseInt(src))
            if vRP.HasGroup(pPassport, activeGroup) then count = count + 1 end
        end
    end
    return count
end

AddEventHandler("playerDropped", function()
    local source = source
    for id, state in pairs(ZoneState) do
        if state.active and state.dominator == source then CancelZone(id, source, "Desconectou", nil) end
    end
end)