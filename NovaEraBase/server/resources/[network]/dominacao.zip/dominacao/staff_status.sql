CREATE TABLE IF NOT EXISTS staff_status (
  passport INT(11) NOT NULL,
  status TINYINT(1) DEFAULT 0,
  PRIMARY KEY (passport)
);