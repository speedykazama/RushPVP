window.addEventListener('message', function(event) {
    let data = event.data;

    // UI DA DOMINAÇÃO
    if (data.action === "show") {
        $("#container").fadeIn();
        updateInfo(data);
    } 
    else if (data.action === "update") {
        updateInfo(data);
    } 
    else if (data.action === "hide") {
        $("#container").fadeOut();
    }
    
    // UI DA RODA DE LOOT
    else if (data.action === "startLoot") {
        $("#loader-container").fadeIn();
        startLootProgress(data.duration);
    }
    else if (data.action === "stopLoot") {
        $("#loader-container").fadeOut();
    }
});

function updateInfo(data) {
    $("#zoneName").text(data.zoneName || "ZONA");
    $("#groupName").text(data.group);
    $("#playerCount").text(data.count);
    $("#timeText").text(data.timeString);
    let percent = (data.time / data.maxTime) * 100;
    $("#progress").css("width", percent + "%");


    if (data.isOwner) {
        $("#cancel-info").show();
    } else {
        $("#cancel-info").hide();
    }
}

function startLootProgress(duration) {
    let percent = 0;
    $("#loaderPercent").text("0%");
    
    let interval = setInterval(() => {
        percent += 1;
        $("#loaderPercent").text(percent + "%");
        
        if (percent >= 100) {
            clearInterval(interval);
        }
    }, duration / 100);
}

window.addEventListener('message', function(event) {
    let data = event.data;

    // UI DA DOMINAÇÃO
    if (data.action === "show") {
        $("#container").fadeIn();
        updateInfo(data);
    } 
    else if (data.action === "update") {
        updateInfo(data);
    } 
    else if (data.action === "hide") {
        $("#container").fadeOut();
    }
    
    // UI DA RODA DE LOOT
    else if (data.action === "startLoot") {
        $("#loader-container").fadeIn();
        startLootProgress(data.duration);
    }
    else if (data.action === "stopLoot") {
        $("#loader-container").fadeOut();
    }

    // --- NOVA LÓGICA KILLFEED ---
    else if (data.action === "newKill") {
        addKillFeed(data.killer, data.killerId, data.victim, data.victimId, data.weapon);
    }
});

function addKillFeed(killer, killerId, victim, victimId, weapon) {
    // Formato: NOME (ID) killed NOME (ID) with ARMA
    let html = `
        <div class="kill-row">
            <span style="color:#fff">${killer}</span> <span style="color:#aaa; font-size: 12px;">(${killerId})</span>
            <span style="color:#666; margin: 0 5px;">MATOU</span>
            <span style="color:#fff">${victim}</span> <span style="color:#aaa; font-size: 12px;">(${victimId})</span>
            <span style="color:#666; margin: 0 5px;">COM</span>
            <span style="color:#ff4444">${weapon}</span>
        </div>
    `;

    let $element = $(html);
    $("#killfeed-container").append($element); // append adiciona em baixo

    // Remove automaticamente após 5 segundos
    setTimeout(() => {
        $element.css("animation", "fadeOutLeft 0.5s ease-out forwards"); // Animação de saída para a esquerda
        setTimeout(() => $element.remove(), 500);
    }, 5000);
}

// ... Restante das tuas funções (updateInfo, startLootProgress) mantêm-se iguais ...
function updateInfo(data) {
    $("#zoneName").text(data.zoneName || "ZONA");
    $("#groupName").text(data.group);
    $("#playerCount").text(data.count);
    $("#timeText").text(data.timeString);
    let percent = (data.time / data.maxTime) * 100;
    $("#progress").css("width", percent + "%");


    if (data.isOwner) {
        $("#cancel-info").show();
    } else {
        $("#cancel-info").hide();
    }
}

function startLootProgress(duration) {
    let percent = 0;
    $("#loaderPercent").text("0%");
    
    let interval = setInterval(() => {
        percent += 1;
        $("#loaderPercent").text(percent + "%");
        
        if (percent >= 100) {
            clearInterval(interval);
        }
    }, duration / 100);
}
