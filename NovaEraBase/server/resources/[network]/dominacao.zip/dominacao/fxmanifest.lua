fx_version 'cerulean'
game 'gta5'

author 'Russo'
description 'Sistema Avançado de Dominação e Loot'
version '1.0.0'
contact 'zeamofc'

shared_scripts {
    '@vrp/lib/utils.lua',
    'config.lua'
}

ui_page 'nui/ui.html'

files {
    'nui/ui.html',
    'nui/style.css',
    'nui/script.js'
}

client_script 'client.lua'
server_script 'server.lua'

dependency 'vrp'