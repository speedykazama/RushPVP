-----------------------------------------------------------------------------------------------------------------------------------------
-- CABEÇALHO ANTI-CRASH (ESSENCIAL)
-----------------------------------------------------------------------------------------------------------------------------------------
_G.module = function(resource, path)
    if not path then path = resource resource = "vrp" end
    local file = LoadResourceFile(resource, path .. ".lua")
    if file then
        local func, err = load(file, resource .. "/" .. path .. ".lua")
        if not func then print(err) return nil end
        return func()
    else
        print("^1[ERRO] Falha ao carregar modulo: " .. resource .. "/" .. path .. "^7")
        return nil
    end
end

if not async then _G.async = function(f) Citizen.CreateThread(f) end end
-----------------------------------------------------------------------------------------------------------------------------------------

local Tunnel = module("vrp","lib/Tunnel")
local Proxy = module("vrp","lib/Proxy")
vRP = Proxy.getInterface("vRP")

Tunnel.bindInterface(GetCurrentResourceName(), {})
Proxy.addInterface(GetCurrentResourceName(), {})

local activeEvent = false

-----------------------------------------------------------------------------------------------------------------------------------------
-- LÓGICA DE INÍCIO
-----------------------------------------------------------------------------------------------------------------------------------------
function StartEventLogic()
    activeEvent = true
    
    local players = vRP.Players()
    local hostSource = nil
    for _, src in pairs(players) do
        hostSource = parseInt(src)
        break
    end

    if hostSource then
        TriggerClientEvent("carroforte:InitHost", hostSource)
        TriggerClientEvent("Notify", -1, "importante", Config.Messages.start, 15000)
        print("^2[CARRO-FORTE] Evento Iniciado (Host: "..hostSource..")^7")
    else
        activeEvent = true
        print("^1[CARRO-FORTE] Falha: Sem jogadores para ser host.^7")
    end
end

RegisterCommand(Config.Command, function(source, args)
    local Passport = vRP.Passport(source)
    if Passport and vRP.HasGroup(Passport, "Admin", 1) then
        if not activeEvent then
            StartEventLogic()
        else
            TriggerClientEvent("Notify", source, "negado", "Já existe um evento a decorrer.")
        end
    end
end)

-----------------------------------------------------------------------------------------------------------------------------------------
-- SINCRONIZAÇÃO
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("carroforte:ShareTruckInfo")
AddEventHandler("carroforte:ShareTruckInfo", function(netId)
    TriggerClientEvent("carroforte:SetBlip", -1, netId)
end)

RegisterNetEvent("carroforte:SyncLoot")
AddEventHandler("carroforte:SyncLoot", function(coords)
    activeEvent = false
    TriggerClientEvent("Notify", -1, "sucesso", "O Carro-Forte foi arrombado!")
    TriggerClientEvent("carroforte:SpawnLootClient", -1, coords)
end)

RegisterNetEvent("carroforte:SyncFail")
AddEventHandler("carroforte:SyncFail", function()
    activeEvent = false
    TriggerClientEvent("Notify", -1, "aviso", "O Carro-Forte escapou!")
    TriggerClientEvent("carroforte:RemoveBlip", -1)
end)

RegisterNetEvent("carroforte:Payment")
AddEventHandler("carroforte:Payment", function()
    local source = source
    local Passport = vRP.Passport(source)
    if Passport then
        local amount = math.random(Config.MoneyPerBag.min, Config.MoneyPerBag.max)
        
        if vRP.GenerateItem then vRP.GenerateItem(Passport, Config.ItemName, amount, true)
        elseif vRP.giveInventoryItem then vRP.giveInventoryItem(Passport, Config.ItemName, amount, true) end
        
        TriggerClientEvent("inventory:Update", source, "Backpack")
        TriggerClientEvent("Notify", source, "sucesso", "Recebeste $"..amount)
    end
end)

-----------------------------------------------------------------------------------------------------------------------------------------
-- TIMER AUTOMÁTICO (3 HORAS)
-----------------------------------------------------------------------------------------------------------------------------------------
Citizen.CreateThread(function()
    Citizen.Wait(10000) -- Inicia 10 seg após ligar o servidor
    
    while true do
        if not activeEvent then
            StartEventLogic()
        end
        
        -- Espera 3 Horas
        Citizen.Wait(3 * 60 * 60 * 1000) 
    end
end)