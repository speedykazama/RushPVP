Config = {}

-- Comando para iniciar (Admin)
Config.Command = "carroforte"

-- Modelo do Carro e dos Guardas
Config.TruckModel = "stockade"
Config.GuardModel = "s_m_m_security_01"
Config.GuardWeapon = "WEAPON_CARBINERIFLE"

-- Rota (Ponto A -> Ponto B)
Config.SpawnLocation = vector3(227.1,210.51,105.53) -- Banco Central (Exemplo)
Config.Destination = vector3(-114.65, 6461.64, 31.43) -- Paleto Bay (Exemplo)

-- Loot (Recompensa)
Config.LootAmount = 15 -- Quantos sacos caem no chão?
Config.MoneyPerBag = { min = 5000, max = 15000 } -- Valor de dinheiro sujo por saco
Config.ItemName = "dollarsroll" -- Nome do item na tua base (dinheirosujo, dirty_money, etc)

-- Mensagens
Config.Messages = {
    start = "O Carro-Forte saiu do Banco Central! Intercepta-o antes que chegue a Paleto Bay.",
    success = "O Carro-Forte foi arrombado! Apanha o dinheiro!",
    fail = "O Carro-Forte chegou ao destino em segurança. Missão falhada."
}