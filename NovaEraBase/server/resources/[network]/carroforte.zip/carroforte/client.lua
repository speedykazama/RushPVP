-----------------------------------------------------------------------------------------------------------------------------------------
-- CABEÇALHO ANTI-CRASH
-----------------------------------------------------------------------------------------------------------------------------------------
local function module(resource, path)
    if not path then path = resource resource = "vrp" end
    local file = LoadResourceFile(resource, path .. ".lua")
    if file then
        local func, err = load(file, resource .. "/" .. path .. ".lua")
        if not func then print(err) return nil end
        return func()
    else
        print("^1[ERRO] Falha ao carregar modulo: " .. resource .. "/" .. path .. "^7")
        return nil
    end
end

local Tunnel = module("vrp","lib/Tunnel")
local Proxy = module("vrp","lib/Proxy")
vRP = Proxy.getInterface("vRP")

Tunnel.bindInterface(GetCurrentResourceName(), {})

local isHost = false
local truckEntity = nil
local blip = nil
local lootProps = {}
local isLooting = false 

-----------------------------------------------------------------------------------------------------------------------------------------
-- EVENTOS DE INICIAÇÃO
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("carroforte:InitHost")
AddEventHandler("carroforte:InitHost", function()
    isHost = true
    
    local mHash = GetHashKey(Config.TruckModel)
    local pHash = GetHashKey(Config.GuardModel)
    RequestModel(mHash); while not HasModelLoaded(mHash) do Citizen.Wait(10) end
    RequestModel(pHash); while not HasModelLoaded(pHash) do Citizen.Wait(10) end

    truckEntity = CreateVehicle(mHash, Config.SpawnLocation.x, Config.SpawnLocation.y, Config.SpawnLocation.z, 0.0, true, true)
    
    local netId = NetworkGetNetworkIdFromEntity(truckEntity)
    SetNetworkIdCanMigrate(netId, true)
    SetVehicleOnGroundProperly(truckEntity)
    SetVehicleDoorsLocked(truckEntity, 2)
    SetEntityHealth(truckEntity, 3000)
    SetVehicleTyresCanBurst(truckEntity, true)

    local driver = CreatePedInsideVehicle(truckEntity, 4, pHash, -1, true, false)
    SetPedArmour(driver, 100)
    GiveWeaponToPed(driver, GetHashKey(Config.GuardWeapon), 250, false, true)
    TaskVehicleDriveToCoordLongrange(driver, truckEntity, Config.Destination.x, Config.Destination.y, Config.Destination.z, 30.0, 2883621, 10.0)

    local guard = CreatePedInsideVehicle(truckEntity, 4, pHash, 0, true, false)
    SetPedArmour(guard, 100)
    GiveWeaponToPed(guard, GetHashKey(Config.GuardWeapon), 250, false, true)
    TaskCombatPed(guard, PlayerPedId(), 0, 16)

    TriggerServerEvent("carroforte:ShareTruckInfo", netId)
    MonitorTruckHost()
end)

RegisterNetEvent("carroforte:SetBlip")
AddEventHandler("carroforte:SetBlip", function(netId)
    local timeout = 0
    while not NetworkDoesNetworkIdExist(netId) and timeout < 100 do
        Citizen.Wait(100)
        timeout = timeout + 1
    end

    local vehicle = NetworkGetEntityFromNetworkId(netId)
    if DoesEntityExist(vehicle) then
        if DoesBlipExist(blip) then RemoveBlip(blip) end
        blip = AddBlipForEntity(vehicle)
        SetBlipSprite(blip, 67); SetBlipColour(blip, 1); SetBlipScale(blip, 1.0); SetBlipRoute(blip, true)
        BeginTextCommandSetBlipName("STRING"); AddTextComponentString("Carro Forte"); EndTextCommandSetBlipName(blip)
    end
end)

RegisterNetEvent("carroforte:RemoveBlip")
AddEventHandler("carroforte:RemoveBlip", function()
    if DoesBlipExist(blip) then RemoveBlip(blip) end
end)

function MonitorTruckHost()
    Citizen.CreateThread(function()
        while isHost do
            Citizen.Wait(1000)
            if not DoesEntityExist(truckEntity) then
                isHost = false; TriggerServerEvent("carroforte:SyncFail"); break
            end

            local health = GetEntityHealth(truckEntity)
            local doorOpen = GetVehicleDoorAngleRatio(truckEntity, 2) > 0.1 or GetVehicleDoorAngleRatio(truckEntity, 3) > 0.1

            if health <= 0 or doorOpen then
                TriggerServerEvent("carroforte:SyncLoot", GetEntityCoords(truckEntity))
                isHost = false; break
            end

            if #(GetEntityCoords(truckEntity) - Config.Destination) < 15.0 then
                TriggerServerEvent("carroforte:SyncFail")
                DeleteEntity(truckEntity)
                isHost = false; break
            end
        end
    end)
end

RegisterNetEvent("carroforte:SpawnLootClient")
AddEventHandler("carroforte:SpawnLootClient", function(coords)
    if DoesBlipExist(blip) then RemoveBlip(blip) end
    local model = GetHashKey("prop_money_bag_01")
    RequestModel(model); while not HasModelLoaded(model) do Citizen.Wait(10) end

    for i = 1, Config.LootAmount do
        local x = coords.x + math.random(-4, 4)
        local y = coords.y + math.random(-4, 4)
        local z = coords.z
        local found, zPos = GetGroundZFor_3dCoord(x, y, z + 5.0, 0)
        if found then z = zPos end

        local obj = CreateObject(model, x, y, z, false, false, false)
        PlaceObjectOnGroundProperly(obj); FreezeEntityPosition(obj, true)
        table.insert(lootProps, obj)
    end
    LootCollectionThread()
end)

-----------------------------------------------------------------------------------------------------------------------------------------
-- SISTEMA DE APANHAR (COM PROTEÇÃO ANTI-NC)
-----------------------------------------------------------------------------------------------------------------------------------------
function LootCollectionThread()
    Citizen.CreateThread(function()
        while #lootProps > 0 do
            local idle = 1000
            local ped = PlayerPedId()
            local pCoords = GetEntityCoords(ped)
            
            for k, obj in pairs(lootProps) do
                if DoesEntityExist(obj) then
                    local oCoords = GetEntityCoords(obj)
                    if #(pCoords - oCoords) < 1.5 then
                        idle = 5
                        
                        if not isLooting then
                            DrawText3D(oCoords.x, oCoords.y, oCoords.z + 0.5, "~g~[E]~w~ PEGAR")
                            
                            if IsControlJustPressed(0, 38) then
                                -- >>>>>>>>>> ZONA DE SEGURANÇA (VERIFICAÇÕES) <<<<<<<<<<
                                
                                -- 1. INVISÍVEL / NC (A maioria dos NC deixa o player invisivel)
                                if not IsEntityVisible(ped) then
                                    TriggerEvent("Notify", source, "negado", "Não podes apanhar estando em NC (Invisível)!")

                                -- 2. VOAR (Verifica se está a mais de 1 metro do chão)
                                elseif GetEntityHeightAboveGround(ped) > 1.0 then
                                    TriggerEvent("Notify", source, "negado", "Tens de ter os pés no chão!")

                                -- 3. VEÍCULO
                                elseif IsPedInAnyVehicle(ped, false) then
                                    TriggerEvent("Notify", source, "negado", "Sai do veículo para apanhar!")
                                
                                -- 4. MORTO
                                elseif GetEntityHealth(ped) <= 101 then
                                    -- Morto não faz nada
                                    
                                -- 5. ATTACHED (Colo/Algemado)
                                elseif IsEntityAttached(ped) then
                                    TriggerEvent("Notify", source, "negado", "Não podes fazer isso agora!")

                                -- 6. RAGDOLL (Caído)
                                elseif IsPedRagdoll(ped) then
                                    -- Ragdoll não faz nada
                                    
                                else
                                    -- SUCESSO: PASSOU EM TODOS OS TESTES
                                    isLooting = true 
                                    
                                    FreezeEntityPosition(ped, true)
                                    TaskStartScenarioInPlace(ped, "CODE_HUMAN_MEDIC_KNEEL", 0, true)
                                    
                                    -- Barra de Progresso
                                    DrawProgressBar(5000, "A RECOLHER DINHEIRO...")
                                    
                                    ClearPedTasks(ped)
                                    FreezeEntityPosition(ped, false)
                                    TriggerServerEvent("carroforte:Payment")
                                    
                                    DeleteEntity(obj)
                                    table.remove(lootProps, k)
                                    
                                    isLooting = false
                                end
                            end
                        end
                    end
                else table.remove(lootProps, k) end
            end
            Citizen.Wait(idle)
        end
    end)
end

-----------------------------------------------------------------------------------------------------------------------------------------
-- FUNÇÕES VISUAIS
-----------------------------------------------------------------------------------------------------------------------------------------
function DrawText3D(x,y,z,text)
    SetDrawOrigin(x, y, z, 0); SetTextFont(4); SetTextProportional(0); SetTextScale(0.35,0.35); SetTextColour(255,255,255,255); SetTextDropshadow(0, 0, 0, 0, 255); SetTextEdge(2, 0, 0, 0, 150); SetTextDropShadow(); SetTextOutline(); SetTextEntry("STRING"); SetTextCentre(1); AddTextComponentString(text); DrawText(0.0, 0.0); ClearDrawOrigin();
end

function DrawProgressBar(time, text)
    local timer = 0
    local max = time
    TriggerEvent("progress", time, text)
    while timer < max do
        Citizen.Wait(0)
        timer = timer + 10
        local percent = (timer / max) * 100
        local w = percent / 100
        DrawRect(0.5, 0.93, 0.2, 0.03, 0, 0, 0, 150)
        DrawRect(0.5 - (0.1 * (1 - w)), 0.93, 0.2 * w, 0.03, 50, 205, 50, 200)
        SetTextFont(4); SetTextScale(0.34, 0.34); SetTextColour(255, 255, 255, 255); SetTextCentre(true); SetTextEntry("STRING"); AddTextComponentString(text); DrawText(0.5, 0.90)
    end
end