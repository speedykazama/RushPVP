fx_version 'cerulean'
game 'gta5'

author 'Russo'
description 'Roubo a Carro Forte'
version '1.0.0'

shared_scripts {
    '@vrp/lib/utils.lua',
    'config.lua'
}

client_script 'client.lua'
server_script 'server.lua'