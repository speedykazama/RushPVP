-----------------------------------------------------------------------------------------------------------------------------------------
-- VRP
-----------------------------------------------------------------------------------------------------------------------------------------
local Tunnel = module("vrp","lib/Tunnel")
-----------------------------------------------------------------------------------------------------------------------------------------
-- CONNECTION
-----------------------------------------------------------------------------------------------------------------------------------------
vSERVER = Tunnel.getInterface("pdm")
-----------------------------------------------------------------------------------------------------------------------------------------
-- VARIABLES
-----------------------------------------------------------------------------------------------------------------------------------------
local Mount = nil
local Camera = nil
local LastModel = ""
-----------------------------------------------------------------------------------------------------------------------------------------
-- CAMERAACTIVE
-----------------------------------------------------------------------------------------------------------------------------------------
function CameraActive()
	if DoesCamExist(Camera) then
		RenderScriptCams(false,false,0,false,false)
		SetCamActive(Camera,false)
		DestroyCam(Camera,false)
		Camera = nil
	end

	Camera = CreateCam("DEFAULT_SCRIPTED_CAMERA",true)
	SetCamCoord(Camera,SpawnVehicleCam.x,SpawnVehicleCam.y,SpawnVehicleCam.z + 0.5)
	RenderScriptCams(true,true,100,true,true)
	SetCamRot(Camera,0.0,0.0,SpawnVehicleCam.w)
	SetCamActive(Camera,true)
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- PDM:OPEN
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNetEvent("pdm:Open")
AddEventHandler("pdm:Open",function()
	if DoesEntityExist(Mount) then
		DeleteEntity(Mount)
	end

	local Ped = PlayerPedId()
	if not LocalPlayer["state"]["Buttons"] and not LocalPlayer["state"]["Commands"] and GetEntityHealth(Ped) > 100 then
		CameraActive()
		SetNuiFocus(true,true)
		SetCursorLocation(0.5,0.5)
		TriggerEvent("dynamic:closeSystem")
		SendNUIMessage({ name = "Open", payload = VehicleGlobal() })
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- CLOSE
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNUICallback("Close",function(Data,Callback)
	SetNuiFocus(false,false)
	SetCursorLocation(0.5,0.5)

	if DoesEntityExist(Mount) then
		DeleteEntity(Mount)
	end

	if DoesCamExist(Camera) then
		RenderScriptCams(false,false,0,false,false)
		SetCamActive(Camera,false)
		DestroyCam(Camera,false)
		Camera = nil
	end

	Callback("Ok")
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- MOUNT
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNUICallback("Mount",function(Data,Callback)
	if LoadModel(Data) and LastModel ~= Data then
		if DoesEntityExist(Mount) then
			DeleteEntity(Mount)
		end

		Mount = CreateVehicle(Data,SpawnVehicle.x,SpawnVehicle.y,SpawnVehicle.z,SpawnVehicle.w,false,false)
		SetVehicleNumberPlateText(Mount,NamePlate)
		SetEntityCollision(Mount,false,false)
		FreezeEntityPosition(Mount,true)
		SetEntityInvincible(Mount,true)
		SetVehicleDirtLevel(Mount,0.0)
		SetModelAsNoLongerNeeded(Data)
		LastModel = Data
	end

	Callback("Ok")
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- BUY
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNUICallback("Buy",function(Data,Callback)
	vSERVER.Buy(Data)

	Callback("Ok")
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- ROTATE
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNUICallback("Rotate",function(Data,Callback)
	if DoesEntityExist(Mount) then
		if Data == "Left" then
			SetEntityHeading(Mount,GetEntityHeading(Mount) - 5)
		else
			SetEntityHeading(Mount,GetEntityHeading(Mount) + 5)
		end
	end

	Callback("Ok")
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- DRIVE
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterNUICallback("Drive",function(Data,Callback)
	if vSERVER.CheckDrive() then
		SetNuiFocus(false,false)
		SetCursorLocation(0.5,0.5)

		if LoadModel(Data) then
			if DoesEntityExist(Mount) then
				DeleteEntity(Mount)
			end

			Mount = CreateVehicle(Data,DriveIn.x,DriveIn.y,DriveIn.z,DriveIn.w,10,0,1)
			SetEntityHeading(Mount,DriveIn.w)

			SetVehicleModKit(Mount,0)
			ToggleVehicleMod(Mount,18,true)
			SetVehicleExtraColours(Mount,147,147)
			SetVehicleMod(Mount,11,GetNumVehicleMods(Mount,11) - 1,false)
			SetVehicleMod(Mount,12,GetNumVehicleMods(Mount,12) - 1,false)
			SetVehicleMod(Mount,13,GetNumVehicleMods(Mount,13) - 1,false)
			SetVehicleMod(Mount,15,GetNumVehicleMods(Mount,15) - 1,false)

			SetVehicleNumberPlateText(Mount,NamePlate)
			SetPedIntoVehicle(PlayerPedId(),Mount,-1)
			SetEntityInvincible(Mount,true)
			SetModelAsNoLongerNeeded(Data)

			LocalPlayer["state"]:set("Commands",true,true)
			LocalPlayer["state"]:set("TestDrive",true,false)

			while true do
				local Ped = PlayerPedId()

				if not DoesEntityExist(Mount) or not IsPedInAnyVehicle(Ped) then
					vSERVER.RemoveDrive()
					SetEntityCoords(Ped,DriveOut.x,DriveOut.y,DriveOut.z,DriveOut.w)

					LocalPlayer["state"]:set("Commands",false,true)
					LocalPlayer["state"]:set("TestDrive",false,false)

					if DoesEntityExist(Mount) then
						DeleteEntity(Mount)
					end

					break
				end

				Wait(200)
			end
		end
	end

	Callback("Ok")
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- VARIABLES
-----------------------------------------------------------------------------------------------------------------------------------------
local initVehicles = {}
local vehicleRotationData = {}
-----------------------------------------------------------------------------------------------------------------------------------------
-- VEHICLES
-----------------------------------------------------------------------------------------------------------------------------------------
local Vehicles = {
    {
        ["coords"] = vector3(-326.26,-1369.95,31.87),
        ["heading"] = 272.13,
        ["model"] = "BCs_HpCkl22",
        ["distance"] = 50,
        ["rotationPoint"] = vector3(-326.26,-1369.95,32.35),
        ["rotationSpeed"] = 0.03,
        ["color"] = {primary = 28, secondary = 28}
    },
    {
        ["coords"] = vector3(-319.55, -1360.44, 31.6),
        ["heading"] = 272.13,
        ["model"] = "BCs_Psrrauh",
        ["distance"] = 30,
        ["rotationPoint"] = vector3(-319.55, -1360.44, 31.88),
        ["rotationSpeed"] = 0.03,
        ["color"] = {primary = 111, secondary = 111}
    },
    {
        ["coords"] = vector3(-332.04, -1380.29, 31.86),
        ["heading"] = 272.13,
        ["model"] = "BCs_PsRrv2k18",
        ["distance"] = 30,
        ["rotationPoint"] = vector3(-332.04, -1380.29, 31.86),
        ["rotationSpeed"] = 0.03,
        ["color"] = {primary = 0, secondary = 0}
    },
    {
        ["coords"] = vector3(-319.83, -1381.93, 31.59),
        ["heading"] = 272.13,
        ["model"] = "BCs_PsBxw7",
        ["distance"] = 30,
        ["rotationPoint"] = vector3(-319.83, -1381.93, 31.98),
        ["rotationSpeed"] = 0.03,
        ["color"] = {primary = 111, secondary = 111}
    },
    {
        ["coords"] = vector3(-333.27, -1357.91, 31.45),
        ["heading"] = 272.13,
        ["model"] = "BCs_PsB81ghr",
        ["distance"] = 30,
        ["rotationPoint"] = vector3(-333.27, -1357.91, 31.45),
        ["rotationSpeed"] = 0.03,
        ["color"] = {primary = 0, secondary = 0}
    }
}
-----------------------------------------------------------------------------------------------------------------------------------------
-- THREADVEHICLES
-----------------------------------------------------------------------------------------------------------------------------------------
Citizen.CreateThread(function()
    while true do
        local ped = PlayerPedId()
        local coords = GetEntityCoords(ped)

        for k, v in pairs(Vehicles) do
            local distance = #(coords - v["coords"])
            if distance <= v["distance"] then
                if initVehicles[k] == nil then
                    local mHash = GetHashKey(v["model"])

                    RequestModel(mHash)
                    while not HasModelLoaded(mHash) do
                        Citizen.Wait(1)
                    end

                    if HasModelLoaded(mHash) then
                        initVehicles[k] = CreateVehicle(mHash, v["coords"], v["heading"], false, false)
                        SetVehicleNumberPlateText(initVehicles[k], "PDMSPORT")
                        FreezeEntityPosition(initVehicles[k], true)
                        SetVehicleDoorsLocked(initVehicles[k], 2)
                        SetModelAsNoLongerNeeded(mHash)

                        SetVehicleColours(initVehicles[k], v["color"].primary, v["color"].secondary)
                        
                        vehicleRotationData[k] = {
                            entity = initVehicles[k],
                            rotationPoint = v["rotationPoint"],
                            rotationSpeed = v["rotationSpeed"]
                        }
                    end
                end
            else
                if initVehicles[k] then
                    if DoesEntityExist(initVehicles[k]) then
                        DeleteEntity(initVehicles[k])
                        initVehicles[k] = nil
                        vehicleRotationData[k] = nil
                    end
                end
            end
        end

        Citizen.Wait(1000)
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        for k, data in pairs(vehicleRotationData) do
            local vehicle = data.entity
            local rotationPoint = data.rotationPoint
            local rotationSpeed = data.rotationSpeed
            local currentTime = GetGameTimer()
            local rotation = 0.1 * math.pi * (currentTime / 75) * rotationSpeed
            local offsetX = math.cos(rotation) * 0.1
            local offsetY = math.sin(rotation) * 0.1
            SetEntityCoordsNoOffset(vehicle, rotationPoint.x + offsetX, rotationPoint.y + offsetY, rotationPoint.z, true, true, true)
            SetEntityHeading(vehicle, (rotation * 180.0 / math.pi) + 0.1)
        end
    end
end)