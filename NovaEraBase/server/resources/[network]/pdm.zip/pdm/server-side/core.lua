-----------------------------------------------------------------------------------------------------------------------------------------
-- VRP
-----------------------------------------------------------------------------------------------------------------------------------------
local Tunnel = module("vrp","lib/Tunnel")
local Proxy = module("vrp","lib/Proxy")
vRP = Proxy.getInterface("vRP")
-----------------------------------------------------------------------------------------------------------------------------------------
-- CONNECTION
-----------------------------------------------------------------------------------------------------------------------------------------
Creative = {}
Tunnel.bindInterface("pdm",Creative)
vCLIENT = Tunnel.getInterface("pdm")
-----------------------------------------------------------------------------------------------------------------------------------------
-- VARIABLES
-----------------------------------------------------------------------------------------------------------------------------------------
local Active = {}
-----------------------------------------------------------------------------------------------------------------------------------------
-- VERIFY
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.Verify()
	local source = source
	local Passport = vRP.Passport(source)
	if Passport then
		if vRP.GetFine(Passport) > 0 then
			TriggerClientEvent("Notify",source,"amarelo","Você possui multas pendentes.",10000)
			return false
		end

		if exports["hud"]:Wanted(Passport,source) and exports["hud"]:Reposed(Passport) then
			return false
		end
	end

	return true
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- GETBESTVEHICLETICKET
-----------------------------------------------------------------------------------------------------------------------------------------
local function GetBestVehicleTicket(Passport)
    for item, value in pairs(VehicleTicketValues) do
        if vRP.ConsultItem(Passport, item, 1) then
            return item, value
        end
    end
    return nil, 0
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- BUY
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.Buy(Name)
    local source = source
    local Passport = vRP.Passport(source)

    if not Active[Passport] and Passport then
        Active[Passport] = true

        if VehicleMode(Name) ~= "Work" then
            local Price = VehiclePrice(Name)
            local Gemstone = VehicleGems(Name)

            local MaxVehicles = MaxVehiclePadrao

            if vRP.HasGroup(Passport,"PremiumPrata") then
                MaxVehicles = MaxVehicles + MaxVehiclePremiumPrata
            elseif vRP.HasGroup(Passport,"PremiumOuro") then
                MaxVehicles = MaxVehicles + MaxVehiclePremiumOuro
            elseif vRP.HasGroup(Passport,"PremiumPlatina") then
                MaxVehicles = MaxVehicles + MaxVehiclePremiumPlatina
            end

            local Vehicles = exports["oxmysql"]:query_async(
                "SELECT vehicle, COUNT(vehicle) AS countVehicle FROM vehicles WHERE work = 'false' AND Passport = @Passport GROUP BY vehicle ORDER BY countVehicle DESC;",
                { Passport = Passport }
            )

            if #Vehicles >= MaxVehicles then
                TriggerClientEvent("Notify",source,"azul","Atingiu o número máximo de veículos em sua garagem!",8000)
                TriggerClientEvent("Notify",source,"azul","<b>Você Possui: </b>"..#Vehicles.." Veículos<br><b>Máximo: </b>"..MaxVehicles,8000)
                Active[Passport] = nil
                return
            end

            if VehicleMode(Name) == "Rental" then

                if parseInt(Gemstone) > 0 then
                    local ticketItem, ticketValue = GetBestVehicleTicket(Passport)

                    if ticketItem and ticketValue >= Gemstone then
                        if vRP.Request(source,"Usar <b>"..ticketItem.."</b> para alugar o veículo <b>"..VehicleName(Name).."</b>?") then

                            vRP.TakeItem(Passport, ticketItem, 1, true)

                            local vehicle = vRP.Query("vehicles/selectVehicles",{ Passport = Passport, vehicle = Name })
                            if vehicle[1] then
                                if vehicle[1]["rental"] <= os.time() then
                                    vRP.Query("vehicles/rentalVehiclesUpdate",{ Passport = Passport, vehicle = Name })
                                else
                                    vRP.Query("vehicles/rentalVehiclesDays",{ Passport = Passport, vehicle = Name })
                                end
                            else
                                vRP.Query("vehicles/rentalVehicles",{ Passport = Passport, vehicle = Name, plate = vRP.GeneratePlate(), work = "false" })
                            end

                            TriggerClientEvent("Notify",source,"verde","Aluguel concluído usando o ticket <b>"..ticketItem.."</b>.",5000)
                        end

                        Active[Passport] = nil
                        return
                    end

                    if vRP.Request(source,"Alugar o veículo <b>"..VehicleName(Name).."</b> por <b>"..Gemstone.."</b> gemas?") then
                        if vRP.PaymentGems(Passport,Gemstone) then

                            local vehicle = vRP.Query("vehicles/selectVehicles",{ Passport = Passport, vehicle = Name })
                            if vehicle[1] then
                                if vehicle[1]["rental"] <= os.time() then
                                    vRP.Query("vehicles/rentalVehiclesUpdate",{ Passport = Passport, vehicle = Name })
                                else
                                    vRP.Query("vehicles/rentalVehiclesDays",{ Passport = Passport, vehicle = Name })
                                end
                            else
                                vRP.Query("vehicles/rentalVehicles",{ Passport = Passport, vehicle = Name, plate = vRP.GeneratePlate(), work = "false" })
                            end

                            TriggerClientEvent("Notify",source,"verde","Aluguel concluído!",5000)
                        else
                            TriggerClientEvent("Notify",source,"vermelho","Gemas insuficientes.",5000)
                        end
                    end

                    Active[Passport] = nil
                    return
                end

                if parseInt(Price) > 0 then
                    if vRP.Request(source,"Alugar o veículo <b>"..VehicleName(Name).."</b> por <b>$"..parseFormat(Price).."</b>?") then
                        if vRP.PaymentFull(Passport,Price,"Aluguel de "..VehicleName(Name)) then

                            local vehicle = vRP.Query("vehicles/selectVehicles",{ Passport = Passport, vehicle = Name })
                            if vehicle[1] then
                                if vehicle[1]["rental"] <= os.time() then
                                    vRP.Query("vehicles/rentalVehiclesUpdate",{ Passport = Passport, vehicle = Name })
                                else
                                    vRP.Query("vehicles/rentalVehiclesDays",{ Passport = Passport, vehicle = Name })
                                end
                            else
                                vRP.Query("vehicles/rentalVehicles",{ Passport = Passport, vehicle = Name, plate = vRP.GeneratePlate(), work = "false" })
                            end

                            TriggerClientEvent("Notify",source,"verde","Aluguel concluído!",5000)
                        end
                    end
                end

                Active[Passport] = nil
                return
            end

            local vehicle = vRP.Query("vehicles/selectVehicles",{ Passport = Passport, vehicle = Name })
            if vehicle[1] then
                TriggerClientEvent("Notify",source,"amarelo","Você já possui esse veículo.",3000)
                Active[Passport] = nil
                return
            end

            if parseInt(Gemstone) > 0 then
                if vRP.Request(source,"Comprar <b>"..VehicleName(Name).."</b> por <b>"..Gemstone.."</b> gemas?") then
                    if vRP.PaymentGems(Passport,Gemstone) then

                        vRP.Query("vehicles/addVehicles",{ Passport = Passport, vehicle = Name, plate = vRP.GeneratePlate(), work = "false" })

                        TriggerClientEvent("Notify",source,"verde","Veículo comprado com sucesso!",5000)

                    else
                        TriggerClientEvent("Notify",source,"vermelho","Gemas insuficientes.",5000)
                    end
                end

                Active[Passport] = nil
                return
            end

            if parseInt(Price) > 0 then
                if vRP.Request(source,"Comprar <b>"..VehicleName(Name).."</b> por <b>$"..parseFormat(Price).."</b>?") then
                    if vRP.PaymentFull(Passport,Price,"Compra de "..VehicleName(Name)) then

                        vRP.Query("vehicles/addVehicles",{ Passport = Passport, vehicle = Name, plate = vRP.GeneratePlate(), work = "false" })

                        TriggerClientEvent("Notify",source,"verde","Veículo comprado com sucesso!",5000)
                    end
                end
            end
        end

        Active[Passport] = nil
    end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- CHECKDRIVE
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.CheckDrive()
    local source = source
    local Passport = vRP.Passport(source)
    if Passport then
        if not Active[Passport] then
            Active[Passport] = true

            if not exports["hud"]:Wanted(Passport) then
                if vRP.Request(source,"Iniciar o teste por <b>" .. DrivePrice.. "</b> dólares?") then
                    if vRP.PaymentFull(Passport,DrivePrice) then
                        Player(source)["state"]["Route"] = Passport
                        SetPlayerRoutingBucket(source, Passport)
                        Active[Passport] = nil

                        return true
                    else
                        TriggerClientEvent("Notify",source,"vermelho","<b>Dólares</b> insuficientes.",5000)
                    end
                end
            end

            Active[Passport] = nil
        end
    end

    return false
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- REMOVEDRIVE
-----------------------------------------------------------------------------------------------------------------------------------------
function Creative.RemoveDrive()
    local source = source
    local Passport = vRP.Passport(source)
    if Passport then
        Player(source)["state"]["Route"] = 0
        SetPlayerRoutingBucket(source, 0)
    end
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- DISCONNECT
-----------------------------------------------------------------------------------------------------------------------------------------
AddEventHandler("Disconnect",function(Passport)
	if Active[Passport] then
		Active[Passport] = nil
	end
end)
