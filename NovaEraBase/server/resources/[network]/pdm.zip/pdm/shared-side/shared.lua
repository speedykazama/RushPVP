SpawnVehicle = vec4(-352.4,-1397.89,31.31,274.97)           -- LOCAL QUE O VEÍCULO VAI SPAWNAR
SpawnVehicleCam = vec4(-345.99,-1397.69,31.31,87.88)        -- LOCAL DA CÂMERA PARA VISUALIZAR O VEÍCULO
DriveIn = vec4(-346.11,-1338.17,31.34,274.97)               -- LOCAL DO SPAWN DO VEÍCULO DO TESTE DRIVE
DriveOut = vec4(-337.68,-1370.07,31.86,0.0)                 -- LOCAL DE SAÍDA DO JOGADOR DO TESTE DRIVE

NamePlate = "PDMSPORT"                                      -- NOME DA PLACA DOS VEÍCULOS
DrivePrice = 100                                            -- VALOR DO TESTE DRIVE

VehicleTicketValues = {
    ["vehiclevip"] = 60,
    ["vehiclevip2"] = 120,
    ["vehiclevip3"] = 300
}