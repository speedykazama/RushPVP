fx_version "bodacious"
game "gta5"
lua54 "yes"

ui_page "web-side/index.html"

server_scripts {
	"@vrp/config/Vehicle.lua",
	"@vrp/config/Global.lua",
	"@vrp/lib/Utils.lua",
	"shared-side/*"
}

client_scripts {
	"@vrp/config/Vehicle.lua",
	"@vrp/config/Global.lua",
	"@vrp/config/Native.lua",
	"@vrp/lib/Utils.lua",
	"shared-side/*",
	"client-side/*"
}

server_scripts {
	"@vrp/config/Vehicle.lua",
	"@vrp/config/Global.lua",
	"@vrp/lib/Utils.lua",
	"shared-side/*",
	"server-side/*"
}

files {
	"web-side/*",
	"web-side/**/*"
}