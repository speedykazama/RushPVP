-----------------------------------------------------------------------------------------------------------------------------------------
-- VRP
-----------------------------------------------------------------------------------------------------------------------------------------
local Tunnel = module("vrp","lib/Tunnel")
local Proxy = module("vrp","lib/Proxy")
vRPC = Tunnel.getInterface("vRP")
vRP = Proxy.getInterface("vRP")
-----------------------------------------------------------------------------------------------------------------------------------------
-- CONNECTION
-----------------------------------------------------------------------------------------------------------------------------------------
vCLIENT = Tunnel.getInterface("paramedic")
vSKINSHOP = Tunnel.getInterface("skinshop")
vKEYBOARD = Tunnel.getInterface("keyboard")
-----------------------------------------------------------------------------------------------------------------------------------------
-- VARIABLES
-----------------------------------------------------------------------------------------------------------------------------------------
local BloodTimers = {}
local ExtractPerson = {}
-----------------------------------------------------------------------------------------------------------------------------------------
-- PARAMEDIC:REPOSED
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("paramedic:Reposed")
AddEventHandler("paramedic:Reposed",function(entity)
	local source = source
	local Passport = vRP.Passport(source)
	if Passport and vRP.GetHealth(source) > 100 and vRP.GetHealth(entity) > 100 then
		if vRP.HasService(Passport,"Emergencia") then
			local Keyboard = vKEYBOARD.keySingle(source,"Minutos:")
			if Keyboard then
				if parseInt(Keyboard[1]) > 0 then
					local OtherPassport = vRP.Passport(entity)
					local Identity = vRP.Identity(OtherPassport)
					local playerTimer = parseInt(Keyboard[1] * 60)
					if Identity then
						if vRP.Request(source,"Adicionar <b>"..Keyboard[1].." minutos</b> de repouso no(a) <b>"..Identity["name"].."</b>?.","Sim, aplicar repouso","Não, mudei de ideia") then
							TriggerClientEvent("Notify",source,"azul","Aplicou <b>"..Keyboard[1].." minutos</b> de repouso.",10000)
							TriggerEvent("Reposed",entity,OtherPassport,playerTimer)

							if NewBankTaxs then
								exports["bank"]:AddTaxs(OtherPassport,"Prefeitura",ReposedTaxs,"Gastos Médicos.")
							end
						end
					end
				end
			end
		end
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- PARAMEDIC:TREATMENT
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("paramedic:Treatment")
AddEventHandler("paramedic:Treatment",function(entity)
	local source = source
	local Passport = vRP.Passport(source)
	if Passport and vRP.GetHealth(source) > 100 and vRP.GetHealth(entity) > 100 then
		local OtherPassport = vRP.Passport(entity)
		local Identity = vRP.Identity(OtherPassport)
		if Identity then
			if vRP.TakeItem(Passport,"syringe0"..Identity["blood"],1) then
				if not BloodTimers[OtherPassport] then
					BloodTimers[OtherPassport] = os.time() + 1800
				end

				TriggerEvent("Reposed",entity,OtherPassport,600)
				TriggerClientEvent("target:StartTreatment",entity)
				TriggerClientEvent("paramedic:Reset",entity)
				TriggerClientEvent("Notify",source,"verde","Tratamento começou.",5000)
			else
				TriggerClientEvent("Notify",source,"amarelo","Precisa de <b>1x "..itemName("syringe0"..Identity["blood"]).."</b>.",5000)
			end
		end
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- PARAMEDIC:EXTRACTBLOOD
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("paramedic:extractBlood")
AddEventHandler("paramedic:extractBlood",function(entity)
	local source = source
	local Passport = vRP.Passport(source)
	if Passport then
		local OtherPassport = vRP.Passport(entity)
		if OtherPassport and not ExtractPerson[OtherPassport] then
			if vRP.GetHealth(entity) >= 170 then
				local Identity = vRP.Identity(OtherPassport)
				if Identity and vRP.Request(entity,"Deseja iniciar a doação sangue?") then
					if not BloodTimers[OtherPassport] then
						BloodTimers[OtherPassport] = os.time()
					end

					if os.time() >= BloodTimers[OtherPassport] then
						if vRP.TakeItem(Passport,"syringe",3) then
							ExtractPerson[OtherPassport] = true
							vRPC.DowngradeHealth(entity,50)
							BloodTimers[OtherPassport] = os.time() + 10800
							vRP.GenerateItem(Passport,"syringe0"..Identity["blood"],5,true)

							if ExtractPerson[OtherPassport] then
								ExtractPerson[OtherPassport] = nil
							end
						else
							TriggerClientEvent("Notify",source,"amarelo","Precisa de <b>3x "..itemName("syringe").."</b>.",5000)
						end
					else
						TriggerClientEvent("Notify",source,"amarelo","No momento não é possível efetuar a extração, o mesmo ainda está se recuperando ou se acidentou recentemente.",10000)
					end
				end
			else
				TriggerClientEvent("Notify",source,"vermelho","Sistema imunológico do paciente muito fraco.",5000)
			end
		end
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- PARAMEDIC:BED
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("paramedic:Bed")
AddEventHandler("paramedic:Bed",function(entity)
	local source = source
	local Passport = vRP.Passport(source)
	if Passport and vRP.GetHealth(source) > 100 then
		if vRP.HasService(Passport,"Emergencia") then
			TriggerClientEvent("target:BedDeitar",entity)
		end
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- PARAMEDIC:REVIVE
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("paramedic:Adrenaline")
AddEventHandler("paramedic:Adrenaline",function(entity)
	local source = source
	local Passport = vRP.Passport(source)
	if Passport and vRP.GetHealth(entity) <= 100 then
		if vRP.ConsultItem(Passport,"adrenaline",1) then
			local OtherPassport = vRP.Passport(entity)
			Player(source)["state"]["Cancel"] = true
			TriggerClientEvent("Progress",source,"Tratando",10000)
			vRPC.playAnim(source,false,{"mini@cpr@char_a@cpr_str","cpr_pumpchest"},true)

			SetTimeout(10000,function()
				vRP.TakeItem(Passport,"adrenaline",1)
				vRP.Revive(entity,120)
				vRPC.Destroy(source)
				vRP.UpgradeThirst(OtherPassport,10)
				vRP.UpgradeHunger(OtherPassport,10)
				Player(source)["state"]["Cancel"] = false
			end)
		else
			TriggerClientEvent("Notify",source,"amarelo","Você não possui <b>1x "..itemName("adrenaline").."</b>.",5000)
		end
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- PARAMEDIC:REVIVE
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("paramedic:Revive")
AddEventHandler("paramedic:Revive", function(entity)
	local source = source
	local Passport = vRP.Passport(source)
	if Passport then
		if vRP.GetHealth(entity) <= 100 then
			if vRP.HasService(Passport, "Emergencia") then
				local OtherPassport = vRP.Passport(entity)
				Player(source)["state"]["Cancel"] = true
				TriggerClientEvent("Progress", source, "Tratando", 10000)
				vRPC.playAnim(source, false, { "mini@cpr@char_a@cpr_str", "cpr_pumpchest" }, true)

				SetTimeout(10000, function()
					vRP.Revive(entity, 120)
					vRPC.Destroy(source)
					vRP.UpgradeThirst(OtherPassport, 10)
					vRP.UpgradeHunger(OtherPassport, 10)
					Player(source)["state"]["Cancel"] = false
				end)
			else
				TriggerClientEvent("Notify", source, "vermelho", "Esta pessoa não precisa de reanimação.", 5000)
			end
		end
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- POLICE:REVIVE
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("Police:Revive")
AddEventHandler("Police:Revive",function(entity)
	local source = source
	local Passport = vRP.Passport(source)
	if Passport and vRP.GetHealth(entity) <= 100 then
		if vRP.HasService(Passport,"Policia") then
			local OtherPassport = vRP.Passport(entity)
			Player(source)["state"]["Cancel"] = true
			TriggerClientEvent("Progress",source,10000)
			vRPC.playAnim(source,false,{"mini@cpr@char_a@cpr_str","cpr_pumpchest"},true)
			
			SetTimeout(10000,function()
				vRP.Revive(entity,101)
				vRPC.Destroy(source)
				vRP.UpgradeThirst(OtherPassport,10)
				vRP.UpgradeHunger(OtherPassport,10)
				Player(source)["state"]["Cancel"] = false
			end)
		end
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- PARAMEDIC:BANDAGE
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("paramedic:Bandage")
AddEventHandler("paramedic:Bandage",function(entity)
	local source = source
	local Passport = vRP.Passport(source)
	if Passport and vRP.GetHealth(source) > 100 and vRP.GetHealth(entity) > 100 then
		if vRP.HasService(Passport,"Emergencia") then
			if vCLIENT.Bleeding(entity) > 0 then
				if vRP.TakeItem(Passport,"gauze",1) then
					local Bandage = vCLIENT.Bandage(entity)
					TriggerClientEvent("Progress",source,"Passando",3000)
					vRPC.playAnim(source,false,{"amb@prop_human_parking_meter@female@idle_a","idle_a_female"},true)
					SetTimeout(3000,function()
						TriggerClientEvent("Notify",source,"amarelo","Passou ataduras.",3000)
						TriggerClientEvent("sounds:source",source,"bandage",0.5)
						TriggerClientEvent("paramedic:Reset",source)
						vRPC.Destroy(source)
					end)
				else
					TriggerClientEvent("Notify",source,"amarelo","Precisa de <b>1x "..itemName("gauze").."</b>.",5000)
				end
			else
				TriggerClientEvent("Notify",source,"amarelo","Nenhum ferimento encontrado.",5000)
			end
		end
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- PARAMEDIC:DIAGNOSTIC
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("paramedic:Diagnostic")
AddEventHandler("paramedic:Diagnostic",function(entity)
	local source = source
	local Passport = vRP.Passport(source)
	if Passport and vRP.GetHealth(source) > 100 then
		if vRP.HasService(Passport,"Emergencia") then
			local Result = ""
			local OtherPassport = vRP.Passport(entity)
			local Identity = vRP.Identity(OtherPassport)
			if Identity then
				local Diagnostic,Bleeding = vCLIENT.Diagnostic(entity)

				if Bleeding <= 1 then
					Result = "<b>Sangramento:</b> Baixo<br>"
				elseif Bleeding == 2 then
					Result = "<b>Sangramento:</b> Médio<br>"
				elseif Bleeding >= 3 then
					Result = "<b>Sangramento:</b> Alto<br>"
				end

				Result = Result.."<b>Tipo Sangüíneo:</b> "..Sanguine(Identity["blood"])

				local Number = 0
				local Damaged = false
				for k,v in pairs(Diagnostic) do
					if not Damaged then
						Result = Result.."<br><br><b>Danos Superficiais:</b><br>"
						Damaged = true
					end

					Number = Number + 1
					Result = Result.."<b>"..Number.."</b>: "..Bone(k).."<br>"
				end

				TriggerClientEvent("Notify",source,"amarelo",Result,10000)
			end
		end
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- PLAYER:PRESETPLASTER
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("paramedic:presetPlaster")
AddEventHandler("paramedic:presetPlaster", function(entity)
	local source = source
	local Passport = vRP.Passport(source)
	if Passport then
		if vRP.HasService(Passport,"Emergencia") then
			local Model = vRP.ModelPlayer(entity)
			if Model == "mp_m_freemode_01" or Model == "mp_f_freemode_01" then
				TriggerClientEvent("skinshop:Apply", entity, PresetPlaster[Model])
			end
		end
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- PLAYER:BLOODDEATH
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("paramedic:bloodDeath")
AddEventHandler("paramedic:bloodDeath",function()
	local source = source
	local Passport = vRP.Passport(source)
	if Passport then
		BloodTimers[Passport] = os.time() + 10800
	end
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- DISCONNECT
-----------------------------------------------------------------------------------------------------------------------------------------
AddEventHandler("Disconnect",function(Passport)
	if ExtractPerson[Passport] then
		ExtractPerson[Passport] = nil
	end
end)