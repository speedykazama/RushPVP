fx_version 'cerulean'
game 'gta5'

author 'GitHub Copilot'
description 'Sistema de Modo de Tiro - Converte armas automáticas para semiautomáticas com alternância'
version '1.0.0'

client_scripts {
    'client.lua'
}

ui_page 'html/index.html'

files {
    'html/index.html'
}

-- Dependências opcionais
-- dependencies {
--     'es_extended', -- Se usar ESX
--     'qb-core'      -- Se usar QB-Core
-- }