-- Sistema de Modo de Tiro (Semi/Automático)
-- Criado por GitHub Copilot

local FireModeSystem = {
    currentMode = "SEMI", -- "SEMI" ou "AUTO"
    lastShotTime = 0,
    semiFireDelay = 17500, -- Delay mínimo entre tiros no modo semi (ms) - aumentado para 2.5s
    showingModeChange = false,
    canShoot = true,
    showDebug = false, -- Controlar se mostra debug na tela
    blockedShots = 0 -- Contador de tiros bloqueados
}

-- Armas que suportam alternância entre semi e automático
local SwitchableWeapons = {
    [`EO_G36_02`] = true,
    [`WEAPON_CARBINERIFLE`] = true,
    [`WEAPON_ADVANCEDRIFLE`] = true,
    [`WEAPON_BULLPUPRIFLE`] = true,
    [`WEAPON_SPECIALCARBINE`] = true,
    [`WEAPON_COMPACTRIFLE`] = true,
    [`WEAPON_MILITARYRIFLE`] = true,
    [`WEAPON_HEAVYRIFLE`] = true,
    [`WEAPON_TACTICALRIFLE`] = true,
    [`WEAPON_BULLPUPRIFLE2`] = true,
    [`WEAPON_SPECIALCARBINE_MK2`] = true,
    [`WEAPON_ASSAULTRIFLE_MK2`] = true,
    [`WEAPON_CARBINERIFLE_MK2`] = true,
    [`EO_G36_02`] = true,
}

-- Todas as armas automáticas (incluindo as que não podem alternar)
local AutomaticWeapons = {
    [`EO_G36_02`] = true,
    [`WEAPON_CARBINERIFLE`] = true,
    [`WEAPON_ADVANCEDRIFLE`] = true,
    [`WEAPON_BULLPUPRIFLE`] = true,
    [`WEAPON_SPECIALCARBINE`] = true,
    [`WEAPON_COMPACTRIFLE`] = true,
    [`WEAPON_MILITARYRIFLE`] = true,
    [`WEAPON_HEAVYRIFLE`] = true,
    [`WEAPON_TACTICALRIFLE`] = true,
    [`WEAPON_BULLPUPRIFLE2`] = true,
    [`WEAPON_SPECIALCARBINE_MK2`] = true,
    [`WEAPON_ASSAULTRIFLE_MK2`] = true,
    [`WEAPON_CARBINERIFLE_MK2`] = true,
    [`EO_G36_02`] = true,
    [`WEAPON_SMG`] = true,
    [`WEAPON_SMG_MK2`] = true,
    [`WEAPON_COMBATPDW`] = true,
    [`WEAPON_MICROSMG`] = true,
    [`WEAPON_MINISMG`] = true,
    [`WEAPON_MG`] = true,
    [`WEAPON_COMBATMG`] = true,
    [`WEAPON_COMBATMG_MK2`] = true,
    [`WEAPON_GUSENBERG`] = true,
}

-- Verificar se a arma é automática
function IsAutomaticWeapon(weaponHash)
    return AutomaticWeapons[weaponHash] or false
end

-- Verificar se a arma pode alternar modos
function CanSwitchFireMode(weaponHash)
    return SwitchableWeapons[weaponHash] or false
end

-- Mostrar notificação
function ShowNotification(text, type)
    SendNUIMessage({
        action = "showNotification",
        text = text,
        type = type or "info"
    })
end

-- Alternar modo de tiro
function ToggleFireMode()
    local ped = PlayerPedId()
    local weaponHash = GetSelectedPedWeapon(ped)
    
    print("DEBUG: ToggleFireMode iniciada")
    print("DEBUG: Weapon Hash: " .. weaponHash)
    print("DEBUG: Pode alternar: " .. (CanSwitchFireMode(weaponHash) and "SIM" or "NÃO"))
    
    if not CanSwitchFireMode(weaponHash) then
        ShowNotification("❌ Esta arma não suporta alternância de modo!", "warning")
        print("DEBUG: Arma não suporta alternância - cancelando")
        return
    end
    
    if FireModeSystem.showingModeChange then
        print("DEBUG: Já alterando modo - cancelando")
        return
    end
    
    FireModeSystem.showingModeChange = true
    
    print("DEBUG: Modo anterior: " .. FireModeSystem.currentMode)
    
    if FireModeSystem.currentMode == "SEMI" then
        FireModeSystem.currentMode = "AUTO"
        ShowNotification("🔥 MODO AUTOMÁTICO ativado", "success")
        PlaySoundFrontend(-1, "WEAPON_PURCHASE", "HUD_AMMO_SHOP_SOUNDSET", false)
        print("DEBUG: Alterado para AUTOMÁTICO")
    else
        FireModeSystem.currentMode = "SEMI"
        ShowNotification("🎯 MODO SEMIAUTOMÁTICO ativado", "info")
        PlaySoundFrontend(-1, "CANCEL", "HUD_FREEMODE_SOUNDSET", false)
        print("DEBUG: Alterado para SEMIAUTOMÁTICO")
    end
    
    print("DEBUG: Novo modo: " .. FireModeSystem.currentMode)
    
    -- Atualizar UI
    SendNUIMessage({
        action = "updateFireMode",
        mode = FireModeSystem.currentMode
    })
    
    print("DEBUG: UI atualizada")
    
    Citizen.SetTimeout(2000, function()
        FireModeSystem.showingModeChange = false
        print("DEBUG: showingModeChange resetado")
    end)
end

-- Controlar tiro semiautomático
function ControlSemiFire()
    local ped = PlayerPedId()
    local weaponHash = GetSelectedPedWeapon(ped)
    
    if not IsAutomaticWeapon(weaponHash) then
        return
    end
    
    local currentTime = GetGameTimer()
    
    -- Se está no modo SEMI ou se a arma não pode alternar (forçar semi)
    if FireModeSystem.currentMode == "SEMI" or not CanSwitchFireMode(weaponHash) then
        
        -- Verificar se pode atirar baseado no tempo
        if currentTime - FireModeSystem.lastShotTime >= FireModeSystem.semiFireDelay then
            FireModeSystem.canShoot = true
        end
        
        -- Método mais suave: bloquear apenas durante o período crítico
        if not FireModeSystem.canShoot then
            -- Só desabilitar se estiver tentando atirar (não constantemente)
            if IsControlPressed(0, 24) or IsControlPressed(0, 25) then
                DisableControlAction(0, 24, true) -- Attack
                DisableControlAction(0, 25, true) -- Attack 2
                DisableControlAction(0, 257, true) -- Attack 2 (controller)
                FireModeSystem.blockedShots = FireModeSystem.blockedShots + 1
            end
        end
        
        -- Detectar quando atirou
        if IsPedShooting(ped) and FireModeSystem.canShoot then
            -- Registrar o tiro e bloquear próximos tiros
            FireModeSystem.lastShotTime = currentTime
            FireModeSystem.canShoot = false
            
            -- Debug
            print("DEBUG: Tiro semi registrado em " .. currentTime)
        end
        
        -- Mostrar debug do estado (opcional)
        if not FireModeSystem.canShoot and FireModeSystem.showDebug then
            local timeLeft = FireModeSystem.semiFireDelay - (currentTime - FireModeSystem.lastShotTime)
            if timeLeft > 0 then
                SetTextFont(4)
                SetTextScale(0.3, 0.3)
                SetTextColour(255, 255, 255, 255)
                SetTextOutline()
                SetTextEntry("STRING")
                AddTextComponentString(string.format("SEMI: %.1fs", timeLeft / 1000))
                DrawText(0.02, 0.02)
            end
        end
    end
end

-- Thread principal de controle
Citizen.CreateThread(function()
    while true do
        local ped = PlayerPedId()
        local weaponHash = GetSelectedPedWeapon(ped)
        
        if IsAutomaticWeapon(weaponHash) and (FireModeSystem.currentMode == "SEMI" or not CanSwitchFireMode(weaponHash)) then
            Citizen.Wait(0) -- Controle preciso apenas no modo semi
            ControlSemiFire()
        else
            Citizen.Wait(100) -- Delay maior quando não precisa de controle preciso
        end
    end
end)

-- Thread separada para detectar tecla G (mais precisa)
Citizen.CreateThread(function()
    local lastKeyPressTime = 0
    
    while true do
        Citizen.Wait(0)
        
        local ped = PlayerPedId()
        local weaponHash = GetSelectedPedWeapon(ped)
        local currentTime = GetGameTimer()
        
        if IsAutomaticWeapon(weaponHash) and CanSwitchFireMode(weaponHash) then
            -- Verificar se G está sendo pressionado (Control ID 47 = G)
            if IsControlJustPressed(0, 47) and currentTime - lastKeyPressTime > 200 then
                print("DEBUG: Tecla G detectada! Alternando modo...")
                lastKeyPressTime = currentTime
                ToggleFireMode()
            end
            
            -- Backup: Verificar tecla J como alternativa (Control ID 152)
            if IsControlJustPressed(0, 152) and currentTime - lastKeyPressTime > 200 then
                print("DEBUG: Tecla J detectada! Alternando modo...")
                lastKeyPressTime = currentTime
                ToggleFireMode()
            end
            
            -- Backup 2: Verificar tecla X (Control ID 73)
            if IsControlJustPressed(0, 73) and currentTime - lastKeyPressTime > 200 then
                print("DEBUG: Tecla X detectada! Alternando modo...")
                lastKeyPressTime = currentTime
                ToggleFireMode()
            end
        end
    end
end)

-- Thread para atualizar UI
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(1000)
        
        local ped = PlayerPedId()
        local weaponHash = GetSelectedPedWeapon(ped)
        
        if IsAutomaticWeapon(weaponHash) then
            local canSwitch = CanSwitchFireMode(weaponHash)
            local mode = canSwitch and FireModeSystem.currentMode or "SEMI"
            
            SendNUIMessage({
                action = "updateDisplay",
                show = true,
                mode = mode,
                canSwitch = canSwitch
            })
        else
            SendNUIMessage({
                action = "updateDisplay",
                show = false
            })
        end
    end
end)

-- Comandos de debug
RegisterCommand("modo", function()
    local ped = PlayerPedId()
    local weaponHash = GetSelectedPedWeapon(ped)
    local weaponName = "DESCONHECIDA"
    
    -- Identificar arma
    if weaponHash == GetHashKey("WEAPON_ASSAULTRIFLE") then weaponName = "ASSAULT RIFLE"
    elseif weaponHash == GetHashKey("WEAPON_CARBINERIFLE") then weaponName = "CARBINE RIFLE"
    elseif weaponHash == GetHashKey("EO_G36_02") then weaponName = "G36"
    elseif weaponHash == GetHashKey("WEAPON_SPECIALCARBINE") then weaponName = "SPECIAL CARBINE"
    end
    
    local isAuto = IsAutomaticWeapon(weaponHash)
    local canSwitch = CanSwitchFireMode(weaponHash)
    local currentMode = canSwitch and FireModeSystem.currentMode or "SEMI (Fixo)"
    
    print("DEBUG INFO:")
    print("- Arma: " .. weaponName .. " (Hash: " .. weaponHash .. ")")
    print("- É automática: " .. (isAuto and "SIM" or "NÃO"))
    print("- Pode alternar: " .. (canSwitch and "SIM" or "NÃO"))
    print("- Modo atual: " .. currentMode)
    
    ShowNotification(string.format("🔫 %s | Modo: %s | Pode alternar: %s", 
        weaponName,
        currentMode,
        canSwitch and "SIM" or "NÃO"
    ), "info")
end, false)

RegisterCommand("alternar", function()
    print("DEBUG: Comando /alternar executado")
    ToggleFireMode()
end, false)

-- Comando para testar detecção da tecla G
RegisterCommand("testeg", function()
    local ped = PlayerPedId()
    local weaponHash = GetSelectedPedWeapon(ped)
    
    print("DEBUG: Testando tecla G")
    print("- Arma Hash: " .. weaponHash)
    print("- É automática: " .. (IsAutomaticWeapon(weaponHash) and "SIM" or "NÃO"))
    print("- Pode alternar: " .. (CanSwitchFireMode(weaponHash) and "SIM" or "NÃO"))
    
    if IsAutomaticWeapon(weaponHash) and CanSwitchFireMode(weaponHash) then
        ShowNotification("✅ Arma compatível! Pressione G para alternar", "success")
    else
        ShowNotification("❌ Arma não compatível com alternância", "warning")
    end
end, false)

-- Comando para testar modo semiautomático
RegisterCommand("testsemi", function()
    local ped = PlayerPedId()
    local weaponHash = GetSelectedPedWeapon(ped)
    local currentTime = GetGameTimer()
    
    print("DEBUG: Estado do modo semiautomático")
    print("- Modo atual: " .. FireModeSystem.currentMode)
    print("- Pode atirar: " .. (FireModeSystem.canShoot and "SIM" or "NÃO"))
    print("- Último tiro: " .. FireModeSystem.lastShotTime)
    print("- Tempo atual: " .. currentTime)
    print("- Tempo desde último tiro: " .. (currentTime - FireModeSystem.lastShotTime) .. "ms")
    print("- Delay necessário: " .. FireModeSystem.semiFireDelay .. "ms")
    
    ShowNotification(string.format("🎯 Modo: %s | Pode atirar: %s", 
        FireModeSystem.currentMode,
        FireModeSystem.canShoot and "SIM" or "NÃO"
    ), "info")
end, false)

-- Comando para alternar debug visual
RegisterCommand("debugsemi", function()
    FireModeSystem.showDebug = not FireModeSystem.showDebug
    ShowNotification(string.format("🔧 Debug visual: %s", 
        FireModeSystem.showDebug and "LIGADO" or "DESLIGADO"
    ), "info")
end, false)

-- Comando para ajustar delay do modo semiautomático
RegisterCommand("delaysemi", function(source, args)
    if args[1] then
        local newDelay = tonumber(args[1])
        if newDelay and newDelay >= 100 and newDelay <= 3000 then
            FireModeSystem.semiFireDelay = newDelay
            ShowNotification(string.format("⏱️ Delay semiautomático: %dms (%.1fs)", 
                newDelay, newDelay/1000
            ), "success")
        else
            ShowNotification("❌ Valor inválido! Use entre 100-3000ms", "warning")
        end
    else
        ShowNotification(string.format("⏱️ Delay atual: %dms (%.1fs)", 
            FireModeSystem.semiFireDelay, FireModeSystem.semiFireDelay/1000
        ), "info")
    end
end, false)

-- Comando para testar o delay em tempo real
RegisterCommand("testardelay", function()
    local ped = PlayerPedId()
    local currentTime = GetGameTimer()
    local timeSinceLastShot = currentTime - FireModeSystem.lastShotTime
    local timeToWait = FireModeSystem.semiFireDelay - timeSinceLastShot
    
    print("DEBUG: Teste do delay semiautomático")
    print("- Delay configurado: " .. FireModeSystem.semiFireDelay .. "ms")
    print("- Último tiro: " .. FireModeSystem.lastShotTime)
    print("- Tempo atual: " .. currentTime)
    print("- Tempo desde último tiro: " .. timeSinceLastShot .. "ms")
    print("- Pode atirar: " .. (FireModeSystem.canShoot and "SIM" or "NÃO"))
    
    if FireModeSystem.canShoot then
        ShowNotification("✅ Pode atirar agora!", "success")
    else
        ShowNotification(string.format("⏳ Aguarde %.1fs para atirar", timeToWait/1000), "warning")
    end
end, false)

RegisterCommand("resetmodo", function()
    FireModeSystem.currentMode = "SEMI"
    FireModeSystem.lastShotTime = 0
    FireModeSystem.canShoot = true
    FireModeSystem.blockedShots = 0
    
    ShowNotification("🔄 Modo de tiro resetado para SEMI", "info")
end, false)