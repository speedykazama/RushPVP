# Sistema de Modo de Tiro (Semi/Automático)

Sistema que converte todas as armas automáticas para modo semiautomático por padrão e permite alternar entre semi e automático em armas específicas.

## 🎯 Características

- **Conversão Automática**: Todas as armas automáticas viram semiautomáticas por padrão
- **Alternância de Modo**: Algumas armas podem alternar entre semi e automático
- **Interface Visual**: Display moderno mostrando o modo atual
- **Controle por Tecla**: Pressione **G** para alternar modos
- **Sons e Efeitos**: Feedback sonoro e visual para mudanças

## 🔫 Como Funciona

### Modo Semiautomático (Padrão)
- **Todas as armas automáticas** começam no modo semiautomático
- Delay de 200ms entre tiros para simular semi
- Não permite tiro contínuo segurando o botão

### Modo Automático (Selecionável)
- **Apenas armas específicas** podem alternar para automático
- Tiro contínuo normal
- Pressione **G** para alternar

## 🔧 Configuração de Armas

### ⚙️ Armas que PODEM Alternar (Semi ↔ Auto):
```lua
SwitchableWeapons = {
    [`WEAPON_ASSAULTRIFLE`] = true,
    [`WEAPON_CARBINERIFLE`] = true,
    [`WEAPON_ADVANCEDRIFLE`] = true,
    [`WEAPON_BULLPUPRIFLE`] = true,
    [`WEAPON_SPECIALCARBINE`] = true,
    [`WEAPON_COMPACTRIFLE`] = true,
    [`WEAPON_MILITARYRIFLE`] = true,
    [`WEAPON_HEAVYRIFLE`] = true,
    [`WEAPON_TACTICALRIFLE`] = true,
    [`WEAPON_BULLPUPRIFLE2`] = true,
    [`WEAPON_SPECIALCARBINE_MK2`] = true,
    [`WEAPON_ASSAULTRIFLE_MK2`] = true,
    [`WEAPON_CARBINERIFLE_MK2`] = true,
    [`EO_G36_02`] = true,
}
```

### 🔒 Armas APENAS Semiautomáticas (Não alternam):
- SMGs (WEAPON_SMG, WEAPON_MICROSMG, etc.)
- Metralhadoras (WEAPON_MG, WEAPON_COMBATMG, etc.)
- Outras armas automáticas não listadas em SwitchableWeapons

## 🎮 Controles

- **G** - Alternar modo de tiro (apenas em armas compatíveis)

## 🎨 Interface

### Display de Modo:
- **🎯 Azul**: Modo Semiautomático
- **🔥 Vermelho**: Modo Automático
- **Hint**: Mostra se pode alternar ou se é modo fixo

### Notificações:
- Confirmação visual quando alterna modos
- Avisos para armas incompatíveis

## 📋 Comandos de Debug

- `/modo` - Mostra informações da arma atual
- `/alternar` - Força alternância de modo
- `/resetmodo` - Reseta para modo semiautomático

## 🛠️ Instalação

1. Coloque a pasta `Fuzil` em `resources/[dev]/`
2. Adicione `ensure Fuzil` no seu `server.cfg`
3. Reinicie o servidor

## ⚙️ Personalização

### Alterar Delay do Modo Semi:
```lua
semiFireDelay = 200, -- ms entre tiros (no client.lua)
```

### Adicionar Nova Arma para Alternância:
```lua
[`WEAPON_NOVA_ARMA`] = true, -- Em SwitchableWeapons
```

### Remover Arma da Alternância:
Remova ou comente a linha da arma em `SwitchableWeapons`

## 🎯 Exemplos de Uso

### Cenário 1: Rifle de Assalto
- **Padrão**: Modo semiautomático
- **Tecla G**: Alterna para automático
- **Tecla G novamente**: Volta para semiautomático

### Cenário 2: SMG
- **Sempre**: Modo semiautomático
- **Tecla G**: Mostra aviso "não suporta alternância"

### Cenário 3: Pistola
- **Não afetada**: Funciona normalmente
- **Interface**: Não aparece display de modo

## 🔊 Efeitos Sonoros

- **Som de Confirmação**: Quando alterna para automático
- **Som de Cancelamento**: Quando alterna para semiautomático
- **Som de Erro**: Quando tenta alternar arma incompatível

## 🐛 Troubleshooting

### Problema: Arma não fica semiautomática
- Verifique se está na lista `AutomaticWeapons`
- Use `/modo` para verificar se está sendo detectada

### Problema: Não consegue alternar
- Verifique se está na lista `SwitchableWeapons`
- Algumas armas são propositalmente fixas em semi

### Problema: Interface não aparece
- Verifique arquivo `html/index.html`
- Certifique-se que está com arma automática

## 📊 Status do Sistema

- ✅ **Funcionando**: Conversão para semiautomático
- ✅ **Funcionando**: Alternância em armas específicas  
- ✅ **Funcionando**: Interface visual
- ✅ **Funcionando**: Controles e feedback

## 🆕 Versão 1.0.0

- Sistema base de conversão semi/auto
- Interface visual completa
- Alternância com tecla G
- Suporte para armas principais do GTA V
- Comandos de debug e personalização

---

**Criado por GitHub Copilot**